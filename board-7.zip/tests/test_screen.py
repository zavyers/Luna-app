import sys, tempfile, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.screen import classify  # noqa: E402
from app.agent.wake import WakeGate  # noqa: E402
from app.ai import AIResponse  # noqa: E402
from app.chat.store import ChatStore  # noqa: E402
from app.config import load_settings  # noqa: E402
from app.ui.server import build_app  # noqa: E402


class FakeProvider:
    last_used = "fake"

    def __init__(self):
        self.calls = []

    def generate(self, messages, system_instruction=None):
        self.calls.append((messages, system_instruction or ""))
        sysm = system_instruction or ""
        if "web search query" in sysm:
            return AIResponse("Casio F-91W price review")
        if "picture of the user's phone screen" in sysm:
            return AIResponse("[curious] A reel with a small digital watch. What would you like to know about it?")
        return AIResponse("[calm] It looks like a Casio F-91W, usually around 20 dollars.")

    def stream(self, messages, system_instruction=None):
        yield self.generate(messages, system_instruction).text


class ScreenPhone:
    def __init__(self):
        self.shots = 0
        self.screen_ok = True

    def find_app(self, name): return ""
    def contacts_enabled(self): return True
    def find_contact(self, name): return []
    def messages_enabled(self): return True
    def recent_messages(self, limit=5, who=""): return []
    def open_message(self, who=""): return "error: none"

    def screenshot(self):
        self.shots += 1
        return "ok:QUJD" if self.screen_ok else "error: turn on Luna phone control first"

    def read_screen(self):
        return "ok: Casio F-91W. Link in bio." if self.screen_ok else "error: turn on Luna phone control first"


class ScreenTests(unittest.TestCase):
    def setUp(self):
        folder = Path(tempfile.mkdtemp())
        settings = load_settings(folder / "none.env", folder / "keys.json")
        settings.__dict__["gemini_api_key"] = "x"
        self.provider = FakeProvider()
        self.phone = ScreenPhone()
        self.app = build_app(settings, store=ChatStore(folder / "chats.json"), provider=self.provider, phone=self.phone)
        self.app.platform = "android"
        self.assistant = self.app.assistant
        self.assistant.fast.platform = "android"
        self.assistant.settings = type("S", (), {"has_api_key": True, "web_mode": "off", "env_file": "", "assistant_name": "Luna",
                                                 "user_title": "sir", "wake_word": "", "wake_required": True})()

    def ask(self, text, chat=None):
        final = None
        for kind, value in self.assistant.handle_stream(chat, text):
            if kind == "reply":
                final = value
        return final

    def test_classify(self):
        self.assertEqual(classify("read my screen"), "look")
        self.assertEqual(classify("what am i looking at"), "look")
        self.assertEqual(classify("tell me about this watch"), "ask")
        self.assertEqual(classify("how much is this watch"), "ask")
        for plain in ["what is the capital of france", "is it raining", "open youtube", "how does this work in python", "tell me a joke"]:
            self.assertIsNone(classify(plain), plain)
        self.assertEqual(classify("is it worth it", fresh=True), "follow")
        self.assertIsNone(classify("thanks", fresh=True))

    def test_look_then_follow_up_uses_the_same_screen(self):
        r = self.ask("hey read the screen")
        self.assertIn("What would you like to know", r.text)
        shots = self.phone.shots
        r2 = self.ask("is it worth buying", r.chat_id)  # no "this": the screen was just looked at
        self.assertIn("Casio", r2.text)
        self.assertEqual(self.phone.shots, shots, "a follow-up must reuse the screen, not look again")
        messages = self.assistant.store.messages(r2.chat_id)
        self.assertEqual([m["role"] for m in messages], ["user", "assistant", "user", "assistant"])  # shows in the conversation box

    def test_question_sends_the_picture(self):
        self.ask("tell me about this watch")
        images = [m.images for call in self.provider.calls for m in call[0] if m.images]
        self.assertTrue(images and images[0][0][1] == "QUJD")

    def test_unseen_screen_is_reported_honestly(self):
        self.phone.screen_ok = False
        r = self.ask("read my screen")
        self.assertFalse(r.ok)
        self.assertIn("phone control", r.text)

    def test_follow_up_never_hijacks_commands_or_other_chat(self):
        self.ask("read my screen")
        self.assertIsNone(self.assistant._try_screen(None, "thanks"))
        self.assertIsNone(self.assistant._screen if not self.assistant._screen_fresh() else None)

    def test_wake_window_can_be_longer(self):
        g = WakeGate(lambda: type("S", (), {"assistant_name": "Luna", "wake_word": "", "wake_required": True})())
        g.extend(now=100.0, seconds=25)
        self.assertEqual(g.process("what about the strap", now=120.0)[0], "command")
        self.assertEqual(g.process("what about the strap", now=200.0)[0], "ignore")

    def test_java_pieces_python_calls_exist(self):
        root = Path(__file__).resolve().parents[1] / "app" / "src" / "main"
        src = (root / "java/com/luna/app/LunaAccessibilityService.java").read_text()
        self.assertRegex(src, r"public static String screenshotBase64\(")
        self.assertIn('canTakeScreenshot="true"', (root / "res/xml/accessibility_service_config.xml").read_text())
        self.assertIn("def keep_awake", (root / "python/luna_android.py").read_text())


if __name__ == "__main__":
    unittest.main()
