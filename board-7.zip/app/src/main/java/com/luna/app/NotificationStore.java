package com.luna.app;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The last few message notifications Luna has seen, kept only in memory (never saved to disk, never logged).
 * This is how Luna can say who messaged you, open that conversation, or reply, without reading your screen.
 * It only works after the person allows "Notification access" for Luna in the phone's settings.
 */
public final class NotificationStore {
    private NotificationStore() { }

    static final class Msg {
        String key, pkg, app, conv, sender, text;
        long when;
        PendingIntent open;
        PendingIntent replyIntent;
        RemoteInput replyInput;
    }

    private static final int MAX = 40;
    private static final ArrayList<Msg> RECENT = new ArrayList<>();
    static volatile LunaNotificationListener listener;

    private static final String[] MESSENGERS = {
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.thoughtcrime.securesms", "com.instagram.android",
            "com.facebook.orca", "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms",
            "com.google.android.gm", "com.discord", "com.slack", "com.snapchat.android", "com.microsoft.teams", "com.linkedin.android",
            "com.truecaller", "com.viber.voip", "jp.naver.line.android", "com.skype.raider"
    };

    public static boolean enabled(Context ctx) {
        try {
            String list = Settings.Secure.getString(ctx.getContentResolver(), "enabled_notification_listeners");
            return list != null && list.contains(ctx.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isMessage(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        if (n == null || sbn.getPackageName().equals("com.luna.app")) return false;
        if ((n.flags & (Notification.FLAG_ONGOING_EVENT | Notification.FLAG_GROUP_SUMMARY)) != 0) return false;
        String cat = n.category == null ? "" : n.category;
        if (cat.equals(Notification.CATEGORY_MESSAGE) || cat.equals(Notification.CATEGORY_EMAIL) || cat.equals(Notification.CATEGORY_SOCIAL)) return true;
        for (String p : MESSENGERS) if (p.equals(sbn.getPackageName())) return true;
        return false;
    }

    private static String str(Bundle b, String key) {
        CharSequence c = b.getCharSequence(key);
        return c == null ? "" : c.toString().trim();
    }

    static void onPosted(Context ctx, StatusBarNotification sbn) {
        try {
            if (!isMessage(sbn)) return;
            Notification n = sbn.getNotification();
            Bundle ex = n.extras;
            if (ex == null) return;
            String app = sbn.getPackageName();
            try {
                app = String.valueOf(ctx.getPackageManager().getApplicationLabel(ctx.getPackageManager().getApplicationInfo(sbn.getPackageName(), 0)));
            } catch (Exception ignored) {
                // keep the package name
            }
            String title = str(ex, Notification.EXTRA_TITLE);
            String conv = str(ex, "android.conversationTitle");
            PendingIntent reply = null;
            RemoteInput input = null;
            if (n.actions != null) {
                for (Notification.Action a : n.actions) {
                    RemoteInput[] ris = a.getRemoteInputs();
                    if (ris == null || ris.length == 0 || a.actionIntent == null) continue;
                    String t = a.title == null ? "" : a.title.toString().toLowerCase(Locale.ROOT);
                    if (reply == null || t.contains("reply")) {
                        reply = a.actionIntent;
                        input = ris[0];
                    }
                }
            }
            List<String[]> items = new ArrayList<>(); // sender, text, when
            Parcelable[] msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (msgs != null && msgs.length > 0) {
                List<Notification.MessagingStyle.Message> list = Notification.MessagingStyle.Message.getMessagesFromBundleArray(msgs);
                int from = Math.max(0, list.size() - 3);
                for (int i = from; i < list.size(); i++) {
                    Notification.MessagingStyle.Message m = list.get(i);
                    CharSequence s = m.getSender();
                    String who = s == null ? title : s.toString();
                    if (m.getText() != null) items.add(new String[]{who, m.getText().toString(), String.valueOf(m.getTimestamp())});
                }
            }
            if (items.isEmpty()) {
                String text = str(ex, Notification.EXTRA_BIG_TEXT);
                if (text.isEmpty()) text = str(ex, Notification.EXTRA_TEXT);
                if (text.isEmpty()) return;
                items.add(new String[]{title, text, String.valueOf(sbn.getPostTime())});
            }
            synchronized (RECENT) {
                for (String[] it : items) {
                    long when = Long.parseLong(it[2]);
                    boolean dup = false;
                    for (Msg m : RECENT) {
                        if (m.key.equals(sbn.getKey()) && m.text.equals(it[1]) && m.when == when) {
                            m.open = n.contentIntent != null ? n.contentIntent : m.open;
                            if (reply != null) { m.replyIntent = reply; m.replyInput = input; }
                            dup = true;
                            break;
                        }
                    }
                    if (dup) continue;
                    Msg m = new Msg();
                    m.key = sbn.getKey();
                    m.pkg = sbn.getPackageName();
                    m.app = app;
                    m.conv = conv.isEmpty() || conv.equals(it[0]) ? "" : conv;
                    m.sender = it[0].isEmpty() ? title : it[0];
                    m.text = it[1];
                    m.when = when;
                    m.open = n.contentIntent;
                    m.replyIntent = reply;
                    m.replyInput = input;
                    RECENT.add(m);
                }
                while (RECENT.size() > MAX) RECENT.remove(0);
            }
        } catch (Exception ignored) {
            // one odd notification must never break the listener
        }
    }

    /** Picks up notifications that were already showing before Luna started looking. */
    static void ingestActive(Context ctx) {
        LunaNotificationListener l = listener;
        if (l == null) return;
        try {
            StatusBarNotification[] active = l.getActiveNotifications();
            if (active != null) for (StatusBarNotification s : active) onPosted(ctx, s);
        } catch (Exception ignored) {
            // not connected yet
        }
    }

    private static boolean matches(Msg m, String who) {
        if (who == null || who.trim().isEmpty()) return true;
        String w = who.trim().toLowerCase(Locale.ROOT);
        return m.sender.toLowerCase(Locale.ROOT).contains(w) || m.conv.toLowerCase(Locale.ROOT).contains(w) || m.app.toLowerCase(Locale.ROOT).contains(w);
    }

    private static List<Msg> newest(String who) {
        ArrayList<Msg> out = new ArrayList<>();
        synchronized (RECENT) {
            for (int i = RECENT.size() - 1; i >= 0; i--) if (matches(RECENT.get(i), who)) out.add(RECENT.get(i));
        }
        out.sort((a, b) -> Long.compare(b.when, a.when));
        return out;
    }

    /** JSON list, newest first: [{app, sender, conv, text, when(seconds)}]. */
    public static String recentJson(Context ctx, String who, int limit) {
        ingestActive(ctx);
        JSONArray arr = new JSONArray();
        try {
            for (Msg m : newest(who)) {
                if (arr.length() >= Math.max(1, Math.min(limit, 20))) break;
                JSONObject o = new JSONObject();
                o.put("app", m.app);
                o.put("sender", m.sender);
                o.put("conv", m.conv);
                o.put("text", m.text);
                o.put("when", m.when / 1000.0);
                arr.put(o);
            }
        } catch (Exception ignored) {
            // return what we have
        }
        return arr.toString();
    }

    /** Opens the conversation of the newest matching message, exactly as tapping its notification would. */
    public static String open(Context ctx, String who) {
        ingestActive(ctx);
        List<Msg> list = newest(who);
        if (list.isEmpty()) return "error: I don't see a message" + (who == null || who.isEmpty() ? "" : " from " + who) + " to open";
        Msg m = list.get(0);
        try {
            if (m.open != null) {
                Bundle opts = null;
                if (Build.VERSION.SDK_INT >= 34) {
                    ActivityOptions ao = ActivityOptions.makeBasic();
                    ao.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                    opts = ao.toBundle();
                }
                m.open.send(ctx, 0, null, null, null, null, opts);
                return "ok: opened the message from " + m.sender + " in " + m.app;
            }
        } catch (PendingIntent.CanceledException ignored) {
            // the notification was dismissed; open the app instead
        } catch (Exception e) {
            return "error: Android wouldn't open it" + (Settings.canDrawOverlays(ctx) ? "" : ". Allow “Display over other apps” for Luna and try again");
        }
        String r = PhoneActions.launchPackage(ctx, m.pkg, m.app);
        return r.startsWith("ok") ? "ok: opened " + m.app + " (that notification is gone, so I couldn't jump to the exact chat)" : r;
    }

    /** Sends a reply through the messaging app's own notification reply box. */
    static String reply(Context ctx, String to, String text) {
        ingestActive(ctx);
        Msg target = null;
        for (Msg m : newest(to)) {
            if (m.replyIntent != null && m.replyInput != null) { target = m; break; }
        }
        if (target == null) {
            return "error: I can't reply from a notification" + (to == null || to.isEmpty() ? "" : " from " + to) + ". Open the chat, or let me prepare an SMS instead";
        }
        try {
            Intent fill = new Intent();
            Bundle results = new Bundle();
            results.putCharSequence(target.replyInput.getResultKey(), text);
            RemoteInput.addResultsToIntent(new RemoteInput[]{target.replyInput}, fill, results);
            target.replyIntent.send(ctx, 0, fill);
            return "ok: sent your reply to " + target.sender + " through " + target.app;
        } catch (PendingIntent.CanceledException e) {
            return "error: that conversation's reply has expired. Open the chat and I'll try again when a new message arrives";
        } catch (Exception e) {
            return "error: the reply was refused" + (e.getMessage() == null ? "" : " (" + e.getMessage() + ")");
        }
    }
}
