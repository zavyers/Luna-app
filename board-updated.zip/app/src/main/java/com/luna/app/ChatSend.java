package com.luna.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;

/**
 * Sends a message to someone in a chat app that has no "send to this person" link (Instagram, Snapchat, Telegram, Messenger,
 * Signal): opens the app, searches for the person, opens the chat, types the words and presses Send, the way you would.
 *
 * Best effort: these apps change their screens often, so if Luna gets stuck she says where, and the message is already
 * copied so you can paste it. Needs Luna phone control (Accessibility).
 */
final class ChatSend {
    private ChatSend() { }

    private static final String[][] APPS = {
            {"instagram", "Instagram"}, {"snapchat", "Snapchat"}, {"telegram", "Telegram"}, {"messenger", "Messenger"}, {"signal", "Signal"}};

    /** Any chat app other than WhatsApp and SMS (which have their own way) is handled by walking through its screens. */
    static boolean supports(String via) {
        return !via.isEmpty() && !"auto".equals(via) && !"whatsapp".equals(via) && !"sms".equals(via);
    }

    static String label(String via) {
        for (String[] a : APPS) if (a[0].equals(via)) return a[1];
        return via.isEmpty() ? via : Character.toUpperCase(via.charAt(0)) + via.substring(1);
    }

    /** The button that opens the list of chats, in apps that start somewhere else (feed, camera). */
    private static String[] inbox(String via) {
        switch (via) {
            case "instagram": return new String[]{"Messages", "Message", "Messenger", "Direct", "Inbox"};
            case "snapchat": return new String[]{"Chat", "Chats"};
            default: return new String[0];
        }
    }

    static String send(Context ctx, String via, String person, String text) {
        if (LunaAccessibilityService.instance == null) {
            return "error: turn on Luna phone control in Luna's settings first, so I can use " + label(via) + " for you";
        }
        String pkg = PhoneActions.packageFor(ctx, label(via));
        if (pkg == null) return "error: " + label(via) + " isn't installed on this phone";
        try { // so that if I get stuck, one paste finishes the job
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Luna", text));
        } catch (Exception ignored) {
            // not allowed right now: carry on
        }
        String opened = PhoneActions.launchPackage(ctx, pkg, label(via));
        if (!opened.startsWith("ok")) return opened;
        new Run(ctx, via, person, text).tick();
        return "ok: sending your " + label(via) + " message to " + person;
    }

    private interface Act {
        String go();
    }

    private static final class Run {
        private final Context ctx;
        private final String via, person;
        private final Handler h = new Handler(Looper.getMainLooper());
        private final List<Act> acts = new ArrayList<>();
        private final List<String> names = new ArrayList<>();
        private final List<Boolean> required = new ArrayList<>();
        private final List<Integer> tries = new ArrayList<>();
        private final List<Long> gaps = new ArrayList<>();
        private int step = 0, attempt = 0;

        private void add(String name, boolean must, int max, long gapAfter, Act act) {
            names.add(name);
            required.add(must);
            tries.add(max);
            gaps.add(gapAfter);
            acts.add(act);
        }

        Run(Context ctx, final String via, final String person, final String text) {
            this.ctx = ctx;
            this.via = via;
            this.person = person;
            final String first = person.trim().split("\\s+")[0];
            add("opening the app", false, 1, 2800, () -> "ok");
            final String[] box = inbox(via);
            if (box.length > 0) add("opening your chats", false, 3, 1200, () -> LunaAccessibilityService.tapLabel(box));
            add("the search button", false, 3, 900, () -> LunaAccessibilityService.tapLabel("Search", "Search for people", "Find"));
            add("typing the name", true, 4, 2000, () -> LunaAccessibilityService.typeInto(person, "search", "find", "to:"));
            add("finding " + first, true, 5, 1800, () -> LunaAccessibilityService.tapPerson(person));
            add("typing the message", true, 4, 700, () -> LunaAccessibilityService.typeInto(text, "message", "send a chat", "write", "chat"));
            add("the send button", true, 4, 600, () -> LunaAccessibilityService.tapLabel("Send"));
        }

        void tick() {
            if (step >= acts.size()) {
                Calls.tell(ctx, "I sent your " + label(via) + " message to " + person + ".");
                return;
            }
            String r;
            try {
                r = acts.get(step).go();
            } catch (Throwable e) {
                r = "error";
            }
            if (r.startsWith("ok")) {
                long gap = gaps.get(step);
                step++;
                attempt = 0;
                h.postDelayed(this::tick, gap);
            } else if (++attempt < tries.get(step)) {
                h.postDelayed(this::tick, 900);
            } else if (!required.get(step)) {
                step++;
                attempt = 0;
                h.postDelayed(this::tick, 300);
            } else {
                Calls.tell(ctx, "I opened " + label(via) + " but got stuck at " + names.get(step) + ". Your message is copied, so you can paste it for " + person + ".");
            }
        }
    }
}
