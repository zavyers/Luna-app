package com.luna.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** The PIN on Luna's screen. Only a salted hash is stored. After a few wrong tries in a row Luna makes the person wait. */
final class AppLock {
    private AppLock() { }

    private static final String FILE = "luna_lock";
    private static final int ROUNDS = 20000;
    static final int FREE_TRIES = 5;

    private static SharedPreferences p(Context ctx) {
        return ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context ctx) {
        return p(ctx).getString("hash", null) != null;
    }

    /** "" when the PIN is acceptable, otherwise what is wrong. */
    static String problem(String pin) {
        return pin != null && pin.trim().matches("[0-9]{4,8}") ? "" : "A PIN is 4 to 8 digits.";
    }

    private static byte[] hash(String alg, String pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin.toCharArray(), salt, ROUNDS, 256);
        try {
            return SecretKeyFactory.getInstance(alg).generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
    }

    static String set(Context ctx, String pin) {
        String why = problem(pin);
        if (!why.isEmpty()) return why;
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            String alg = "PBKDF2WithHmacSHA256";
            byte[] h;
            try {
                h = hash(alg, pin.trim(), salt);
            } catch (Exception old) { // Android 7 has no SHA-256 version
                alg = "PBKDF2WithHmacSHA1";
                h = hash(alg, pin.trim(), salt);
            }
            p(ctx).edit().putString("alg", alg).putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("hash", Base64.encodeToString(h, Base64.NO_WRAP)).putInt("fails", 0).putLong("until", 0).apply();
            return "";
        } catch (Exception e) {
            return "Could not save the PIN: " + e.getMessage();
        }
    }

    static void disable(Context ctx) {
        p(ctx).edit().clear().apply();
    }

    static long waitMs(Context ctx) {
        long left = p(ctx).getLong("until", 0) - System.currentTimeMillis();
        return left > 0 ? left : 0;
    }

    static boolean check(Context ctx, String pin) {
        if (!enabled(ctx) || waitMs(ctx) > 0) return false;
        SharedPreferences sp = p(ctx);
        boolean ok;
        try {
            byte[] salt = Base64.decode(sp.getString("salt", ""), Base64.NO_WRAP);
            byte[] want = Base64.decode(sp.getString("hash", ""), Base64.NO_WRAP);
            ok = MessageDigest.isEqual(want, hash(sp.getString("alg", "PBKDF2WithHmacSHA256"), pin == null ? "" : pin.trim(), salt));
        } catch (Exception e) {
            ok = false;
        }
        SharedPreferences.Editor e = sp.edit();
        if (ok) {
            e.putInt("fails", 0).putLong("until", 0);
        } else {
            int fails = sp.getInt("fails", 0) + 1;
            e.putInt("fails", fails);
            if (fails >= FREE_TRIES) e.putLong("until", System.currentTimeMillis() + Math.min(900000L, 30000L << Math.min(fails - FREE_TRIES, 5)));
        }
        e.apply();
        return ok;
    }

    static int triesLeft(Context ctx) {
        return Math.max(0, FREE_TRIES - p(ctx).getInt("fails", 0));
    }
}
