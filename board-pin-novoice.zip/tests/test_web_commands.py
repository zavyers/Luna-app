import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))
from app.agent.fast import FastIntents  # noqa: E402


class Phone:
    def find_app(self, name):
        return None

    def contacts_enabled(self):
        return False


def args(text):
    r = FastIntents("android", Phone()).match(text)
    return r.actions[0]["args"] if r and r.actions else None


class T(unittest.TestCase):
    def test_commands(self):
        self.assertEqual(args("screnshot please"), {"action": "screenshot"})
        self.assertEqual(args("google best phones"), {"action": "a_search_web", "query": "best phones"})
        self.assertEqual(args("open flipkart.com"), {"action": "a_open_url", "url": "https://flipkart.com"})
        self.assertIsNone(args("what is a screenshot"))


class Wiring(unittest.TestCase):
    def test_pin_is_connected(self):
        main = Path(__file__).resolve().parents[1] / "app" / "src" / "main"
        act = (main / "java/com/luna/app/MainActivity.java").read_text()
        for needle in ["AppLock.check(this, typed)", "public String setPin(", "welcome()", "if (locked)"]:
            self.assertIn(needle, act)
        js = (main / "python/app/ui/web/app.js").read_text()
        for needle in ["window.__lunaWelcome", "nat.setPin("]:
            self.assertIn(needle, js)
        self.assertEqual(js, (Path(__file__).resolve().parents[1] / "windows/app/ui/web/app.js").read_text())


if __name__ == "__main__":
    unittest.main()
