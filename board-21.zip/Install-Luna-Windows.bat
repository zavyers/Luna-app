@echo off
rem Double-click this to install Luna on Windows. It runs the installer in the "windows" folder next to it.
if not exist "%~dp0windows\Install-Luna.bat" (
  echo The "windows" folder is missing. Unzip the whole board.zip first, then run this again.
  pause
  exit /b 1
)
call "%~dp0windows\Install-Luna.bat"
