package com.luna.app;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Lets Luna see message notifications (who wrote, what they said). Off until the person allows it in the phone's settings. */
public class LunaNotificationListener extends NotificationListenerService {
    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        NotificationStore.listener = this;
        NotificationStore.ingestActive(this);
    }

    @Override
    public void onListenerDisconnected() {
        NotificationStore.listener = null;
        super.onListenerDisconnected();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        CallWatcher.onPosted(this, sbn); // a ringing call is announced at once
        NotificationStore.onPosted(this, sbn);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        CallWatcher.onRemoved(sbn);
    }
}
