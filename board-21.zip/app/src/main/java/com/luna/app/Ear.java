package com.luna.app;

import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;

import java.io.OutputStream;

/**
 * Lets Luna listen WITHOUT taking the sound away from a reel or video.
 *
 * The normal speech recogniser opens the microphone itself and grabs audio focus, which is what pauses or
 * mutes Instagram, YouTube and music. Here Luna records the microphone herself (recording never asks for
 * audio focus) and hands the sound to the recogniser, so other apps keep playing.
 * Needs Android 13 or newer; on older phones {@link #supported()} is false and the old way is used.
 */
final class Ear {
    private static final int RATE = 16000;

    /** After the recogniser refused our audio twice in a row we stop trying it (some phones don't support it). */
    private static volatile int refusals = 0;

    private AudioRecord rec;
    private OutputStream out;
    private volatile boolean go;

    static boolean supported() {
        return Build.VERSION.SDK_INT >= 33 && refusals < 2;
    }

    static void worked() {
        refusals = 0;
    }

    static void refused() {
        refusals++;
    }

    /** Adds the extras that make the recogniser read from our own recording. False means: listen the normal way. */
    boolean attach(Context ctx, Intent intent) {
        if (!supported()) return false;
        stop();
        try {
            if (ctx.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return false;
            final int size = Math.max(min * 2, 8192);
            AudioRecord r = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                r.release();
                return false;
            }
            ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
            final OutputStream o = new ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]);
            rec = r;
            out = o;
            go = true;
            r.startRecording();
            Thread t = new Thread(() -> {
                byte[] buf = new byte[4096];
                long start = System.currentTimeMillis(), lastLoud = 0;
                boolean spoke = false;
                double floor = 300; // how loud the room is when nobody speaks
                try {
                    while (go) {
                        int n = r.read(buf, 0, buf.length);
                        if (n < 0) break;
                        if (n == 0) continue;
                        o.write(buf, 0, n);
                        // The recogniser only gives its final answer when the audio ENDS, so end it when the person stops talking.
                        double sum = 0;
                        for (int i = 0; i + 1 < n; i += 2) {
                            short v = (short) ((buf[i + 1] << 8) | (buf[i] & 0xff));
                            sum += (double) v * v;
                        }
                        double rms = Math.sqrt(sum / (n / 2));
                        long now = System.currentTimeMillis();
                        boolean loud = rms > Math.max(500, floor * 2.2);
                        if (loud) {
                            spoke = true;
                            lastLoud = now;
                        } else {
                            floor = 0.95 * floor + 0.05 * rms;
                        }
                        if (spoke && now - lastLoud > 1200) break; // finished talking
                        if (!spoke && now - start > 9000) break;   // nobody spoke
                        if (now - start > 20000) break;            // never listen forever (a reel playing is "loud" all the time)
                    }
                } catch (Exception ignored) {
                    // the recogniser closed its end: this round is over
                } finally {
                    try { o.close(); } catch (Exception ignored) { /* already closed */ }
                }
            }, "luna-ear");
            t.setDaemon(true);
            t.start();
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0]);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT);
            intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, RATE);
            return true;
        } catch (Throwable e) {
            stop();
            return false;
        }
    }

    /** Stops recording and closes the pipe. Safe to call any number of times. */
    void stop() {
        go = false;
        AudioRecord r = rec;
        rec = null;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) { /* not started */ }
            try { r.release(); } catch (Exception ignored) { /* already released */ }
        }
        OutputStream o = out;
        out = null;
        if (o != null) {
            try { o.close(); } catch (Exception ignored) { /* already closed */ }
        }
    }
}
