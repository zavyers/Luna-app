package com.luna.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

/**
 * Sends a message to someone in a chat app that has no "send to this person" link (Instagram, Snapchat, Telegram, Messenger,
 * Signal): opens the app, searches for the person, opens the chat, types the words and presses Send, the way you would.
 *
 * Best effort: these apps change their screens often, so if Luna gets stuck she says where, and the message is already
 * copied so you can paste it. Needs Luna phone control (Accessibility).
 */
final class ChatSend {
    private ChatSend() { }

    private static final String[][] APPS = {
            {"instagram", "Instagram"}, {"snapchat", "Snapchat"}, {"telegram", "Telegram"}, {"messenger", "Messenger"}, {"signal", "Signal"}};

    static boolean supports(String via) {
        for (String[] a : APPS) if (a[0].equals(via)) return true;
        return false;
    }

    static String label(String via) {
        for (String[] a : APPS) if (a[0].equals(via)) return a[1];
        return via;
    }

    /** The button that opens the list of chats, in apps that start somewhere else (feed, camera). */
    private static String[] inbox(String via) {
        switch (via) {
            case "instagram": return new String[]{"Messages", "Message", "Messenger", "Direct", "Inbox"};
            case "snapchat": return new String[]{"Chat", "Chats"};
            default: return new String[0];
        }
    }

    static String send(Context ctx, String via, final String person, final String text) {
        if (LunaAccessibilityService.instance == null) {
            return "error: turn on Luna phone control in Luna's settings first, so I can use " + label(via) + " for you";
        }
        String pkg = PhoneActions.packageFor(ctx, label(via));
        if (pkg == null) return "error: " + label(via) + " isn't installed on this phone";
        try { // so that if I get stuck, one paste finishes the job
            ((ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Luna", text));
        } catch (Exception ignored) {
            // not allowed right now: carry on
        }
        String opened = PhoneActions.launchPackage(ctx, pkg, label(via));
        if (!opened.startsWith("ok")) return opened;
        final String[] box = inbox(via);
        Macro m = new Macro(ctx, "I sent your " + label(via) + " message to " + person + ".",
                "I opened " + label(via) + " but got stuck at %s. Your message is copied, so you can paste it for " + person + ".")
                .step("opening the app", false, 1, 2800, () -> "ok");
        if ("instagram".equals(via)) {
            // Instagram: go through the inbox and its search bar, never the "New message" screen
            m.step("leaving the new message screen", false, 1, 700, () -> {
                if (LunaAccessibilityService.onScreen("New message")) LunaAccessibilityService.back();
                return "ok";
            });
            m.step("opening your inbox", true, 4, 1300, () -> {
                if (LunaAccessibilityService.onScreen("Primary", "Requests")) return "ok: already in the inbox";
                return LunaAccessibilityService.tapExact(box, "new message", "explore");
            });
            m.step("the inbox search bar", true, 4, 1500, () -> LunaAccessibilityService.typeIntoOnly(person, "search"))
                    .step("finding " + person.trim().split("\\s+")[0], true, 5, 1800, () -> LunaAccessibilityService.tapPerson(person))
                    .step("typing the message", true, 4, 700, () -> LunaAccessibilityService.typeInto(text, "message", "send a chat", "write", "chat"))
                    .step("the send button", true, 4, 600, () -> LunaAccessibilityService.tapLabel("Send"))
                    .run();
            return "ok: sending your " + label(via) + " message to " + person;
        }
        if (box.length > 0) m.step("opening your chats", false, 3, 1200, () -> LunaAccessibilityService.tapLabel(box));
        m.step("the search button", false, 3, 900, () -> LunaAccessibilityService.tapLabel("Search", "Search for people", "Find"))
                .step("typing the name", true, 4, 2000, () -> LunaAccessibilityService.typeInto(person, "search", "find", "to:"))
                .step("finding " + person.trim().split("\\s+")[0], true, 5, 1800, () -> LunaAccessibilityService.tapPerson(person))
                .step("typing the message", true, 4, 700, () -> LunaAccessibilityService.typeInto(text, "message", "send a chat", "write", "chat"))
                .step("the send button", true, 4, 600, () -> LunaAccessibilityService.tapLabel("Send"))
                .run();
        return "ok: sending your " + label(via) + " message to " + person;
    }
}
