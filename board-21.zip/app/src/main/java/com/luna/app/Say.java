package com.luna.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.Locale;

/** Says one sentence out loud, even when the background listening service isn't running, then lets go of the speech engine. */
final class Say {
    private Say() { }

    static void once(Context ctx, final String text, final String lang) {
        if (text == null || text.trim().isEmpty()) return;
        final Context app = ctx.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        final TextToSpeech[] holder = new TextToSpeech[1];
        holder[0] = new TextToSpeech(app, status -> {
            final TextToSpeech t = holder[0];
            if (t == null) return;
            if (status != TextToSpeech.SUCCESS) {
                t.shutdown();
                return;
            }
            try {
                t.setAudioAttributes(Duck.voiceAttributes());
                Locale want = Locale.forLanguageTag(lang == null || lang.isEmpty() ? "en-US" : lang);
                if (t.setLanguage(want) < TextToSpeech.LANG_AVAILABLE) t.setLanguage(Locale.US);
                t.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { main.post(t::shutdown); }
                    @Override public void onError(String utteranceId) { main.post(t::shutdown); }
                });
                t.speak(text.length() > 600 ? text.substring(0, 600) : text, TextToSpeech.QUEUE_FLUSH, null, "say" + System.nanoTime());
                main.postDelayed(t::shutdown, 20000); // never keep the engine longer than this
            } catch (Exception e) {
                t.shutdown();
            }
        });
    }
}
