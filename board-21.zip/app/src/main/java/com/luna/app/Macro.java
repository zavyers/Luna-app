package com.luna.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * A short list of screen steps Luna carries out in another app (tap, type, wait), each retried a few times because apps are slow.
 * An optional step that never works is skipped; a required one that never works stops the macro and Luna says where she got stuck.
 */
final class Macro {
    private static final class Step {
        final String name;
        final boolean required;
        final int tries;
        final long gap;
        final Supplier<String> act;

        Step(String name, boolean required, int tries, long gap, Supplier<String> act) {
            this.name = name;
            this.required = required;
            this.tries = tries;
            this.gap = gap;
            this.act = act;
        }
    }

    private final Context ctx;
    private final String done, stuck;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Step> steps = new ArrayList<>();
    private int at = 0, attempt = 0;

    /** @param done what Luna says at the end; @param stuck what she says when stuck, "%s" being the step she could not do */
    Macro(Context ctx, String done, String stuck) {
        this.ctx = ctx;
        this.done = done;
        this.stuck = stuck;
    }

    /** An act returns "ok..." when it worked. gap is the pause (ms) after it, for the app to catch up. */
    Macro step(String name, boolean required, int tries, long gap, Supplier<String> act) {
        steps.add(new Step(name, required, tries, gap, act));
        return this;
    }

    void run() {
        if (at >= steps.size()) {
            Calls.tell(ctx, done);
            return;
        }
        Step s = steps.get(at);
        String r;
        try {
            r = s.act.get();
        } catch (Throwable e) {
            r = "error";
        }
        if (r.startsWith("ok")) {
            at++;
            attempt = 0;
            h.postDelayed(this::run, s.gap);
        } else if (++attempt < s.tries) {
            h.postDelayed(this::run, 900);
        } else if (!s.required) {
            at++;
            attempt = 0;
            h.postDelayed(this::run, 300);
        } else {
            Calls.tell(ctx, stuck.replace("%s", s.name));
        }
    }
}
