package com.luna.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.os.Bundle;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

/**
 * Keeps Luna listening while another app is on screen. Only runs when the person switches
 * "keep listening in the background" on, and always shows a notification while it does.
 */
public class ListenService extends Service {
    static volatile ListenService instance;
    static volatile boolean activityVisible = true;

    private static final int NOTIF_ID = 42;
    private static final String CHANNEL = "luna_listening";

    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer rec;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean busy = false;
    private boolean running = false;
    private boolean stopped = false;
    private Locale ttsLocale = null;
    private final Ear ear = new Ear();
    private Duck duck;
    private boolean usingEar = false;
    private boolean voiceMale = false;
    private boolean heardSpeech = false;
    private boolean ready = false;       // the recogniser said it is ready to hear
    private boolean gotRms = false;      // the recogniser measured sound, so it is really receiving audio
    private int session = 0;             // which listening round we are in (so old timers can tell they are stale)
    private long busySince = 0;
    /** Safety net: wakes the listener up if anything ever forgot to, and frees it if it got stuck "busy". */
    private final Runnable beat = new Runnable() {
        @Override public void run() {
            if (stopped) return;
            if (busy && System.currentTimeMillis() - busySince > 45000) { // speech or thinking never finished
                busy = false;
                if (duck != null) duck.up();
                hudIdle();
            }
            maybeListen();
            main.postDelayed(this, 6000);
        }
    };
    private boolean spoke = false;
    private long awakeUntil = 0;       // while this is in the future, Luna is waiting for you to speak (follow-up window)
    private String thinkText = "";
    private final Runnable thinkRun = () -> {
        if (busy && !stopped && !isMuted()) Overlay.show(this, Overlay.THINKING, thinkText);
    };
    private final Runnable idleCheck = this::hudIdle;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        duck = new Duck(this);
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        startSpeech(null);
        main.postDelayed(this::maybeListen, 800);
        main.postDelayed(beat, 6000);
        main.postDelayed(this::pollPending, 4000);
        // get the engine and the app list ready now, so the first spoken request isn't slow
        PhoneActions.warmUp(this);
        new Thread(() -> {
            try {
                engine();
            } catch (Throwable ignored) {
                // it will be started again when needed
            }
        }).start();
    }

    private void startSpeech(final String engine) {
        final TextToSpeech[] made = new TextToSpeech[1];
        TextToSpeech.OnInitListener init = status -> {
            if (status != TextToSpeech.SUCCESS) {
                try { if (made[0] != null) made[0].shutdown(); } catch (Exception ignored) { /* gone */ }
                if (engine == null) main.post(() -> startSpeech("com.google.android.tts")); // default engine is off: try Google's
                return;
            }
            tts = made[0];
            ttsReady = true;
            tts.setAudioAttributes(Duck.voiceAttributes()); // quiet the reel while I talk, don't stop it
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { main.post(ListenService.this::finishTurn); }
                @Override public void onError(String utteranceId) { main.post(ListenService.this::speechFailed); }
            });
        };
        made[0] = engine == null ? new TextToSpeech(this, init) : new TextToSpeech(this, init, engine);
    }

    private String lunaName() {
        return getSharedPreferences("luna", MODE_PRIVATE).getString("name", "Luna");
    }

    /** Between things: show "listening" while the follow-up window is open (you can talk without saying Hey Luna), otherwise nothing. */
    private void hudIdle() {
        main.removeCallbacks(idleCheck);
        if (busy) return; // thinking or speaking has its own box; finishTurn() comes back here
        long left = awakeUntil - System.currentTimeMillis();
        if (stopped || isMuted() || (activityVisible && !callWindow()) || left <= 0) {
            Overlay.hide();
            return;
        }
        Overlay.show(this, Overlay.LISTENING, lunaName());
        main.postDelayed(idleCheck, left + 60);
    }

    private boolean isMuted() {
        return getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false);
    }

    /** Another app (a video, a reel, music) is playing sound. Listening then would take the sound away from it. */
    private boolean otherAudioPlaying() {
        if (Ear.supported()) return false; // my own recording never takes the sound away, so there is nothing to wait for
        if (getSharedPreferences("luna", MODE_PRIVATE).getBoolean("listen_during_media", false)) return false;
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        return am != null && am.isMusicActive();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "MUTE".equals(intent.getAction())) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("muted", !isMuted()).apply();
            syncState();
            return START_STICKY;
        }
        if (intent != null && "STOP".equals(intent.getAction())) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("background", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopped = true;
        instance = null;
        Overlay.hide();
        ear.stop();
        if (duck != null) duck.up();
        main.removeCallbacksAndMessages(null);
        if (rec != null) {
            rec.destroy();
            rec = null;
        }
        if (tts != null) {
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW));
        }
        String name = getSharedPreferences("luna", MODE_PRIVATE).getString("name", "Luna");
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, ListenService.class).setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 3, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent mute = new Intent(this, ListenService.class).setAction("MUTE");
        PendingIntent mutePi = PendingIntent.getService(this, 4, mute, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean muted = isMuted();
        b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(muted ? name + " is muted" : name + " is listening")
                .setContentText(muted ? "The microphone is off. Tap Unmute to talk to me." : "Say “Hey " + name + "” while using any app")
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(R.mipmap.ic_launcher, muted ? "Unmute" : "Mute", mutePi)
                .addAction(R.mipmap.ic_launcher, "Stop", stopPi);
        return b.build();
    }

    // ------------------------------------------------------------------ listening

    /** Called when Luna's screen appears or disappears. */
    static void refresh() {
        final ListenService s = instance;
        if (s != null) s.main.post(s::syncState);
    }

    private void syncState() {
        if (isMuted() || (activityVisible && !callWindow())) Overlay.hide();
        try {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF_ID, buildNotification());
        } catch (Exception ignored) {
            // the notification text is only a courtesy
        }
        if (isMuted()) {
            if (running && rec != null) {
                rec.cancel();
                running = false;
            }
            ear.stop();
            return;
        }
        if (activityVisible && !callWindow()) {
            if (running && rec != null) {
                rec.cancel();
                running = false;
            }
            ear.stop();
        } else {
            maybeListen();
        }
    }

    private void maybeListen() {
        if (stopped || (activityVisible && !callWindow()) || busy || running) return;
        if (isMuted()) return; // the mute button means the microphone is really off
        if (otherAudioPlaying()) {
            // a video or music is playing in another app: wait instead of silencing it, and look again soon
            main.postDelayed(this::maybeListen, 2500);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this);
            rec.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { ready = true; }
                @Override public void onBeginningOfSpeech() { heardSpeech = true; if (usingEar) Ear.worked(); }
                @Override public void onRmsChanged(float rmsdB) { gotRms = true; }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onResults(Bundle results) {
                    running = false;
                    ear.stop();
                    if (usingEar) Ear.worked();
                    if (isMuted()) return; // the mute button was pressed while I was listening: throw it away
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list == null || list.isEmpty() || list.get(0).trim().isEmpty()) {
                        main.postDelayed(ListenService.this::maybeListen, 300);
                    } else {
                        handle(list.get(0));
                    }
                }

                @Override
                public void onError(int error) {
                    running = false;
                    ear.stop();
                    if (usingEar && !heardSpeech && !ready && !gotRms) {
                        Ear.refused(); // this phone's recogniser never started on my recording: fall back to the normal way
                    }
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return;
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                            || error == SpeechRecognizer.ERROR_TOO_MANY_REQUESTS) {
                        resetRecognizer(); // a wedged recogniser never recovers by itself: make a fresh one
                    }
                    long wait = (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) ? 300 : 3000;
                    main.postDelayed(ListenService.this::maybeListen, wait);
                }
            });
        }
        String lang = getSharedPreferences("luna", MODE_PRIVATE).getString("lang", "en-US");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        usingEar = ear.attach(this, intent);
        heardSpeech = false;
        ready = false;
        gotRms = false;
        running = true;
        final int mine = ++session;
        rec.startListening(intent);
        main.postDelayed(() -> { // never started on my recording within a few seconds: that is the stuck case
            if (running && session == mine && !ready && !gotRms && !heardSpeech) {
                if (usingEar) Ear.refused();
                restartListening();
            }
        }, 6000);
        main.postDelayed(() -> { // one listening round never lasts this long: it is hung
            if (running && session == mine) restartListening();
        }, 30000);
    }

    private void restartListening() {
        running = false;
        ear.stop();
        resetRecognizer();
        main.postDelayed(this::maybeListen, 300);
    }

    private void resetRecognizer() {
        try {
            if (rec != null) {
                rec.cancel();
                rec.destroy();
            }
        } catch (Exception ignored) {
            // already gone
        }
        rec = null;
        running = false;
    }

    private PyObject engine() {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        PyObject module = Python.getInstance().getModule("luna_android");
        module.callAttr("start", getFilesDir().getAbsolutePath() + "/luna"); // does nothing if already started
        return module;
    }

    private void handle(final String text) {
        if (isMuted()) { finishTurn(); return; }
        busy = true;
        busySince = System.currentTimeMillis();
        thinkText = text.length() > 70 ? text.substring(0, 70) + "…" : text;
        // chatter that isn't for Luna is dropped in a few milliseconds; only real work shows the "thinking" box
        main.removeCallbacks(thinkRun);
        main.postDelayed(thinkRun, 350);
        new Thread(() -> {
            String out = "";
            try {
                PyObject eng = engine();
                if (callWindow()) {
                    String verdict = eng.callAttr("call_reply", text).toString(); // accept, decline or ""
                    if ("accept".equals(verdict) || "decline".equals(verdict)) {
                        main.post(() -> onCallVerdict(verdict));
                        return;
                    }
                }
                out = eng.callAttr("heard", text).toString();
            } catch (Throwable ignored) {
                // the engine is not ready; just listen again
            }
            final String json = out;
            main.post(() -> onReply(json));
        }).start();
    }

    // ------------------------------------------------------------------ a call is ringing

    private static volatile long callUntil = 0;

    static boolean callWindow() {
        return System.currentTimeMillis() < callUntil;
    }

    /** The call stopped ringing (answered, declined, or the caller gave up). */
    static void callEnded() {
        callUntil = 0;
        final ListenService s = instance;
        if (s != null) s.main.post(s::syncState);
    }

    private static boolean hindi(Context c) {
        return c.getSharedPreferences("luna", MODE_PRIVATE).getString("lang", "en-US").startsWith("hi");
    }

    private static String callLine(String who, String app, boolean video, boolean ask, boolean hi) {
        String name = CallWatcher.spokenCaller(who);
        String line;
        if (hi) {
            line = name + (app.isEmpty() ? "" : " का " + app) + " " + (video ? "वीडियो कॉल" : "कॉल") + " आ रहा है।";
            if (ask) line += " उठाऊँ या काट दूँ?";
        } else {
            line = name + " is " + (video ? "video calling you" : "calling") + (app.isEmpty() ? "" : " on " + app) + ".";
            if (ask) line += " Do you want to accept or decline?";
        }
        return line;
    }

    /** Tells the person about a call the moment it starts ringing, screen on or off, and asks what to do. */
    static void announceCall(final Context ctx, final String who, final String app, final boolean video) {
        callUntil = System.currentTimeMillis() + 90000L;
        final ListenService s = instance;
        if (s == null) { // the listening service isn't running: still say who it is
            boolean hi = hindi(ctx);
            Say.once(ctx, callLine(who, app, video, false, hi), hi ? "hi-IN" : "en-US");
            return;
        }
        s.main.post(() -> s.speakCall(who, app, video, 0));
    }

    private void speakCall(final String who, final String app, final boolean video, int round) {
        if (stopped || !CallWatcher.ringing()) return;
        boolean hi = hindi(this);
        boolean canAsk = !isMuted() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        String line = round == 0 ? callLine(who, app, video, canAsk, hi) : (hi ? "उठाऊँ या काट दूँ?" : "Accept or decline?");
        MainActivity.pauseWebListening(); // if Luna's own screen is open, its microphone must not fight for the answer
        speak(line, hi ? "hi-IN" : "en-US", 1.05f, 1.05f);
        if (canAsk && round < 2) { // still ringing and nobody answered: ask again, briefly
            final int next = round + 1;
            main.postDelayed(() -> {
                if (CallWatcher.ringing() && !busy) speakCall(who, app, video, next);
            }, 14000);
        }
    }

    private void onCallVerdict(String verdict) {
        main.removeCallbacks(thinkRun);
        boolean accept = "accept".equals(verdict);
        String res = accept ? CallWatcher.answer(this) : CallWatcher.decline(this);
        callUntil = 0;
        boolean hi = hindi(this);
        if (res.startsWith("error")) {
            String why = res.replaceFirst("^error:?\\s*", "");
            speak("Sorry, I couldn't " + (accept ? "answer" : "decline") + " it. " + why + ".", "en-US", 1.1f, 1.05f);
        } else if (accept) {
            // say nothing: the other person might hear me over the call. A short beep is enough.
            final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80);
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 200);
            main.postDelayed(tone::release, 600);
            finishTurn();
        } else {
            speak(hi ? "ठीक है, काट दिया।" : "Okay, declined.", hi ? "hi-IN" : "en-US", 1.05f, 1.05f);
        }
    }

    /** Says something now from outside (for example, after a message has been sent). */
    static void sayNow(final String text) {
        final ListenService s = instance;
        if (s != null) s.main.post(() -> s.speak(text, "en-US", 1.1f, 1.05f));
    }

    private void onReply(String json) {
        main.removeCallbacks(thinkRun);
        if (isMuted()) { // muted while I was thinking: stay silent
            finishTurn();
            return;
        }
        try {
            JSONObject r = new JSONObject(json);
            String state = r.optString("state");
            if ("awake".equals(state)) {
                awakeUntil = System.currentTimeMillis() + 12000L; // "Hey Luna" heard: show that she is listening
                // say it out loud: a 0.2 second beep is easy to miss, and then it feels like she didn't hear
                speak(hindi(this) ? "जी?" : "Yes?", hindi(this) ? "hi-IN" : "en-US", 1.1f, 1.1f);
                return;
            }
            if (!"reply".equals(state)) {
                finishTurn();
                return;
            }
            JSONArray actions = r.optJSONArray("actions");
            String problem = "";
            if (actions != null) {
                for (int i = 0; i < actions.length(); i++) {
                    String res = PhoneActions.run(this, actions.getJSONObject(i));
                    if (res != null && res.startsWith("error") && problem.isEmpty()) problem = res.replaceFirst("^error:?\\s*", "");
                }
            }
            String say = r.optString("speak");
            if (!problem.isEmpty()) say = "Sorry, I couldn't do that. " + problem + ".";
            JSONArray confirm = r.optJSONArray("confirm");
            if (confirm != null && confirm.length() > 0) say += " That needs your OK, so please open the app.";
            if (say.trim().isEmpty()) {
                finishTurn();
            } else {
                speak(say, r.optString("lang", "en-US"), (float) r.optDouble("pitch", 1.1), (float) r.optDouble("rate", 1.05));
            }
        } catch (Exception e) {
            finishTurn();
        }
    }

    private void finishTurn() {
        busy = false;
        main.removeCallbacks(thinkRun);
        if (duck != null) duck.up();
        if (spoke) {
            spoke = false;
            // the follow-up window starts when I finish talking, not when I start
            new Thread(() -> {
                double seconds = 12;
                try { seconds = engine().callAttr("keep_awake").toDouble(); } catch (Throwable ignored) { /* not ready */ }
                final long until = System.currentTimeMillis() + (long) (seconds * 1000);
                main.post(() -> {
                    awakeUntil = until;
                    hudIdle();
                });
            }).start();
        } else {
            hudIdle();
        }
        main.postDelayed(this::maybeListen, 400);
    }

    // --------------------------------------------------------------------- speaking

    private String lastSay = "";
    private boolean retriedSay = false;

    /** The chosen voice could not play: say it again once with the phone's default voice, then give up quietly. */
    private void speechFailed() {
        if (!retriedSay && tts != null && !lastSay.isEmpty()) {
            retriedSay = true;
            ttsLocale = null;
            Voices.useDefault(tts);
            int r = tts.speak(lastSay, TextToSpeech.QUEUE_FLUSH, null, "retry" + System.nanoTime());
            if (r == TextToSpeech.SUCCESS) return;
        }
        finishTurn();
    }

    private void speak(String text, String lang, float pitch, float rate) {
        if (!ttsReady || tts == null) {
            finishTurn();
            return;
        }
        retriedSay = false;
        busy = true;
        busySince = System.currentTimeMillis();
        spoke = true;
        main.removeCallbacks(thinkRun);
        main.removeCallbacks(idleCheck);
        if (!isMuted() && !(activityVisible && !callWindow())) Overlay.show(this, Overlay.SPEAKING, text);
        if (running && rec != null) {
            rec.cancel();
            running = false;
        }
        ear.stop();
        duck.down();
        Locale want = Locale.forLanguageTag(lang);
        if (Voices.male(this) != voiceMale) { // the person switched between Voice 1 and Voice 2
            voiceMale = Voices.male(this);
            ttsLocale = null;
        }
        if (!want.equals(ttsLocale)) {
            int r = tts.setLanguage(want);
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                ttsLocale = want;
                Voices.choose(tts, want, Voices.male(this));
            }
        }
        tts.setPitch(Voices.pitch(this, pitch));
        tts.setSpeechRate(rate);
        String say = text.length() > 3500 ? text.substring(0, 3500) : text;
        lastSay = say;
        int result = tts.speak(say, TextToSpeech.QUEUE_FLUSH, null, "bg" + System.nanoTime());
        if (result != TextToSpeech.SUCCESS) speechFailed();
    }

    static void speakReminder(final String title) {
        final ListenService s = instance;
        if (s != null) s.main.post(() -> s.speak("Reminder, sir: " + title, "en-US", 1.1f, 1.05f));
    }

    // ------------------------------------------------- orders from the paired laptop

    private void pollPending() {
        if (stopped) return;
        if (!activityVisible) {
            new Thread(() -> {
                try {
                    final JSONArray list = new JSONArray(engine().callAttr("pending").toString());
                    if (list.length() == 0) return;
                    main.post(() -> {
                        try {
                            for (int i = 0; i < list.length(); i++) PhoneActions.run(ListenService.this, list.getJSONObject(i));
                        } catch (Exception ignored) {
                            // skip a bad order
                        }
                    });
                } catch (Throwable ignored) {
                    // not ready yet
                }
            }).start();
        }
        main.postDelayed(this::pollPending, 3000);
    }
}
