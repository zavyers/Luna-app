package com.luna.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

/** The phone's last known position, for the weather. Needs "location" allowed for Luna. */
final class Where {
    private Where() { }

    static String now(Context ctx) {
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return "error: location is not allowed for Luna";
        }
        LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        for (String provider : lm.getProviders(true)) {
            try {
                Location l = lm.getLastKnownLocation(provider);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            } catch (SecurityException ignored) {
                // not allowed for this provider
            }
        }
        return best == null ? "error: no position yet" : "ok:" + best.getLatitude() + "," + best.getLongitude() + "," + Math.round(best.getAccuracy());
    }
}
