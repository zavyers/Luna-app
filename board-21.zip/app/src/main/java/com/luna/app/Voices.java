package com.luna.app;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.Locale;
import java.util.Set;

/** Picks Luna's voice: "Voice 1" is the best female voice for the language, "Voice 2" a male one (lower pitched when the phone has no male voice). */
final class Voices {
    private Voices() { }

    static boolean male(Context ctx) {
        return "male".equals(ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).getString("voice_kind", "female"));
    }

    /** Deeper for Voice 2, so it always sounds different even on phones that only ship one voice. */
    static float pitch(Context ctx, float pitch) {
        return male(ctx) ? pitch * 0.8f : pitch;
    }

    /** Goes back to the phone's own default voice (used when the chosen voice fails to play). */
    static void useDefault(TextToSpeech tts) {
        try {
            Voice d = tts.getDefaultVoice();
            if (d != null) tts.setVoice(d);
        } catch (Exception ignored) {
            // keep whatever is set
        }
    }

    static void choose(TextToSpeech tts, Locale want, boolean male) {
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Voice v : all) {
                if (!v.getLocale().getLanguage().equals(want.getLanguage())) continue;
                Set<String> feats = v.getFeatures();
                if (feats != null && feats.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue; // voice data missing: it would be silent
                String name = v.getName().toLowerCase(Locale.ROOT);
                boolean female = name.contains("female");
                boolean man = !female && name.contains("male");
                int score = male ? (man ? 5 : female ? -4 : 0) : (female ? 4 : man ? -5 : 0);
                if (!v.isNetworkConnectionRequired()) score += 1;
                if (v.getLocale().equals(want)) score += 1;
                if (score > bestScore) {
                    best = v;
                    bestScore = score;
                }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) {
            // keep the phone's default voice
        }
    }
}
