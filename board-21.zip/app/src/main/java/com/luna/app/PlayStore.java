package com.luna.app;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** "Install Spotify": opens Google Play's search, opens the app's page and presses Install. Needs Luna phone control. */
final class PlayStore {
    private PlayStore() { }

    static String install(Context ctx, final String name) {
        if (LunaAccessibilityService.instance == null) return "error: turn on Luna phone control in Luna's settings first, so I can press Install for you";
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(name) + "&c=apps")).setPackage("com.android.vending");
        String opened = PhoneActions.open(ctx, i, "Google Play is open");
        if (!opened.startsWith("ok")) return "error: Google Play isn't available on this phone";
        new Macro(ctx, "I pressed Install for " + name + ". It downloads in the background.",
                "I opened Google Play for " + name + " but got stuck at %s. Please press Install yourself.")
                .step("loading the search", false, 1, 3500, () -> "ok")
                .step("opening the app page", true, 5, 3500, () -> LunaAccessibilityService.tapPerson(name))
                .step("the Install button", true, 6, 1500, () -> LunaAccessibilityService.tapLabel("Install", "Get"))
                .run();
        return "ok: installing " + name + " from Google Play";
    }
}
