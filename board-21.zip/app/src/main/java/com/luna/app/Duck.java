package com.luna.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;

/**
 * While Luna speaks, other apps (a reel, a video, music) get quieter and come back to full volume afterwards.
 * Without this, speaking either talks over them at full volume or makes them pause.
 */
final class Duck {
    private final AudioManager am;
    private AudioFocusRequest request;
    private boolean held;

    Duck(Context ctx) {
        am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
    }

    static AudioAttributes voiceAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    synchronized void down() {
        if (held || am == null) return;
        try {
            int r;
            if (Build.VERSION.SDK_INT >= 26) {
                request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(voiceAttributes())
                        .setWillPauseWhenDucked(false)
                        .setOnAudioFocusChangeListener(change -> { })
                        .build();
                r = am.requestAudioFocus(request);
            } else {
                r = am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
            held = r == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        } catch (Exception ignored) {
            // speaking still works without ducking
        }
    }

    synchronized void up() {
        if (!held || am == null) return;
        held = false;
        try {
            if (Build.VERSION.SDK_INT >= 26 && request != null) am.abandonAudioFocusRequest(request);
            else am.abandonAudioFocus(null);
        } catch (Exception ignored) {
            // nothing to give back
        }
        request = null;
    }
}
