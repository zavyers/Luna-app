package com.luna.app;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.telecom.TelecomManager;

import java.util.Locale;

/**
 * Notices a call that is ringing (a normal phone call or a WhatsApp call) from its notification, tells the person
 * straight away who it is, and can answer or decline it. Answering uses the same Answer / Decline buttons that the
 * phone's own call notification has; for a normal call, if that isn't possible, the phone's call service is asked
 * (needs "Answer phone calls" to be allowed). Works with the screen on or off.
 * Needs "Notification access" for Luna, the same switch that lets her read messages.
 */
public final class CallWatcher {
    private CallWatcher() { }

    static final class Call {
        String key, pkg, app, who;
        boolean video, whatsapp;
        PendingIntent answer, decline;
        long since;
    }

    private static final long MAX_RING_MS = 90000L;
    private static final String[] ANSWER_WORDS = {"answer", "accept", "pick up", "pickup", "attend", "receive", "उत्तर", "जवाब", "स्वीकार", "उठाएं", "अटेंड"};
    private static final String[] DECLINE_WORDS = {"decline", "reject", "dismiss", "ignore", "refuse", "अस्वीकार", "खारिज", "काटें", "रिजेक्ट"};

    private static volatile Call current;

    static boolean ringing() {
        Call c = current;
        return c != null && System.currentTimeMillis() - c.since < MAX_RING_MS;
    }

    private static boolean has(String title, String[] words) {
        for (String w : words) if (title.contains(w)) return true;
        return false;
    }

    private static String text(Bundle ex, String key) {
        CharSequence c = ex.getCharSequence(key);
        return c == null ? "" : c.toString().trim();
    }

    private static boolean generic(String s) {
        String l = s.toLowerCase(Locale.ROOT);
        return l.isEmpty() || l.contains("incoming") || l.equals("call") || l.contains("calling") || l.contains("ringing");
    }

    private static boolean isPhoneApp(String pkg) {
        return pkg.contains("dialer") || pkg.contains("incallui") || pkg.contains("telecom") || pkg.equals("com.android.phone")
                || pkg.contains("contacts");
    }

    /** Called for every notification that is posted. Announces a call once, when it starts ringing. */
    static void onPosted(Context ctx, StatusBarNotification sbn) {
        try {
            Call c = parse(ctx, sbn);
            Call old = current;
            if (c == null) {
                // the same notification stopped being an incoming call: it was answered (or dropped)
                if (old != null && old.key.equals(sbn.getKey())) {
                    current = null;
                    ListenService.callEnded();
                }
                return;
            }
            long now = System.currentTimeMillis();
            if (old != null && now - old.since < MAX_RING_MS && (old.key.equals(c.key) || (old.who.equals(c.who) && now - old.since < 20000L))) {
                // an update of the call that is already ringing: keep its buttons fresh, don't announce it again
                if (c.answer != null) old.answer = c.answer;
                if (c.decline != null) old.decline = c.decline;
                return;
            }
            current = c;
            ListenService.announceCall(ctx, c.who, c.whatsapp ? "WhatsApp" : c.app, c.video);
        } catch (Throwable ignored) {
            // a strange notification must never break the listener
        }
    }

    static void onRemoved(StatusBarNotification sbn) {
        Call c = current;
        if (c != null && c.key.equals(sbn.getKey())) {
            current = null;
            ListenService.callEnded();
        }
    }

    private static Call parse(Context ctx, StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        String pkg = sbn.getPackageName();
        if (n == null || "com.luna.app".equals(pkg)) return null;
        Bundle ex = n.extras;
        if (ex == null) return null;
        int type = ex.getInt("android.callType", 0); // Android 12+: 1 incoming, 2 ongoing, 3 screening
        if (type == 2 || type == 3) return null;
        boolean callCategory = Notification.CATEGORY_CALL.equals(n.category);
        if (type == 0 && !callCategory && n.fullScreenIntent == null) return null;

        PendingIntent answer = null, decline = null;
        Notification.Action[] actions = n.actions;
        if (actions != null) {
            for (Notification.Action a : actions) {
                if (a == null || a.actionIntent == null) continue;
                String t = a.title == null ? "" : a.title.toString().toLowerCase(Locale.ROOT);
                if (answer == null && has(t, ANSWER_WORDS)) answer = a.actionIntent;
                else if (decline == null && has(t, DECLINE_WORDS)) decline = a.actionIntent;
            }
            if (type == 1 && actions.length >= 2) { // Android's call style always lists Decline first, then Answer
                if (decline == null && actions[0] != null) decline = actions[0].actionIntent;
                if (answer == null && actions[1] != null) answer = actions[1].actionIntent;
            }
        }
        boolean incoming = type == 1 || (answer != null && decline != null && (callCategory || n.fullScreenIntent != null));
        if (!incoming) return null;

        String who = "";
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                Object person = ex.get("android.callPerson");
                if (person instanceof android.app.Person) {
                    CharSequence nm = ((android.app.Person) person).getName();
                    if (nm != null) who = nm.toString().trim();
                }
            }
        } catch (Throwable ignored) {
            // fall back to the title below
        }
        String title = text(ex, Notification.EXTRA_TITLE);
        String body = text(ex, Notification.EXTRA_TEXT);
        if (generic(who)) who = generic(title) ? body : title;
        if (generic(who)) who = "";

        Call c = new Call();
        c.key = sbn.getKey();
        c.pkg = pkg;
        c.whatsapp = pkg.startsWith("com.whatsapp");
        c.video = (title + " " + body).toLowerCase(Locale.ROOT).contains("video");
        c.who = who;
        c.answer = answer;
        c.decline = decline;
        c.since = System.currentTimeMillis();
        String app = "";
        if (!c.whatsapp && !isPhoneApp(pkg)) {
            try {
                PackageManager pm = ctx.getPackageManager();
                app = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
            } catch (Exception e) {
                app = "";
            }
        }
        c.app = app;
        return c;
    }

    /** How a caller is said out loud: a name as it is, a bare number as "an unknown number ending 4 5 6 7". */
    static String spokenCaller(String who) {
        String digits = who == null ? "" : who.replaceAll("\\D", "");
        if (who == null || who.trim().isEmpty()) return "someone";
        if (digits.length() >= 5 && digits.length() * 2 >= who.replaceAll("[\\s+()-]", "").length()) {
            String end = digits.substring(digits.length() - 4);
            StringBuilder sb = new StringBuilder("an unknown number ending ");
            for (int i = 0; i < end.length(); i++) sb.append(end.charAt(i)).append(i < end.length() - 1 ? " " : "");
            return sb.toString();
        }
        return who;
    }

    static String answer(Context ctx) {
        return act(ctx, true);
    }

    static String decline(Context ctx) {
        return act(ctx, false);
    }

    @SuppressLint("MissingPermission")
    private static String act(Context ctx, boolean accept) {
        Call c = current;
        if (c == null) return "error: no call is ringing";
        String who = c.who.isEmpty() ? "the caller" : c.who;
        String done = "ok: " + (accept ? "answered" : "declined") + " the call from " + who;
        PendingIntent pi = accept ? c.answer : c.decline;
        if (pi != null) {
            try {
                Bundle opts = null;
                if (Build.VERSION.SDK_INT >= 34) {
                    ActivityOptions ao = ActivityOptions.makeBasic();
                    ao.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                    opts = ao.toBundle();
                }
                pi.send(ctx, 0, null, null, null, null, opts);
                finish();
                return done;
            } catch (Exception ignored) {
                // the button is no longer valid: try the phone's own call service below
            }
        }
        if (!c.whatsapp && Build.VERSION.SDK_INT >= 26) {
            try {
                if (ctx.checkSelfPermission("android.permission.ANSWER_PHONE_CALLS") == PackageManager.PERMISSION_GRANTED) {
                    TelecomManager tm = (TelecomManager) ctx.getSystemService(Context.TELECOM_SERVICE);
                    if (tm != null) {
                        if (accept) {
                            tm.acceptRingingCall();
                            finish();
                            return done;
                        }
                        if (Build.VERSION.SDK_INT >= 28 && tm.endCall()) {
                            finish();
                            return done;
                        }
                    }
                } else {
                    return "error: allow “Answer phone calls” in Luna's settings so I can " + (accept ? "answer" : "decline") + " calls";
                }
            } catch (Exception ignored) {
                // report below
            }
        }
        return "error: that call has no " + (accept ? "answer" : "decline") + " button I can press, so please do it on the screen";
    }

    private static void finish() {
        current = null;
        ListenService.callEnded();
    }
}
