package com.luna.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * The little box Luna floats at the top of whatever app is open, so you can see what she is doing:
 * "Luna is listening", "Luna is thinking" (with three bouncing dots) and "speaking" (with voice waves
 * and the words she is saying). It never takes touches, so the app underneath works as normal.
 *
 * It appears using Luna's phone-control permission, or "Display over other apps" if that is what was
 * allowed. With neither, it simply doesn't show (the sound and the notification still work).
 */
final class Overlay {
    private Overlay() { }

    static final String LISTENING = "listening";
    static final String THINKING = "thinking";
    static final String SPEAKING = "speaking";

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static Hud hud;
    private static WindowManager wm;
    private static WindowManager.LayoutParams lp;

    /** Shows (or changes) the box. Safe from any thread. `text` is the name for "listening", what you said for "thinking", the spoken words for "speaking". */
    static void show(Context ctx, final String state, final String text) {
        final Context app = ctx.getApplicationContext();
        if (Looper.myLooper() == Looper.getMainLooper()) showNow(app, state, text);
        else MAIN.post(() -> showNow(app, state, text));
    }

    static void hide() {
        if (Looper.myLooper() == Looper.getMainLooper()) hideNow();
        else MAIN.post(Overlay::hideNow);
    }

    private static String name(Context ctx) {
        return ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).getString("name", "Luna");
    }

    private static void showNow(Context app, String state, String text) {
        try {
            if (hud == null) {
                Context window = LunaAccessibilityService.instance;
                int type;
                if (window != null) {
                    type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
                } else if (Settings.canDrawOverlays(app)) {
                    window = app;
                    type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
                } else {
                    return; // no permission: stay invisible rather than fail
                }
                wm = (WindowManager) window.getSystemService(Context.WINDOW_SERVICE);
                Hud h = new Hud(app);
                h.set(state, text, name(app));
                lp = new WindowManager.LayoutParams(h.wantedWidth(), h.wantedHeight(), type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                        PixelFormat.TRANSLUCENT);
                lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                lp.y = h.topMargin();
                h.setAlpha(0f);
                wm.addView(h, lp);
                h.animate().alpha(1f).setDuration(160).start();
                hud = h;
                return;
            }
            hud.set(state, text, name(app));
            lp.width = hud.wantedWidth();
            lp.height = hud.wantedHeight();
            wm.updateViewLayout(hud, lp);
        } catch (Exception e) {
            hud = null; // the system refused the window: try again from scratch next time
        }
    }

    private static void hideNow() {
        Hud h = hud;
        hud = null;
        if (h == null || wm == null) return;
        try {
            wm.removeViewImmediate(h);
        } catch (Exception ignored) {
            // already gone
        }
    }

    /** The drawing of the box. */
    static final class Hud extends View {
        private static final int CYAN = 0xFF5EEAD4;
        private static final int BLUE = 0xFF60A5FA;
        private final float d;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint title = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint sub = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final long t0 = SystemClock.uptimeMillis();
        private String state = Overlay.LISTENING;
        private String text = "";
        private String who = "Luna";
        private StaticLayout words;
        private int wordsWidth = -1;

        Hud(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(0xF2081321);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(px(1.5f));
            accent.setStyle(Paint.Style.FILL);
            accent.setColor(CYAN);
            accent.setStrokeCap(Paint.Cap.ROUND);
            title.setColor(0xFFF1F5F9);
            title.setTextSize(px(15) );
            title.setFakeBoldText(true);
            sub.setColor(0xFF94A3B8);
            sub.setTextSize(px(13));
        }

        private float px(float dp) {
            return dp * d;
        }

        void set(String newState, String newText, String name) {
            state = newState;
            who = name == null || name.isEmpty() ? "Luna" : name;
            String t = newText == null ? "" : newText.trim();
            if (Overlay.LISTENING.equals(state)) t = "";
            text = t.length() > 160 ? t.substring(0, 160) + "…" : t;
            words = null;
            wordsWidth = -1;
            invalidate();
        }

        int wantedWidth() {
            DisplayMetrics m = getResources().getDisplayMetrics();
            return (int) Math.min(m.widthPixels - px(24), px(360));
        }

        int wantedHeight() {
            if (Overlay.SPEAKING.equals(state)) return (int) px(text.isEmpty() ? 62 : 108);
            if (Overlay.THINKING.equals(state)) return (int) px(text.isEmpty() ? 58 : 70);
            return (int) px(58);
        }

        int topMargin() {
            int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
            int bar = id > 0 ? getResources().getDimensionPixelSize(id) : (int) px(24);
            return bar + (int) px(6);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            stroke.setShader(new LinearGradient(0, 0, w, 0, CYAN, BLUE, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(px(26), h / 2f);
            RectF box = new RectF(px(1.5f), px(1.5f), w - px(1.5f), h - px(1.5f));
            c.drawRoundRect(box, r, r, fill);
            c.drawRoundRect(box, r, r, stroke);
            float s = (SystemClock.uptimeMillis() - t0) / 1000f;
            if (Overlay.LISTENING.equals(state)) drawListening(c, h, s);
            else if (Overlay.THINKING.equals(state)) drawThinking(c, h, s);
            else drawSpeaking(c, w, s);
            if (isAttachedToWindow()) postInvalidateOnAnimation();
        }

        private float centreBaseline(float cy, Paint p) {
            Paint.FontMetrics fm = p.getFontMetrics();
            return cy - (fm.ascent + fm.descent) / 2f;
        }

        private void drawListening(Canvas c, float h, float s) {
            float cy = h / 2f, cx = px(32);
            float pulse = (s % 1.4f) / 1.4f;
            Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(px(2));
            ring.setColor(CYAN);
            ring.setAlpha((int) (150 * (1f - pulse)));
            c.drawCircle(cx, cy, px(8) + pulse * px(13), ring);
            c.drawCircle(cx, cy, px(8), accent);
            c.drawText(who + " is listening", px(56), centreBaseline(cy, title), title);
            // a few small bars that breathe, so it feels alive
            for (int i = 0; i < 4; i++) {
                float a = 0.35f + 0.65f * Math.abs((float) Math.sin(s * 4f + i * 0.9f));
                float x = getWidth() - px(26) + i * px(5);
                c.drawLine(x, cy - a * px(9), x, cy + a * px(9), barPaint());
            }
        }

        private Paint barPaint() {
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(px(3));
            p.setColor(CYAN);
            return p;
        }

        private void drawThinking(Canvas c, float h, float s) {
            boolean two = !text.isEmpty();
            float cy = h / 2f;
            for (int i = 0; i < 3; i++) {
                float bounce = Math.abs((float) Math.sin(s * 5f - i * 0.7f)) * px(7);
                c.drawCircle(px(30) + i * px(15), cy + px(3) - bounce, px(4.5f), accent);
            }
            float x = px(88);
            if (two) {
                c.drawText(who + " is thinking…", x, cy - px(3), title);
                String line = TextUtils.ellipsize("“" + text + "”", sub, getWidth() - x - px(18), TextUtils.TruncateAt.END).toString();
                c.drawText(line, x, cy + px(17), sub);
            } else {
                c.drawText(who + " is thinking…", x, centreBaseline(cy, title), title);
            }
        }

        private void drawSpeaking(Canvas c, float w, float s) {
            float left = px(22), right = w - px(22);
            int n = 30;
            float step = (right - left) / (n - 1);
            Paint p = barPaint();
            float cy = px(28);
            for (int i = 0; i < n; i++) {
                float edge = (float) Math.sin(Math.PI * i / (n - 1)); // taller in the middle, like a voice
                float a = 0.18f + 0.82f * Math.abs((float) (Math.sin(s * 7f + i * 0.55f) * Math.cos(s * 2.3f + i * 0.21f)));
                float half = (px(3) + a * edge * px(19));
                c.drawLine(left + i * step, cy - half, left + i * step, cy + half, p);
            }
            if (text.isEmpty()) return;
            int width = (int) (w - px(36));
            if (words == null || wordsWidth != width) {
                words = StaticLayout.Builder.obtain(text, 0, text.length(), sub, width)
                        .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setAlignment(Layout.Alignment.ALIGN_CENTER).build();
                wordsWidth = width;
            }
            c.save();
            c.translate(px(18), px(60));
            words.draw(c);
            c.restore();
        }
    }
}
