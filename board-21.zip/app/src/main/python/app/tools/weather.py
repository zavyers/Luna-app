"""Accurate weather from Open-Meteo (free, no key). Where: the city you name, else the phone's own position (when Luna may
use location), else an approximate place from the internet connection, which Luna says out loud so you can name your city."""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional, Tuple

Place = Tuple[float, float, str, bool]  # latitude, longitude, name, approximate

_CODES = {0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "overcast", 45: "foggy", 48: "foggy", 51: "light drizzle", 53: "drizzle",
          55: "heavy drizzle", 56: "freezing drizzle", 57: "freezing drizzle", 61: "light rain", 63: "rain", 65: "heavy rain", 66: "freezing rain",
          67: "freezing rain", 71: "light snow", 73: "snow", 75: "heavy snow", 77: "snow grains", 80: "light showers", 81: "showers",
          82: "heavy showers", 85: "snow showers", 86: "heavy snow showers", 95: "a thunderstorm", 96: "a thunderstorm with hail", 99: "a thunderstorm with hail"}
_last_place: Optional[Place] = None


def _get(url: str, timeout: float = 8.0) -> Dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "Luna/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return json.loads(res.read().decode("utf-8"))


def geocode(city: str) -> Optional[Place]:
    data = _get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name=" + urllib.parse.quote(city))
    hit = (data.get("results") or [None])[0]
    if not hit:
        return None
    label = ", ".join(x for x in (hit.get("name"), hit.get("admin1"), hit.get("country")) if x)
    return float(hit["latitude"]), float(hit["longitude"]), label, False


def _name_of(lat: float, lon: float) -> str:
    try:
        d = _get(f"https://api.bigdatacloud.net/data/reverse-geocode-client?localityLanguage=en&latitude={lat}&longitude={lon}", 5)
        return ", ".join(x for x in (d.get("locality") or d.get("city"), d.get("principalSubdivision")) if x) or "your location"
    except Exception:
        return "your location"


def locate(phone: Any) -> Optional[Place]:
    global _last_place
    try:  # 1. the phone's own position
        raw = str(phone.location()) if phone is not None and hasattr(phone, "location") else ""
        if raw.startswith("ok:"):
            lat, lon = (float(x) for x in raw[3:].split(",")[:2])
            _last_place = (lat, lon, _name_of(lat, lon), False)
            return _last_place
    except Exception:
        pass
    try:  # 2. roughly, from the internet connection
        d = _get("https://ipwho.is/")
        if d.get("success"):
            _last_place = (float(d["latitude"]), float(d["longitude"]), ", ".join(x for x in (d.get("city"), d.get("region")) if x), True)
            return _last_place
    except Exception:
        pass
    return _last_place  # 3. the last place that worked


def _forecast(lat: float, lon: float) -> Dict[str, Any]:
    q = urllib.parse.urlencode({
        "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 2,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,precipitation",
        "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"})
    return _get("https://api.open-meteo.com/v1/forecast?" + q)


def _chance(p: Optional[float]) -> str:
    return "unknown" if p is None else "very likely" if p >= 70 else "quite possible" if p >= 40 else "unlikely"


def report(data: Dict[str, Any], label: str, mode: str = "now") -> str:
    cur, day = data["current"], data["daily"]
    i = 1 if mode == "tomorrow" else 0
    hi, lo = round(day["temperature_2m_max"][i]), round(day["temperature_2m_min"][i])
    rain = day["precipitation_probability_max"][i]
    what = _CODES.get(day["weather_code"][i], "mixed weather")
    if mode == "rain":
        return f"In {label}, rain today is {_chance(rain)}" + (f" ({round(rain)}% chance)" if rain is not None else "") + f". Right now it is {_CODES.get(cur['weather_code'], 'dry')}."
    if mode == "tomorrow":
        return f"Tomorrow in {label}: {what}, between {lo} and {hi} degrees" + (f", with a {round(rain)}% chance of rain." if rain is not None else ".")
    return (f"In {label} it is {round(cur['temperature_2m'])} degrees, feels like {round(cur['apparent_temperature'])}, {_CODES.get(cur['weather_code'], 'mixed weather')}. "
            f"Humidity {round(cur['relative_humidity_2m'])} percent, wind {round(cur['wind_speed_10m'])} kilometres per hour. "
            f"Today {lo} to {hi} degrees" + (f", rain {_chance(rain)}." if rain is not None else "."))


def answer(city: str, mode: str, phone: Any = None) -> str:
    """The spoken weather report. Never raises: a failure becomes a sentence."""
    try:
        place = geocode(city) if city else locate(phone)
        if place is None:
            return f"I couldn't find a place called {city}. Say the city name again." if city else "I can't tell where you are. Say it like “weather in Mumbai”."
        text = report(_forecast(place[0], place[1]), place[2] or "your area", mode)
        if place[3]:
            text += " That is for your approximate area, so say “weather in” and your city for exact numbers."
        return text
    except Exception:
        return "I couldn't reach the weather service. Check your internet connection and ask me again."
