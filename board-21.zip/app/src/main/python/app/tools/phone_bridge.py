"""Python's line to the Android app (Chaquopy). Only exists on a phone; tests use FakePhone.

Every method returns plain Python values and never raises: when the phone can't do something the
answer says so ("" / [] / "error: ..."), so Luna can report the truth instead of pretending.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List


class AndroidPhone:
    available = True
    error = ""   # the last time the link to the Java side failed (shown to the person instead of a wrong "not allowed")

    def _ctx(self) -> Any:
        from com.chaquo.python import Python  # type: ignore  # only inside the Android app
        return Python.getPlatform().getApplication()

    def _cls(self, name: str) -> Any:
        from java import jclass  # type: ignore
        return jclass("com.luna.app." + name)

    def find_app(self, name: str) -> str:
        """The label of the installed app that best matches `name`, or ''."""
        try:
            return str(self._cls("PhoneActions").findApp(self._ctx(), str(name)) or "")
        except Exception as e:
            self.error = f"{type(e).__name__}: {str(e)[:120]}"
            return ""

    def messages_enabled(self) -> bool:
        try:
            ok = bool(self._cls("NotificationStore").enabled(self._ctx()))
            self.error = ""
            return ok
        except Exception as e:
            self.error = f"{type(e).__name__}: {str(e)[:120]}"
            return False

    def recent_messages(self, limit: int = 5, who: str = "") -> List[Dict[str, Any]]:
        try:
            raw = str(self._cls("NotificationStore").recentJson(self._ctx(), str(who or ""), int(limit)))
            data = json.loads(raw)
            return [d for d in data if isinstance(d, dict)] if isinstance(data, list) else []
        except Exception as e:
            self.error = f"{type(e).__name__}: {str(e)[:120]}"
            return []

    def message_status(self) -> Dict[str, Any]:
        """{enabled, connected, seen, kept}: is Luna really connected to the notifications, and has she seen any?"""
        try:
            data = json.loads(str(self._cls("NotificationStore").statusJson(self._ctx())))
            return data if isinstance(data, dict) else {}
        except Exception as e:
            self.error = f"{type(e).__name__}: {str(e)[:120]}"
            return {}

    def open_message(self, who: str = "") -> str:
        try:
            return str(self._cls("NotificationStore").open(self._ctx(), str(who or "")))
        except Exception as error:
            return f"error: {type(error).__name__}"

    def contacts_enabled(self) -> bool:
        try:
            ok = bool(self._cls("Calls").canRead(self._ctx()))
            self.error = ""
            return ok
        except Exception as e:
            self.error = f"{type(e).__name__}: {str(e)[:120]}"
            return False

    def find_contact(self, name: str) -> List[Dict[str, Any]]:
        """People in the phone's contacts matching `name`, best match first: [{name, number}]."""
        try:
            data = json.loads(str(self._cls("Calls").searchJson(self._ctx(), str(name))))
            return [d for d in data if isinstance(d, dict) and d.get("name")] if isinstance(data, list) else []
        except Exception as e:
            self.error = f"{type(e).__name__}: {str(e)[:120]}"
            return []

    def screenshot(self) -> str:
        """A small picture of the screen as 'ok:<base64 jpeg>', or 'error: ...'."""
        try:
            return str(self._cls("LunaAccessibilityService").screenshotBase64())
        except Exception as error:
            return f"error: {type(error).__name__}"

    def location(self) -> str:
        """'ok:lat,lon,accuracy' from the phone, or 'error: ...'."""
        try:
            return str(self._cls("Where").now(self._ctx()))
        except Exception as error:
            return f"error: {type(error).__name__}"

    def read_screen(self) -> str:
        try:
            return str(self._cls("LunaAccessibilityService").readScreen())
        except Exception as error:
            return f"error: {type(error).__name__}"


def get_phone() -> Any:
    """The real phone bridge inside the Android app, otherwise None."""
    try:
        import java  # noqa: F401  (only importable under Chaquopy)
    except Exception:
        return None
    return AndroidPhone()
