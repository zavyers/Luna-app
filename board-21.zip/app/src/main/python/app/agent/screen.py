"""\"Look at what I'm watching\": Luna reads the screen (text and a picture), says what it is, asks what the person
wants to know, researches it on the internet and answers. Works while a reel or video is playing in another app.

This module only decides WHAT was asked. Assistant does the looking, searching and answering.
"""
from __future__ import annotations

import re
from typing import Optional

FRESH_SECONDS = 180  # follow-up questions about the same screen are understood without saying "this" again

_STRIP = re.compile(r"[^\w\s'+-]", re.UNICODE)

# "read my screen", "what am I looking at", "look at this reel": no particular question yet
_LOOK = [
    re.compile(r"\b(?:read|scan|look at|have a look at|see|check|watch|dekho|dekh)\s+(?:out\s+)?(?:my\s+|the\s+|this\s+)?(?:phone\s+)?(?:screen|display|reel|reels|video|page)\b"),
    re.compile(r"\b(?:read|summari[sz]e|describe|explain)\s+(?:out\s+)?(?:my\s+|the\s+|this\s+)?(?:phone\s+)?(?:screen|display|page)\b"),
    re.compile(r"\bwhat(?:'s| is| am i| do you see)\s+(?:on\s+(?:my\s+|the\s+)?(?:screen|display)|seeing|looking at|watching|on screen)\b"),
    re.compile(r"\bwhat do you see\b"),
    re.compile(r"\bscreen\s+(?:par|pe|mein|me)\s+kya\b"),
    re.compile(r"\b(?:screen|reel|video)\s+(?:padho|dekho|dekh)\b"),
    re.compile(r"\b(?:look|see) (?:at )?this\b$"),
]

# "read the screen": read the words that are there, straight away, with no picture and no AI in between
_READ = [
    re.compile(r"^(?:(?:hey|hi|ok|okay)\s+)?(?:luna\s+)?(?:and\s+)?(?:please\s+)?(?:(?:can|could|would) you\s+)?read(?: out)?(?: loud)?\s+(?:the\s+|my\s+|this\s+|that\s+)?(?:whole\s+|entire\s+|full\s+)?"
               r"(?:phone\s+)?(?:screen|display|page|text|post|caption|article)(?:\s+(?:out|aloud|loud|for me|to me|please|now))*$"),
    re.compile(r"^(?:(?:hey|hi|ok|okay)\s+)?(?:luna\s+)?(?:please\s+)?read\s+(?:this|it|that)(?:\s+(?:out|aloud|loud|for me|to me|please|now))*$"),
    re.compile(r"^(?:screen|page|ye|yeh)\s+(?:ko\s+)?(?:padho|padh do|padh de|sunao|sunao ji)$"),
]
_MORE = re.compile(r"^(?:keep reading|continue reading|read more|read on|go on|continue|carry on|aage padho|aur padho|aage sunao)$")

_THING = (r"watch|watches|phone|mobile|laptop|shoes|shoe|sneakers|bag|car|bike|scooter|product|item|thing|dress|outfit|jacket|shirt|tshirt|t-shirt|"
          r"jeans|glasses|sunglasses|headphones|earbuds|speaker|gadget|device|camera|tv|fridge|furniture|sofa|chair|table|lamp|perfume|"
          r"bottle|gift|jewellery|jewelry|ring|necklace|watchband|song|movie|show|place|hotel|resort|restaurant|dish|food|recipe|plant|"
          r"building|app|game|brand|model|price|offer|deal|ghadi|joote|kapde|gaadi")
_QUESTION = (r"what|which|who|how much|how|price|cost|costs|worth|brand|model|review|reviews|compare|buy|where|tell me|about|research|"
             r"find out|look up|search|details|info|information|good|real|genuine|original|kya|kitna|kitne|kaun|kaunsa|kaunsi|batao|bata|"
             r"consider|should i|is it|is this|are these|specs|features")
_ASK = [
    # "tell me about this watch", "how much is this watch", "ye watch kaisi hai"
    re.compile(rf"\b(?:this|that|these|those|the|yeh|ye|is|iski|iska|isko|us)\s+(?:{_THING})\b"),
    # "what is this", "how much does this cost", "is this good"
    re.compile(r"^(?:and\s+)?(?:what(?:'s| is| are)|how much(?: is| does| are)?|is|are|which|who made|whose|kya hai|ye kya|yeh kya|iska|iski|ye kitne|yeh kitne)\s+(?:this|that|these|those|ye|yeh)\b"),
    re.compile(r"\b(?:how much|price|cost|kitne ka|kitna)\b.{0,12}\b(?:this|that|ye|yeh|iska)\b"),
    # something said about the screen or video
    re.compile(r"\b(?:on (?:my |the )?screen|in (?:this|the) (?:reel|reels|video|photo|picture|image|post|page)|(?:he|she|they)(?:'s| is| are)? wearing|wearing)\b"),
    re.compile(r"\b(?:research|look up|find out|google|search)\s+(?:about\s+)?(?:this|that|it)\b"),
]
_Q = re.compile(rf"\b(?:{_QUESTION})\b")

_DONE = re.compile(r"^(?:thanks|thank you|ok|okay|stop|cancel|never ?mind|that'?s all|that is all|no|nope|nothing|bye|shukriya|dhanyavaad|theek hai|bas)\b")


def clean(text: str) -> str:
    return " ".join(_STRIP.sub(" ", (text or "").lower()).split())


def classify(text: str, fresh: bool = False) -> Optional[str]:
    """\"read\" (read the words on the screen out loud, at once), \"more\" (carry on reading),
    \"look\" (describe the screen and ask what they want), \"ask\" (a question about what is on the screen),
    \"follow\" (a follow-up about a screen Luna just looked at), or None (nothing to do with the screen)."""
    t = clean(text)
    if not t or len(t) > 160:
        return None
    if fresh and _MORE.match(t):
        return "more"
    if any(rx.match(t) for rx in _READ):
        return "read"
    if any(rx.search(t) for rx in _LOOK):
        return "look"
    if any(rx.search(t) for rx in _ASK) and (_Q.search(t) or len(t.split()) <= 4):
        return "ask"
    if fresh and not _DONE.match(t) and len(t.split()) <= 30:
        return "follow"
    return None


def wants_to_stop(text: str) -> bool:
    return bool(_DONE.match(clean(text)))


LOOK_SYSTEM = (
    "You are Luna, a friendly voice assistant. You are shown a picture of the user's phone screen and the text on it. "
    "In one or two short sentences say what the main thing on the screen is, for example 'a reel showing a silver watch "
    "with a blue dial'. Mention a brand or name only if it is written on the screen. Never say who a real person is from "
    "their face. Then ask what they would like to know about it, in the language the user used. Plain spoken words, no lists. "
    "Start with one emotion tag in square brackets, like [curious]."
)

QUERY_SYSTEM = (
    "You turn a question about something on a phone screen into one web search query. Reply with exactly one line and nothing "
    "else: the search query (brand, model or type, and what they want to know, for example 'Casio F-91W price India review'). "
    "If you cannot tell what the thing is, reply exactly: UNCLEAR"
)

ANSWER_RULES = (
    "The user is looking at their phone screen (picture and text given) and asked about it. Answer their question about the thing "
    "on the screen using the WEB RESULTS when given, and what you can see. Say what you think the item is, then the useful facts "
    "(price range, quality, pros and cons, alternatives) in 3 to 5 short spoken sentences. If you are not sure what it is, say so "
    "and tell them what you would need (a closer look, the name). Never identify a real person from their face. "
    "Do not use lists or markdown."
)


# ---- reading the words aloud
_SPLIT = re.compile(r"\s*(?:\.\s+|\n+)")
_NOISE = {"like", "likes", "comment", "comments", "share", "send", "more", "more options", "navigation bar", "back", "menu", "options",
          "tap to unmute", "unmute", "mute", "audio", "camera", "home", "reels", "search and explore", "profile", "double tap to like"}
CHUNK = 700


def tidy(page: str) -> list:
    """The screen's words as short, separate pieces: no repeats, no tiny button labels."""
    seen, out = set(), []
    for frag in _SPLIT.split(page or ""):
        frag = frag.strip().strip(".")
        key = frag.lower()
        if len(re.sub(r"\W", "", frag)) < 2 or key in _NOISE or key in seen:
            continue
        seen.add(key)
        out.append(frag)
    return out


def take_chunk(body: str, limit: int = CHUNK) -> tuple:
    """(the first part to say now, the rest). Cuts between pieces so a sentence isn't chopped in half."""
    if len(body) <= limit:
        return body, ""
    cut = body.rfind(". ", 0, limit)
    if cut < limit // 3:
        cut = body.rfind(" ", 0, limit)
    if cut <= 0:
        cut = limit
    return body[:cut].strip().rstrip("."), body[cut:].lstrip(". ").strip()
