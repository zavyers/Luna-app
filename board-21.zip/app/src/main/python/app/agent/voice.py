"""Very short spoken answers: yes/no to a question Luna has just asked, and accept/decline for a ringing phone.

Works for English, Hinglish and Hindi (Devanagari). Anything longer than a few words is ignored, so ordinary
talk in the room is never taken for an answer. When a sentence has both a yes-word and a no-word the NO wins,
because doing nothing is the safe mistake.
"""
from __future__ import annotations

import re

MAX_WORDS = 8

# "Hey Luna, ..." in front of the answer is fine
_WAKE = re.compile(r"^\s*(?:hey|hi|hello|ok|okay|ae|arey|oye)?\s*(?:luna|loona|lunar|looner|लूना|लुना)\b[\s,.:;!?-]*", re.IGNORECASE)
_PUNCT = re.compile(r"[^\w\s'\u0900-\u097F]")

_YES = re.compile(
    r"\b(?:yes|yeah|yep|yup|sure|ok|okay|correct|confirm|confirmed|send it|send|do it|go ahead|please do|affirmative|"
    r"haan|han|haa|haanji|ji haan|theek hai|thik hai|kar do|bhej do|bhejo)\b|(?:हाँ|हां|हा|जी हाँ|जी हां|ठीक है|कर दो|भेज दो|भेजो)")
_NO = re.compile(
    r"\b(?:no|nope|nah|cancel|stop|don'?t|do not|never mind|nevermind|not now|negative|nahi|nahin|nai|mat|rehne do|ruko)\b|"
    r"(?:नहीं|नही|मत|रहने दो|रुको|कैंसिल)")

_ACCEPT = re.compile(
    r"\b(?:accept|answer|pick(?: it| the call| the phone)? up|pickup|take (?:it|the call)|receive|attend|lift|yes|yeah|yep|yup|sure|ok|okay|"
    r"haan|han|haa|haanji|ji haan|utha|uthao|utha lo|utha do|utha lijiye|attend karo|receive karo)\b|"
    r"(?:हाँ|हां|हा|उठाओ|उठा लो|उठाइए|उठा दो|उठाऊं|उठाऊँ|रिसीव|अटेंड|एक्सेप्ट)")
_DECLINE = re.compile(
    r"\b(?:decline|reject|refuse|cut|hang ?up|disconnect|ignore|dismiss|cancel|no|nope|nah|don'?t|do not|not now|busy|"
    r"nahi|nahin|nai|mat|kaat|kaato|kaat do|kaat de|kat|reject kar do|cut kar do|busy hoon)\b|"
    r"(?:नहीं|नही|मत|काट|काटो|कट|रिजेक्ट|डिक्लाइन|बिजी|काट दो|काट दे)")


def _prepare(text: str) -> str:
    t = (text or "").strip()
    t = _WAKE.sub("", t, count=1)
    t = _PUNCT.sub(" ", t.lower())
    return " ".join(t.split())


def yes_no(text: str) -> str:
    """'yes', 'no' or '' (neither)."""
    t = _prepare(text)
    if not t or len(t.split()) > MAX_WORDS:
        return ""
    if _NO.search(t):
        return "no"
    if _YES.search(t):
        return "yes"
    return ""


def call_decision(text: str) -> str:
    """'accept', 'decline' or '' for what was said while the phone is ringing."""
    t = _prepare(text)
    if not t or len(t.split()) > MAX_WORDS:
        return ""
    if _DECLINE.search(t):
        return "decline"
    if _ACCEPT.search(t):
        return "accept"
    return ""
