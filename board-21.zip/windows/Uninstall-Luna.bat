@echo off
setlocal EnableExtensions
title Uninstall Luna
set "DEST=%LOCALAPPDATA%\Luna"
echo.
echo  This removes Luna from this PC (%DEST%) and her shortcuts.
choice /C YN /N /M "Continue? (Y/N) "
if errorlevel 2 exit /b 0
choice /C YN /N /M "Also delete your saved chats, plans and AI keys? (Y/N) "
set "WIPE=1"
if errorlevel 2 set "WIPE=0"

taskkill /F /IM pythonw.exe /FI "WINDOWTITLE eq Luna*" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Startup'))){ Remove-Item (Join-Path $d 'Luna.lnk') -ErrorAction SilentlyContinue }"

if "%WIPE%"=="1" (
  rem this window is running from inside the folder, so delete it a moment after we exit
  start "" /min cmd /c "timeout /t 2 >nul & rmdir /s /q ""%DEST%"""
) else (
  for /d %%D in ("%DEST%\*") do if /I not "%%~nxD"=="data" rmdir /s /q "%%D"
  for %%F in ("%DEST%\*") do if /I not "%%~nxF"==".env" if /I not "%%~nxF"=="Uninstall-Luna.bat" del /q "%%F"
  echo  Your chats and keys were kept in %DEST%\data
)
echo  Luna was removed.
timeout /t 4 >nul
endlocal
