@echo off
setlocal EnableExtensions
title Install Luna
set "SRC=%~dp0"
set "DEST=%LOCALAPPDATA%\Luna"
echo.
echo  ==============================
echo    Installing Luna on Windows
echo  ==============================
echo  Luna will be installed in: %DEST%
echo  (Your chats and keys are kept if you install again to update.)
echo.

rem ---- 1. Python 3.9 or newer
set "PYEXE=" & set "PYARG="
py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>&1
if not errorlevel 1 ( set "PYEXE=py" & set "PYARG=-3" )
if not defined PYEXE (
  python -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
  echo  Python was not found. Trying to install it with Windows Package Manager...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PYEXE (
  echo.
  echo  Luna needs Python. Opening the download page now.
  echo  Install Python 3.12, TICK "Add python.exe to PATH", then run Install-Luna.bat again.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)

rem ---- 2. copy Luna's files (never touching saved chats, keys or the .env file)
if /I not "%SRC%"=="%DEST%\" (
  robocopy "%SRC%." "%DEST%" /E /NFL /NDL /NJH /NJS /NP /XD data __pycache__ venv .venv /XF .env *.pyc >nul
  if errorlevel 8 ( echo  Could not copy the files to %DEST% & pause & exit /b 1 )
)
if not exist "%DEST%\.env" if exist "%DEST%\.env.example" copy /Y "%DEST%\.env.example" "%DEST%\.env" >nul

rem ---- 3. a private Python environment with what Luna needs
if not exist "%DEST%\venv\Scripts\python.exe" (
  echo  Setting up Luna's Python environment...
  "%PYEXE%" %PYARG% -m venv "%DEST%\venv"
  if errorlevel 1 ( echo  Could not create the environment. & pause & exit /b 1 )
)
echo  Installing Luna's parts (this takes a minute)...
"%DEST%\venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
"%DEST%\venv\Scripts\python.exe" -m pip install --quiet python-dotenv requests psutil
if errorlevel 1 ( echo  Could not download Luna's parts. Check your internet and run this again. & pause & exit /b 1 )
rem the extra Luna window is optional: Luna opens in an Edge window without it
"%DEST%\venv\Scripts\python.exe" -m pip install --quiet pywebview >nul 2>&1

rem ---- 4. Desktop and Start menu shortcuts
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut((Join-Path $d 'Luna.lnk')); $s.TargetPath='%DEST%\venv\Scripts\pythonw.exe'; $s.Arguments='main.py'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\luna.ico'; $s.Description='Luna assistant'; $s.Save() }"

rem ---- 5. optionally start with Windows, so she is always there
choice /C YN /N /M "Start Luna automatically when you sign in to Windows? (Y/N) "
if not errorlevel 2 (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) 'Luna.lnk')); $s.TargetPath='%DEST%\venv\Scripts\pythonw.exe'; $s.Arguments='main.py'; $s.WorkingDirectory='%DEST%'; $s.IconLocation='%DEST%\luna.ico'; $s.Save()"
)

echo.
echo  Done! Luna is installed. Opening her now.
echo  - Allow the microphone when asked, and keep her window open (minimise it).
echo  - Open the menu, then Settings, and paste an AI key (Gemini and Groq are free).
echo  - To pair with your phone: Settings, then PHONE and LAPTOP, on the same Wi-Fi.
echo  - If Windows asks about the firewall, allow "Private networks".
start "" /D "%DEST%" "%DEST%\venv\Scripts\pythonw.exe" main.py
timeout /t 8 >nul
endlocal
