import re, unittest
from pathlib import Path

JAVA = Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "java" / "com" / "luna" / "app"


class OverlayWiringTests(unittest.TestCase):
    """The floating Listening / Thinking / Speaking box can't run off a phone, so check it is wired in everywhere it must be."""

    def setUp(self):
        self.overlay = (JAVA / "Overlay.java").read_text()
        self.service = (JAVA / "ListenService.java").read_text()

    def test_three_states_are_drawn(self):
        for needle in ("is listening", "is thinking", "drawSpeaking", "TYPE_ACCESSIBILITY_OVERLAY", "TYPE_APPLICATION_OVERLAY", "FLAG_NOT_TOUCHABLE"):
            self.assertIn(needle, self.overlay)

    def test_service_shows_each_state(self):
        self.assertIn("Overlay.show(this, Overlay.SPEAKING", self.service)
        self.assertIn("Overlay.THINKING", self.service)
        self.assertIn("Overlay.LISTENING", self.service)

    def test_box_is_hidden_when_muted_stopped_or_the_app_is_open(self):
        self.assertRegex(self.service, r"isMuted\(\) \|\| \(activityVisible && !callWindow\(\)\)\) Overlay\.hide\(\)")
        self.assertRegex(self.service, r"onDestroy\(\) \{[^}]*Overlay\.hide\(\)")

    def test_follow_up_window_comes_from_python(self):
        self.assertIn('callAttr("keep_awake").toDouble()', self.service)

    def test_braces_balance(self):
        for f in ("Overlay.java", "ListenService.java"):
            src = re.sub(r'"(?:\\.|[^"\\])*"|//[^\n]*', "", (JAVA / f).read_text())
            self.assertEqual(src.count("{"), src.count("}"), f)


if __name__ == "__main__":
    unittest.main()
