import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))
from app.agent.fast import FastIntents  # noqa: E402


class Phone:
    def find_app(self, name):
        return None

    def contacts_enabled(self):
        return False


def args(text):
    r = FastIntents("android", Phone()).match(text)
    return r.actions[0]["args"] if r and r.actions else None


class T(unittest.TestCase):
    def test_commands(self):
        self.assertEqual(args("screnshot please"), {"action": "screenshot"})
        self.assertEqual(args("google best phones"), {"action": "a_search_web", "query": "best phones"})
        self.assertEqual(args("open flipkart.com"), {"action": "a_open_url", "url": "https://flipkart.com"})
        self.assertIsNone(args("what is a screenshot"))


if __name__ == "__main__":
    unittest.main()
