import sys, time, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.fast import FastIntents  # noqa: E402
from app.agent.typos import fix_command  # noqa: E402


def lev(a, b):
    prev = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i]
        for j, y in enumerate(b, 1):
            cur.append(min(cur[-1] + 1, prev[j] + 1, prev[j - 1] + (x != y)))
        prev = cur
    return prev[-1]


class Phone:
    def __init__(self, contacts, rows=None, apps=("Chrome", "WhatsApp", "Instagram", "Snapchat")):
        self.contacts, self.rows, self.apps = contacts, rows or [], apps

    def find_app(self, name):
        n = name.lower()
        return next((a for a in self.apps if a.lower() == n or a.lower().startswith(n)), "")

    def contacts_enabled(self): return True
    def messages_enabled(self): return True

    def find_contact(self, name):
        n = name.lower()
        hits = [dict(c) for c in self.contacts if n in c["name"].lower()]
        if hits:
            return hits
        # the real phone also tries close spellings and marks them as a guess
        return [dict(c, fuzzy=True) for c in self.contacts if any(len(t) >= 3 and lev(t, n) <= 1 for t in c["name"].lower().split())]

    def recent_messages(self, limit=5, who=""):
        return [r for r in self.rows if not who or who.lower() in r["sender"].lower()][:limit]


CONTACTS = [{"name": "Mom", "number": "+911"}, {"name": "Rahul Sharma", "number": "+912"}, {"name": "Rahul Verma", "number": "+913"},
            {"name": "Priya Singh", "number": "+914"}]


def fast(rows=None, contacts=CONTACTS):
    t = [1000.0]
    f = FastIntents("android", Phone(contacts, rows), now=lambda: t[0])
    f._t = t
    return f


def sent(r):
    assert r is not None and r.actions, r
    return r.actions[0]["args"]


class TypoTests(unittest.TestCase):
    def test_command_words_are_fixed_but_the_message_is_not(self):
        self.assertEqual(fix_command("mesage rahull on instagrm sayin hi"), "message rahull on instagram saying hi")
        self.assertEqual(fix_command("Send a mesage to Mom saying I'm comming tomorow"), "Send a message to Mom saying I'm comming tomorow")
        self.assertEqual(fix_command("message Tella saying hi"), "message Tella saying hi")  # a name that looks like a command word
        self.assertEqual(fix_command("what is the weather"), "what is the weather")

    def test_open_with_typos(self):
        r = fast().match("opne instgram")
        self.assertIn("Instagram", r.text)


class SendTests(unittest.TestCase):
    def test_typos_in_a_send(self):
        a = sent(fast().match("snd a mesage to mom sayin I'm late"))
        self.assertEqual((a["action"], a["to"], a["text"]), ("send_message", "Mom", "I'm late"))

    def test_first_name_only(self):
        self.assertEqual(sent(fast().match("message priya saying hi"))["to"], "Priya Singh")

    def test_several_people_at_once(self):
        a = sent(fast().match("message Mom, Priya and Rahul Sharma saying dinner at 8"))
        self.assertEqual(a["to"], "Mom|Priya Singh|Rahul Sharma")
        self.assertEqual(a["text"], "dinner at 8")

    def test_everyone_means_the_chats_that_wrote_to_me(self):
        rows = [{"app": "WhatsApp", "sender": "Rahul", "conv": "", "text": "x", "when": 1}, {"app": "SMS", "sender": "Mom", "conv": "", "text": "y", "when": 2},
                {"app": "WhatsApp", "sender": "Rahul", "conv": "", "text": "z", "when": 3}]
        self.assertEqual(sent(fast(rows).match("message everyone saying happy diwali"))["to"], "Rahul|Mom")
        r = fast().match("message everyone saying hi")  # nobody wrote to me: never message the whole phone book
        self.assertFalse(r.ok)
        self.assertEqual(r.actions, [])

    def test_too_many_people_are_refused(self):
        names = ", ".join(f"p{i}" for i in range(12))
        contacts = [{"name": f"p{i}", "number": f"+9{i}"} for i in range(12)]
        r = fast(contacts=contacts).match(f"message {names} saying hi")
        self.assertEqual(r.actions, [])
        self.assertIn("10", r.text)

    def test_asks_which_one_then_understands_the_answer(self):
        f = fast()
        r = f.match("message rahul saying I'm coming")
        self.assertEqual(r.actions, [])
        self.assertIn("Rahul Sharma", r.text)
        self.assertEqual(sent(f.match("the second one"))["to"], "Rahul Verma")
        f.match("message rahul saying hi")
        self.assertEqual(sent(f.match("sharma"))["to"], "Rahul Sharma")

    def test_asks_when_the_name_is_only_a_guess(self):
        f = fast()
        r = f.match("message priyaa saying hi")
        self.assertIn("Did you mean Priya Singh", r.text)
        self.assertEqual(sent(f.match("yes"))["to"], "Priya Singh")
        f.match("message priyaa saying hi")
        r = f.match("no")
        self.assertEqual(r.actions, [])

    def test_a_calling_guess_is_asked_too(self):
        f = fast()
        r = f.match("call priyaa")
        self.assertIn("Did you mean Priya Singh", r.text)
        a = sent(f.match("yeah"))
        self.assertEqual((a["action"], a["contact"]), ("call_contact", "Priya Singh"))

    def test_another_request_drops_the_question(self):
        f = fast()
        f.match("message rahul saying hi")
        r = f.match("open whatsapp")
        self.assertIn("WhatsApp", r.text)
        self.assertIsNone(f._pending)

    def test_other_chat_apps(self):
        for said, app in [("message zed on instagram saying hi", "instagram"), ("dm zed on insta saying hi", "instagram"),
                          ("send a snapchat message to zed saying hi", "snapchat"), ("message zed on telegram saying hi", "telegram"),
                          ("mesage zed on instgram sayin hi", "instagram")]:
            a = sent(fast().match(said))
            self.assertEqual((a["app"], a["to"], a["text"]), (app, "Zed", "hi"), said)

    def test_the_old_ways_still_work(self):
        self.assertEqual(sent(fast().match("send a message to mom on whatsapp saying hi"))["app"], "whatsapp")
        self.assertEqual(sent(fast().match("tell mom i'll be late"))["to"], "Mom")


if __name__ == "__main__":
    unittest.main()


class SameNameTests(unittest.TestCase):
    TWINS = [{"name": "Rahul", "number": "+91 98765 41234"}, {"name": "Rahul", "number": "+91 98765 45678"}, {"name": "Mom", "number": "+911"}]

    def test_two_contacts_with_the_same_name_are_asked_about(self):
        f = fast(contacts=self.TWINS)
        r = f.match("message rahul saying hi")
        self.assertEqual(r.actions, [])
        self.assertIn("1 2 3 4", r.text)  # read out digit by digit
        self.assertIn("5 6 7 8", r.text)
        self.assertEqual(sent(f.match("the second one"))["to"], "Rahul ending 5678")
        f.match("message rahul saying hi")
        self.assertEqual(sent(f.match("ending 1 2 3 4"))["to"], "Rahul ending 1234")
        f.match("call rahul")
        a = sent(f.match("5678"))
        self.assertEqual((a["action"], a["contact"]), ("call_contact", "Rahul ending 5678"))

    def test_the_same_person_saved_twice_is_not_two_people(self):
        twice = [{"name": "Mom", "number": "+91 91111 22222"}, {"name": "Mom", "number": "9111122222"}]
        self.assertEqual(sent(fast(contacts=twice).match("message mom saying hi"))["to"], "Mom")

    def test_chat_history_never_skips_the_question(self):
        rows = [{"app": "WhatsApp", "sender": "Rahul Sharma", "conv": "", "text": "hey", "when": 1}]
        r = fast(rows).match("message rahul saying hi")
        self.assertEqual(r.actions, [])
        self.assertIn("Rahul Verma", r.text)

    def test_first_names_win_over_letters_inside_other_names(self):
        contacts = [{"name": "Kiran Shah", "number": "+915"}, {"name": "Rahul Sharma", "number": "+912"}]
        self.assertEqual(sent(fast(contacts=contacts).match("message ra saying hi"))["to"], "Rahul Sharma")

    def test_spelling_slips_in_first_names(self):
        for said in ["message rahull saying hi", "message rahl saying hi", "message raul saying hi"]:
            r = fast(contacts=[{"name": "Rahul Sharma", "number": "+912"}]).match(said)
            self.assertIn("Did you mean Rahul Sharma", r.text, said)


class JavaPieces(unittest.TestCase):
    def test_the_phone_side_exists(self):
        root = Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "java" / "com" / "luna" / "app"
        self.assertIn("class ChatSend", (root / "ChatSend.java").read_text())
        calls = (root / "Calls.java").read_text()
        for needle in ['split("\\\\|")', "class Batch", '"fuzzy"', "ChatSend.supports"]:
            self.assertIn(needle, calls)
        acc = (root / "LunaAccessibilityService.java").read_text()
        for needle in ["static String typeInto", "static String tapPerson"]:
            self.assertIn(needle, acc)
        self.assertIn("static int lev(", (root / "PhoneActions.java").read_text())
