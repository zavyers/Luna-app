import sys, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.fast import FastIntents  # noqa: E402
from app.tools import weather  # noqa: E402

ROOT = Path(__file__).resolve().parents[1] / "app" / "src" / "main"


class Phone:
    def __init__(self, rows=()): self.rows = list(rows)
    def find_app(self, name): return ""
    def contacts_enabled(self): return True
    def messages_enabled(self): return True
    def find_contact(self, name): return []
    def recent_messages(self, limit=5, who=""): return [r for r in self.rows if not who or who.lower() in r["sender"].lower()][:limit]


class WeatherTests(unittest.TestCase):
    def ask(self, said, calls):
        f = FastIntents("android", Phone(), weather=lambda city, mode: (calls.append((city, mode)) or "Sunny."))
        return f.match(said)

    def test_the_ways_to_ask(self):
        for said, want in [("what's the weather", ("", "now")), ("weather in Mumbai", ("Mumbai", "now")), ("weather in new delhi today", ("New Delhi", "now")),
                           ("will it rain tomorrow", ("", "tomorrow")), ("will it rain", ("", "rain")), ("do I need an umbrella", ("", "rain")),
                           ("Hey Luna what is the wether in pune", ("Pune", "now")), ("temprature in goa", ("Goa", "now")), ("mausam kaisa hai", ("", "now")),
                           ("forcast for london tomorrow", ("London", "tomorrow"))]:
            calls = []
            r = self.ask(said, calls)
            self.assertIsNotNone(r, said)
            self.assertEqual(calls, [want], said)
            self.assertIn("Sunny", r.text)

    def test_other_talk_is_left_alone(self):
        for said in ["open whatsapp", "what is the capital of france", "i feel under the weather lol okay thanks for everything you did", "tell me a joke"]:
            calls = []
            r = self.ask(said, calls)
            self.assertEqual(calls, [], said)

    def test_report_numbers(self):
        data = {"current": {"temperature_2m": 31.4, "apparent_temperature": 36.2, "relative_humidity_2m": 62, "weather_code": 2, "wind_speed_10m": 11.6, "precipitation": 0},
                "daily": {"weather_code": [63, 3], "temperature_2m_max": [33.1, 32.0], "temperature_2m_min": [26.2, 25.9], "precipitation_probability_max": [72, 20]}}
        self.assertIn("31 degrees, feels like 36, partly cloudy", weather.report(data, "Mumbai"))
        self.assertIn("very likely (72% chance)", weather.report(data, "Mumbai", "rain"))
        self.assertIn("20% chance of rain", weather.report(data, "Mumbai", "tomorrow"))

    def test_a_failure_becomes_a_sentence(self):
        old = weather._get
        weather._get = lambda *a, **k: (_ for _ in ()).throw(OSError("offline"))
        try:
            self.assertIn("couldn't reach the weather service", weather.answer("Mumbai", "now"))
        finally:
            weather._get = old

    def test_phone_position_is_used_first(self):
        class P:
            def location(self): return "ok:19.07,72.87,30"
        old = weather._get
        weather._get = lambda url, timeout=8.0: {"locality": "Mumbai", "principalSubdivision": "Maharashtra"}
        try:
            place = weather.locate(P())
            self.assertEqual((place[0], place[2], place[3]), (19.07, "Mumbai, Maharashtra", False))
        finally:
            weather._get = old


class TapTests(unittest.TestCase):
    ROWS = [{"app": "WhatsApp", "sender": "Rahul", "conv": "", "text": "dinner?", "when": 1.0},
            {"app": "Instagram", "sender": "jai", "conv": "", "text": "hi bro", "when": 2.0}]

    def test_each_message_opens_its_own_app(self):
        r = FastIntents("android", Phone(self.ROWS), now=lambda: 10.0).match("who messaged me")
        taps = [a for a in r.actions if a["status"] == "tap"]
        self.assertEqual({(a["args"]["who"], a["args"]["app"]) for a in taps}, {("Rahul", "WhatsApp"), ("jai", "Instagram")})
        self.assertTrue(all(a["args"]["action"] == "open_message" for a in taps))

    def test_phone_and_page_support_it(self):
        self.assertIn('case "open_message"', (ROOT / "java/com/luna/app/PhoneActions.java").read_text())
        self.assertIn("equalsIgnoreCase(m.app)", (ROOT / "java/com/luna/app/NotificationStore.java").read_text())
        js = (ROOT / "python/app/ui/web/app.js").read_text()
        for needle in ["function tapToOpen", "a.status === 'tap'", "interimSeen", "finalSeen"]:
            self.assertIn(needle, js)
        self.assertIn("now - lastLoud > 1200", (ROOT / "java/com/luna/app/Ear.java").read_text())
        self.assertIn("ACCESS_COARSE_LOCATION", (ROOT / "AndroidManifest.xml").read_text())


if __name__ == "__main__":
    unittest.main()
