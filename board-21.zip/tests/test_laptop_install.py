import sys, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.actions import ActionRunner, _APPS, _SITES  # noqa: E402
from app.agent.fast import FastIntents  # noqa: E402
from app.agent.typos import fix_command  # noqa: E402


class Shell:
    def __init__(self): self.log = []
    def start(self, argv): self.log.append(("start", argv))
    def startfile(self, target): self.log.append(("file", target))
    def key(self, vk, times=1): self.log.append(("key", vk, times))
    def lock(self): self.log.append(("lock",))
    def browse(self, url): self.log.append(("browse", url))


def laptop():
    sh = Shell()
    runner = ActionRunner(object(), "windows", shell=sh)
    return FastIntents("windows", None, runner, {**_APPS, **_SITES}), sh


class LaptopTests(unittest.TestCase):
    def test_commands_with_typos_run_instantly(self):
        for said, effect in [("lok the laptop", ("lock",)), ("volum up", ("key", 0xAF, 5)), ("mute", ("key", 0xAD, 1)),
                             ("pause", ("key", 0xB3, 1)), ("next song", ("key", 0xB0, 1)), ("Hey Luna, volume down", ("key", 0xAE, 5))]:
            f, sh = laptop()
            r = f.match(said)
            self.assertIsNotNone(r, said)
            self.assertEqual(sh.log[-1], effect, said)

    def test_open_apps_and_folders_with_spelling_slips(self):
        for said, target in [("open chrome", "chrome"), ("opne chrme", "chrome"), ("open notpad", "notepad"), ("lanch calculater", "calc"),
                             ("open vs code", "code")]:
            f, sh = laptop()
            r = f.match(said)
            self.assertIsNotNone(r, said)
            self.assertIn(target, str(sh.log[-1]), said)
        f, sh = laptop()
        f.match("open downloads folder")
        self.assertEqual(sh.log[-1][0], "file")

    def test_dangerous_things_ask_first(self):
        for said in ["shutdown", "restart", "close notepad"]:
            f, sh = laptop()
            r = f.match(said)
            self.assertEqual(r.actions[0]["status"], "confirm", said)
            self.assertEqual(sh.log, [], said)

    def test_ordinary_talk_is_left_to_the_ai(self):
        for said in ["what is the weather", "tell me a joke", "open the door", "play despacito on youtube"]:
            f, sh = laptop()
            self.assertIsNone(f.match(said), said)
            self.assertEqual(sh.log, [], said)


class Phone:
    def __init__(self, apps=()): self.apps = apps
    def find_app(self, name): return next((a for a in self.apps if a.lower() == name.lower()), "")
    def contacts_enabled(self): return True
    def messages_enabled(self): return False
    def find_contact(self, name): return []
    def recent_messages(self, limit=5, who=""): return []


class InstallTests(unittest.TestCase):
    def test_install_asks_then_installs(self):
        f = FastIntents("android", Phone())
        for said, name in [("install spotify", "Spotify"), ("download instagram from the play store", "Instagram"), ("please instal telegram", "Telegram"),
                           ("get snapchat from play store", "Snapchat"), ("dowload Netflix app", "Netflix")]:
            r = f.match(said)
            self.assertIsNotNone(r, said)
            a = r.actions[0]
            self.assertEqual((a["status"], a["args"]), ("confirm", {"action": "install_app", "name": name}), said)

    def test_already_installed_just_opens(self):
        r = FastIntents("android", Phone(("Spotify",))).match("install spotify")
        self.assertEqual(r.actions[0]["args"]["action"], "a_open_app")

    def test_not_an_app(self):
        f = FastIntents("android", Phone())
        for said in ["download the report", "download a file", "get me a coffee", "install it", "get snacks"]:
            r = f.match(said)
            self.assertTrue(r is None or not r.actions, said)


class WhatsAppOnlyAndVoices(unittest.TestCase):
    ROOT = Path(__file__).resolve().parents[1] / "app" / "src" / "main"

    def test_whatsapp_means_only_whatsapp(self):
        calls = (self.ROOT / "java/com/luna/app/Calls.java").read_text()
        self.assertIn('"whatsapp".equals(via) ? "com.whatsapp" : null', calls)
        self.assertIn("startsWith(onlyPackage)", (self.ROOT / "java/com/luna/app/NotificationStore.java").read_text())

    def test_second_voice_and_stuck_guards_exist(self):
        java = self.ROOT / "java/com/luna/app"
        self.assertIn("class Voices", (java / "Voices.java").read_text())
        for f in ("MainActivity.java", "ListenService.java"):
            self.assertIn("Voices.choose", (java / f).read_text())
        js = (self.ROOT / "python/app/ui/web/app.js").read_text()
        for needle in ["voiceKind", "function watch()", "holdDog", "ctl.abort()"]:
            self.assertIn(needle, js)
        self.assertIn("install_app", (java / "PhoneActions.java").read_text())

    def test_more_typos(self):
        self.assertEqual(fix_command("lok the laptop"), "lock the laptop")
        self.assertEqual(fix_command("volum up"), "volume up")
        self.assertEqual(fix_command("instal spotify"), "install spotify")


if __name__ == "__main__":
    unittest.main()
