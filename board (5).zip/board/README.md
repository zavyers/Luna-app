# Luna – Starter Project (Android, Kotlin + Jetpack Compose)

Open this folder in Android Studio -> Sync -> Run.

## Included (v0.1)
- Chat box, Hinglish system prompt, emotion tag in replies
- Provider switch: Groq (free default) / OpenAI / Grok / Gemini
- Top mic/mute button, voice-wave animation
- Foreground service skeleton (always-on listening, no audio focus)
- Logo: logo/luna_logo.svg

## Next steps
1. Wake word: add Picovoice Porcupine in LunaService ("Hey Luna")
2. Speech-to-text + TTS (female voice, emotion -> pitch/speed)
3. EncryptedSharedPreferences for API keys + PIN/pattern lock
4. Memory + planner (Room DB), alarms (AlarmClock intent)
5. AccessibilityService: read screen, WhatsApp/Instagram actions
6. NotificationListenerService: read latest messages, announce calls
7. Image generation, code runner, file attach, laptop sync
