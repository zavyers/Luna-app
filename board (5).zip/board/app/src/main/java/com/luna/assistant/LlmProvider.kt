package com.luna.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class Provider(val label: String, val url: String, val model: String) {
    GROQ("Groq (free default)", "https://api.groq.com/openai/v1/chat/completions", "llama-3.3-70b-versatile"),
    OPENAI("OpenAI", "https://api.openai.com/v1/chat/completions", "gpt-4o-mini"),
    GROK("Grok", "https://api.x.ai/v1/chat/completions", "grok-2-latest"),
    GEMINI("Gemini", "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent", "gemini-1.5-flash")
}

const val SYSTEM_PROMPT = """You are Luna, a warm female voice assistant. Reply in Hinglish (Roman script) in text.
When speaking Hindi, use casual Gen-Z Hindi, not pure/formal Hindi. Match the user's emotion: sad when they are sad, happy when they are happy.
Understand typos. Before messaging or calling anyone, confirm the name. Start your reply with an emotion tag like [happy], [sad], [neutral]."""

object LlmClient {
    suspend fun ask(p: Provider, apiKey: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val conn = if (p == Provider.GEMINI)
                URL(p.url + "?key=" + apiKey).openConnection() as HttpURLConnection
            else URL(p.url).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            if (p != Provider.GEMINI) conn.setRequestProperty("Authorization", "Bearer $apiKey")

            val body = if (p == Provider.GEMINI) {
                val contents = JSONArray()
                history.forEach { (role, text) ->
                    contents.put(JSONObject().put("role", if (role == "user") "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", text))))
                }
                JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
                    .put("contents", contents)
            } else {
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                history.forEach { (role, text) -> msgs.put(JSONObject().put("role", role).put("content", text)) }
                JSONObject().put("model", p.model).put("messages", msgs)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
            if (code !in 200..299) return@withContext "Error $code: $text"
            val j = JSONObject(text)
            if (p == Provider.GEMINI)
                j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getString("text")
            else j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
}
