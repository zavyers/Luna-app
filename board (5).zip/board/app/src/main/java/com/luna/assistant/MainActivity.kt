package com.luna.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B5CF6))) { LunaScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LunaScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var muted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }          // TODO: store in EncryptedSharedPreferences
    var provider by remember { mutableStateOf(Provider.GROQ) }
    val chat = remember { mutableStateListOf<Pair<String, String>>() }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) ctx.startForegroundService(Intent(ctx, LunaService::class.java))
    }
    LaunchedEffect(muted) {
        if (muted) ctx.stopService(Intent(ctx, LunaService::class.java))
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Luna") }, actions = {
            TextButton(onClick = { provider = Provider.values()[(provider.ordinal + 1) % Provider.values().size] }) { Text(provider.label) }
            FilledTonalIconToggleButton(checked = muted, onCheckedChange = { muted = it }) { Text(if (muted) "Muted" else "Mic") }
        })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(12.dp)) {
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("${provider.label} API key") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            VoiceWave(active = busy || !muted, modifier = Modifier.fillMaxWidth().height(56.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(chat) { (role, text) ->
                    val me = role == "user"
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (me) Alignment.CenterEnd else Alignment.CenterStart) {
                        Surface(shape = RoundedCornerShape(16.dp), color = if (me) Color(0xFF6C2BD9) else Color(0xFF2A2A3C)) {
                            Text(text, Modifier.padding(12.dp))
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Luna se baat karo...") })
                Spacer(Modifier.width(8.dp))
                Button(enabled = !busy && input.isNotBlank(), onClick = {
                    chat += "user" to input; input = ""; busy = true
                    scope.launch {
                        val reply = try { LlmClient.ask(provider, apiKey, chat.toList()) } catch (e: Exception) { "Error: ${e.message}" }
                        chat += "assistant" to reply; busy = false
                    }
                }) { Text("Send") }
            }
        }
    }
}

@Composable
fun VoiceWave(active: Boolean, modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "w").animateFloat(0f, 6.28f,
        infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "p")
    Canvas(modifier) {
        val bars = 24; val gap = size.width / bars
        for (i in 0 until bars) {
            val h = if (active) (abs(sin(t + i * 0.5f)) * 0.8f + 0.1f) * size.height else 0.08f * size.height
            val x = gap * i + gap / 2
            drawLine(Color(0xFFB794F6), Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2), 6f, StrokeCap.Round)
        }
    }
}
