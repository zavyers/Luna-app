package com.luna.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Always-on listener. TODO: plug in Porcupine (wake word "Hey Luna") here.
 * Tip: do NOT request audio focus so reels/videos keep playing.
 */
class LunaService : Service() {
    override fun onCreate() {
        super.onCreate()
        val ch = "luna"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Luna", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Luna is listening")
            .setSmallIcon(R.drawable.ic_luna).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
}
