package com.luna.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 7;
    private static final int FILE_REQUEST = 8;

    private WebView web;
    private SpeechRecognizer recognizer;
    private String listenLang = "en-US";
    private boolean pendingListen = false;
    private boolean started = false;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Locale ttsLocale = null;
    private final ArrayList<String[]> ttsBacklog = new ArrayList<>();
    private int utteranceCount = 0;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050b14"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            // Lets the paperclip button open the phone's photo picker.
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Choose photos"), FILE_REQUEST);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "LunaNative");
        setContentView(web);
        startSpeech();
        startLuna();
    }

    /** What the Luna screen can ask the phone to do. */
    public class Bridge {
        @JavascriptInterface
        public void startListening(final String lang) {
            runOnUiThread(() -> beginListening(lang));
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.stopListening();
            });
        }

        @JavascriptInterface
        public void cancelListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.cancel();
            });
        }

        @JavascriptInterface
        public void speak(final String text, final String lang, final float pitch, final float rate) {
            runOnUiThread(() -> speakNow(text, lang, pitch, rate));
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> {
                ttsBacklog.clear();
                if (tts != null) tts.stop();
            });
        }

        @JavascriptInterface
        public void saveFile(final String name, final String mime, final String base64) {
            runOnUiThread(() -> saveToDownloads(name, mime, base64));
        }

        @JavascriptInterface
        public void pinShortcut(final String name) {
            runOnUiThread(() -> pinHomeShortcut(name));
        }
    }

    private void js(String call) {
        runOnUiThread(() -> web.evaluateJavascript(call, null));
    }

    // ------------------------------------------------------------------ listening

    private void heard(String text, boolean done) {
        js("window.__lunaHeard && window.__lunaHeard(" + JSONObject.quote(text) + "," + done + ")");
    }

    private void voiceEnd() {
        js("window.__lunaVoiceEnd && window.__lunaVoiceEnd()");
    }

    private void voiceError(String message, boolean fatal) {
        js("window.__lunaVoiceError && window.__lunaVoiceError(" + JSONObject.quote(message) + "," + fatal + ")");
    }

    private void beginListening(String lang) {
        if (lang != null && !lang.isEmpty()) listenLang = lang;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceError("This phone has no speech recognition. Install or enable the Google app.", true);
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), false);
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), true);
                    voiceEnd(); // the page starts the next listening round by itself
                }

                @Override
                public void onError(int error) {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        voiceError("Allow the microphone for this app in the phone's settings.", true);
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        voiceError("Voice needs the internet. Check your connection.", false);
                    } else if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            || error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        voiceEnd(); // silence is normal while waiting for the wake word
                    } else {
                        voiceError("Voice input stopped (code " + error + ").", false);
                    }
                }
            });
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, listenLang);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, listenLang);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        recognizer.startListening(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != MIC_REQUEST) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (ok && pendingListen) {
            pendingListen = false;
            beginListening(listenLang);
        } else {
            pendingListen = false;
            voiceError("Luna needs the microphone permission to hear you. Tap the mic at the top and allow it.", true);
        }
    }

    // --------------------------------------------------------------------- voice

    /** The phone's own text-to-speech, with a female voice chosen when one exists. */
    private void startSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
                @Override public void onError(String utteranceId) { js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
            });
            ttsReady = true;
            for (String[] item : ttsBacklog) {
                speakNow(item[0], item[1], Float.parseFloat(item[2]), Float.parseFloat(item[3]));
            }
            ttsBacklog.clear();
        });
    }

    private void useLanguage(String tag) {
        Locale want = (tag == null || tag.isEmpty()) ? Locale.getDefault() : Locale.forLanguageTag(tag);
        if (want.equals(ttsLocale)) return;
        int r = tts.setLanguage(want);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (ttsLocale == null) tts.setLanguage(Locale.US);
            return;
        }
        ttsLocale = want;
        chooseFemaleVoice(want);
    }

    private void chooseFemaleVoice(Locale want) {
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            Voice best = null;
            int bestScore = -99;
            for (Voice v : all) {
                if (!v.getLocale().getLanguage().equals(want.getLanguage())) continue;
                String name = v.getName().toLowerCase(Locale.ROOT);
                int score = 0;
                if (name.contains("female")) score += 4;
                else if (name.contains("male")) score -= 5;
                if (!v.isNetworkConnectionRequired()) score += 1;
                if (v.getLocale().equals(want)) score += 1;
                if (score > bestScore) { best = v; bestScore = score; }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) {
            // keep the phone's default voice
        }
    }

    private void speakNow(String text, String lang, float pitch, float rate) {
        if (!ttsReady || tts == null) {
            ttsBacklog.add(new String[]{text, lang, String.valueOf(pitch), String.valueOf(rate)});
            return;
        }
        useLanguage(lang);
        tts.setPitch(pitch);
        tts.setSpeechRate(rate);
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "luna" + (utteranceCount++));
    }

    // ------------------------------------------------------- files and the home screen

    private void saveToDownloads(String name, String mime, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("no uri");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(data);
                }
                Toast.makeText(this, "Saved " + safe + " in your Downloads folder", Toast.LENGTH_LONG).show();
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(data);
                }
                Toast.makeText(this, "Saved to " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not save the file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Android can't rename an installed app, so this adds a home-screen shortcut with the chosen name. */
    private void pinHomeShortcut(String name) {
        try {
            if (Build.VERSION.SDK_INT < 26) {
                Toast.makeText(this, "This Android version can't add shortcuts from inside the app.", Toast.LENGTH_LONG).show();
                return;
            }
            ShortcutManager sm = getSystemService(ShortcutManager.class);
            if (sm == null || !sm.isRequestPinShortcutSupported()) {
                Toast.makeText(this, "Your launcher can't add shortcuts from inside the app.", Toast.LENGTH_LONG).show();
                return;
            }
            Intent open = new Intent(Intent.ACTION_MAIN).setClass(this, MainActivity.class);
            ShortcutInfo info = new ShortcutInfo.Builder(this, "luna-" + System.currentTimeMillis())
                    .setShortLabel(name)
                    .setLongLabel(name)
                    .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                    .setIntent(open)
                    .build();
            sm.requestPinShortcut(info, null);
        } catch (Exception e) {
            Toast.makeText(this, "Could not add the shortcut: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_REQUEST || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                result = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ------------------------------------------------------------------ the engine

    private void startLuna() {
        if (started) return;
        started = true;
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                PyObject mod = Python.getInstance().getModule("luna_android");
                final String url = mod.callAttr("start", getFilesDir().getAbsolutePath() + "/luna").toString();
                runOnUiThread(() -> web.loadUrl(url));
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Luna failed to start: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
