"""Starts Luna's local server inside the Android app and returns its address."""
import os
from pathlib import Path


def start(data_dir):
    os.environ.setdefault("LUNA_REQUEST_TIMEOUT", "120")  # phones on mobile data can be slow
    from app.chat.store import ChatStore
    from app.config import load_settings
    from app.ui.server import LunaServer, build_app

    folder = Path(data_dir)
    folder.mkdir(parents=True, exist_ok=True)
    # Keys, the assistant's name and everything else are set in Luna's own Settings screen.
    settings = load_settings(folder / "none.env", folder / "keys.json")
    server = LunaServer(build_app(settings, store=ChatStore(folder / "chats.json")))
    server.start()
    return server.url
