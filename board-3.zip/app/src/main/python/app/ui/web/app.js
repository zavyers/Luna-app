/* Luna UI logic. Talks only to the local Luna server (same origin). All text from the
   user or the AI is inserted with textContent, never as HTML. */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const TOKEN = $('meta[name="luna-token"]').content;
  const SVG_NS = 'http://www.w3.org/2000/svg';

  // ---------------------------------------------------------------- helpers

  async function api(method, args = {}) {
    let res;
    try {
      res = await fetch('/api/' + method, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Luna-Token': TOKEN },
        body: JSON.stringify(args),
      });
    } catch (_) {
      throw new Error("Luna's engine isn't responding. Close Luna and start her again.");
    }
    let data = {};
    try { data = await res.json(); } catch (_) { /* keep empty */ }
    if (!res.ok) throw new Error(data.error || 'That request failed.');
    return data;
  }

  // Streaming send: calls onChunk(text) as words arrive, resolves with the final reply.
  async function apiSend(args, onChunk, onStatus) {
    let res;
    try {
      res = await fetch('/api/send_stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Luna-Token': TOKEN },
        body: JSON.stringify(args),
      });
    } catch (_) {
      throw new Error("Luna's engine isn't responding. Close Luna and start her again.");
    }
    if (!res.ok || !res.body) {
      let data = {};
      try { data = await res.json(); } catch (_) { /* keep empty */ }
      throw new Error(data.error || 'That request failed.');
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    let final = null;
    const handle = (line) => {
      if (!line.trim()) return;
      let ev; try { ev = JSON.parse(line); } catch (_) { return; }
      if (ev.t === 'chunk') onChunk(ev.text);
      else if (ev.t === 'status') { if (onStatus) onStatus(ev.text); }
      else if (ev.t === 'done') final = ev.reply;
    };
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) >= 0) { handle(buf.slice(0, i)); buf = buf.slice(i + 1); }
    }
    handle(buf);
    if (!final) throw new Error('The connection to Luna was interrupted.');
    return final;
  }

  function el(tag, props = {}, ...kids) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else if (v === true) node.setAttribute(k, '');
      else if (v !== false && v != null) node.setAttribute(k, v);
    }
    kids.forEach((kid) => kid != null && node.append(kid));
    return node;
  }

  function icon(d) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    for (const part of d.split('|')) {
      const path = document.createElementNS(SVG_NS, 'path');
      path.setAttribute('d', part);
      svg.append(path);
    }
    return svg;
  }
  const ICON = {
    chev: 'M9 6l6 6-6 6',
    folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
    chat: 'M5 5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-7l-5 4v-4H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z',
    plus: 'M12 5v14|M5 12h14',
    edit: 'M4 20h4L19 9l-4-4L4 16z',
    trash: 'M5 7h14|M10 7V4h4v3|M7 7l1 13h8l1-13',
  };

  function store(key, value) {
    try {
      if (value === undefined) return JSON.parse(localStorage.getItem(key) || 'null');
      localStorage.setItem(key, JSON.stringify(value));
    } catch (_) { /* storage can be unavailable; the UI works without it */ }
    return null;
  }

  // ------------------------------------------------------------------ state

  const S = {
    chatId: null,
    chat: null,
    state: 'IDLE',
    busy: false,
    gemini: 'unknown',
    openaiReady: false,
    lastVoice: false,
    name: 'Luna',
    title: 'sir',
    photos: [],
    syncPaired: false,
    syncRev: -1,
    setup: '',
    overview: { projects: [], chats: [] },
    query: '',
    closed: new Set(store('luna.closedProjects') || []), // projects start expanded so every chat is visible
  };

  const els = {
    stateLabel: $('#stateLabel'), stateLine: $('#stateLine'), core: $('#coreSvg'),
    convo: $('#convo'), convoTitle: $('#convoTitle'),
    input: $('#input'), form: $('#form'), stop: $('#stopBtn'), mic: $('#micBtn'),
    chipGemini: $('#chipGemini'), subtitle: $('#subtitle'),
    drawer: $('#drawer'), scrim: $('#scrim'), menuBtn: $('#menuBtn'), list: $('#drawerList'),
    search: $('#search'), toast: $('#toast'),
  };

  // ------------------------------------------------------------------ states

  function greeting() {
    const h = new Date().getHours();
    const part = h < 5 ? 'Good evening' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
    return `${part}. How can I help?`;
  }

  let errorTimer = null;
  function setState(name, line) {
    S.state = name;
    document.body.dataset.state = name;
    els.stateLabel.textContent = name;
    els.stateLine.textContent = line || (name === 'IDLE' ? idleHint() : greeting());
    els.core.setAttribute('aria-label', 'Luna core, state: ' + name.toLowerCase());
    els.stop.hidden = name !== 'SPEAKING';
    wave.restart();
    clearTimeout(errorTimer);
    if (name === 'ERROR') {
      errorTimer = setTimeout(() => { if (S.state === 'ERROR') setState('IDLE'); }, 9000);
    }
  }

  function applyStatus(st) {
    S.gemini = st.gemini;
    S.setup = st.setup_message || '';
    if (st.providers) S.openaiReady = st.providers.some((p) => p.id === 'openai' && p.configured);
    if (st.assistant) applyProfile(st.assistant);
    if (st.sync) { S.syncPaired = !!st.sync.paired; if (S.syncRev < 0) S.syncRev = st.sync.revision; }
    const chip = els.chipGemini;
    const map = {
      missing_key: ['KEY MISSING', 'bad', 'SETUP NEEDED'],
      configured: ['KEY SET', 'warn', 'KEY SET'],
      ready: ['READY', 'ok', 'ONLINE'],
      error: ['ERROR', 'bad', 'OFFLINE'],
    };
    const [label, tone, sub] = map[st.gemini] || ['…', 'warn', 'STARTING'];
    chip.textContent = label;
    chip.dataset.tone = tone;
    els.subtitle.textContent = 'AI ASSISTANT · ' + sub;
  }

  // ------------------------------------------------------------------ waveform

  const wave = (() => {
    const canvas = $('#wave');
    const ctx = canvas.getContext('2d');
    const BARS = 72;
    let w = 0, h = 0, raf = 0, last = 0, ext = 0, extAt = 0;
    const css = (name) => getComputedStyle(document.body).getPropertyValue(name).trim() || '#35c9ea';

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const r = canvas.getBoundingClientRect();
      w = Math.max(1, Math.round(r.width * dpr));
      h = Math.max(1, Math.round(r.height * dpr));
      canvas.width = w; canvas.height = h;
      draw(performance.now());
    }

    function amplitude(i, t) {
      const x = i / (BARS - 1);
      const envelope = Math.sin(Math.PI * x) ** 1.2; // taller in the middle
      switch (S.state) {
        case 'LISTENING':
        case 'SPEAKING': {
          const live = performance.now() - extAt < 400 ? ext : null; // real mic/speaker level when provided
          const base = live !== null ? 0.25 + 0.75 * live : 0.55;
          const n = Math.sin(t * 0.009 + i * 0.7) * Math.sin(t * 0.0053 + i * 1.9);
          return envelope * base * (0.35 + 0.65 * Math.abs(n)) + 0.04;
        }
        case 'THINKING': {
          const pos = (t * 0.0007) % 1.4 - 0.2;
          const d = Math.abs(x - pos);
          return Math.max(0.04, Math.exp(-d * d * 90) * 0.9);
        }
        default:
          return 0.0;
      }
    }

    function draw(t) {
      ctx.clearRect(0, 0, w, h);
      const accent = css('--accent');
      const violet = css('--violet');
      const step = w / BARS;
      const bw = Math.max(1.5, step * 0.38);
      ctx.fillStyle = accent;
      for (let i = 0; i < BARS; i++) {
        const a = amplitude(i, t);
        const bh = Math.max(bw, a * h);
        ctx.fillStyle = a > 0.3 && i % 6 === 3 ? violet : accent;
        ctx.globalAlpha = a > 0 ? 0.55 + 0.45 * Math.min(1, a * 1.5) : 0.55;
        ctx.fillRect(i * step + (step - bw) / 2, (h - bh) / 2, bw, bh);
      }
      ctx.globalAlpha = 1;
    }

    function loop(t) {
      raf = 0;
      if (document.hidden) return;
      if (t - last >= 33) { last = t; draw(t); } // ~30 fps keeps old laptops cool
      if (S.state === 'LISTENING' || S.state === 'SPEAKING' || S.state === 'THINKING') raf = requestAnimationFrame(loop);
    }

    function restart() {
      cancelAnimationFrame(raf);
      raf = 0;
      draw(performance.now());
      if (S.state === 'LISTENING' || S.state === 'SPEAKING' || S.state === 'THINKING') raf = requestAnimationFrame(loop);
    }

    new ResizeObserver(resize).observe(canvas);
    return { restart, resize, setLevel(v) { ext = Math.max(0, Math.min(1, v)); extAt = performance.now(); } };
  })();

  // ------------------------------------------------------------------ toast + modal

  let toastTimer = null;
  function toast(text) {
    els.toast.textContent = text;
    els.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { els.toast.hidden = true; }, 3800);
  }

  const modal = { root: $('#modal'), title: $('#modalTitle span'), body: $('#modalBody'), actions: $('#modalActions'), restore: null, onEsc: null };

  function openModal(title, bodyNode, buttons, onEsc) {
    modal.title.textContent = title;
    modal.body.replaceChildren(bodyNode);
    modal.actions.replaceChildren(...buttons);
    modal.restore = document.activeElement;
    modal.onEsc = onEsc || closeModal;
    modal.root.hidden = false;
    const first = modal.body.querySelector('input') || modal.actions.querySelector('button:last-child');
    if (first) first.focus();
  }
  function closeModal() {
    modal.root.hidden = true;
    modal.onEsc = null;
    if (modal.restore && modal.restore.focus) modal.restore.focus();
  }

  function confirmDialog(title, message, confirmLabel) {
    return new Promise((resolve) => {
      const done = (v) => { closeModal(); resolve(v); };
      openModal(title, el('p', { text: message }), [
        el('button', { class: 'btn', text: 'CANCEL', onclick: () => done(false) }),
        el('button', { class: 'btn danger', text: confirmLabel, onclick: () => done(true) }),
      ], () => done(false));
    });
  }

  function promptDialog(title, label, initial, okLabel) {
    return new Promise((resolve) => {
      const input = el('input', { class: 'modal-input', type: 'text', maxlength: '60', value: initial || '', 'aria-label': label, placeholder: label });
      const done = (v) => { closeModal(); resolve(v); };
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); done(input.value); } });
      openModal(title, input, [
        el('button', { class: 'btn', text: 'CANCEL', onclick: () => done(null) }),
        el('button', { class: 'btn primary', text: okLabel || 'OK', onclick: () => done(input.value) }),
      ], () => done(null));
      input.select();
    });
  }

  function scrollDown() { els.convo.scrollTop = els.convo.scrollHeight; }

  function addMsg(role, text, who) {
    const label = who || (role === 'you' ? 'YOU' : S.name.toUpperCase());
    const node = el('div', { class: 'msg ' + role, 'data-role': role, 'data-label': label }, el('span', { class: 'who', text: label }), el('div', { class: 'body' }));
    setBody(node, text);
    els.convo.append(node);
    scrollDown();
    return node;
  }

  function addTyping() {
    const node = el('div', { class: 'msg luna', 'aria-label': S.name + ' is thinking' }, el('span', { class: 'who', text: S.name.toUpperCase() }),
      el('div', { class: 'body' }, el('span', { class: 'dots' }, el('span'), el('span'), el('span'))));
    els.convo.append(node);
    scrollDown();
    return node;
  }

  function showWelcome() {
    els.convo.replaceChildren();
    if (S.gemini === 'missing_key') {
      addMsg('err', S.setup, 'SETUP NEEDED');
    } else {
      els.convo.append(el('p', { class: 'welcome', text: 'Type a message, or say “new chat” or “new project” to start fresh. Open the menu to see all your chats.' }));
    }
  }

  function renderChat(chat) {
    S.chatId = chat.id;
    S.chat = chat;
    const title = chat.project ? `${chat.project.name} / ${chat.title}` : chat.title;
    els.convoTitle.textContent = title.toUpperCase();
    els.convoTitle.title = title;
    els.convo.replaceChildren();
    if (!chat.messages.length) showWelcome();
    else chat.messages.forEach((m) => addMsg(m.role === 'user' ? 'you' : 'luna', m.text));
    scrollDown();
    highlightActive();
  }

  function firstSentence(text, max = 90) {
    const flat = text.replace(/\s+/g, ' ').trim();
    const cut = flat.search(/[.!?](\s|$)/);
    const s = cut > 12 ? flat.slice(0, cut + 1) : flat;
    return s.length > max ? s.slice(0, max - 1).trimEnd() + '…' : s;
  }

  async function send(text, opts = {}) {
    text = (text || '').trim();
    const photos = S.photos.slice();
    if (!text && photos.length) text = 'Look at this photo and tell me about it.';
    if (!text || S.busy) return;
    Voice.stop();
    S.lastVoice = !!opts.voice;
    const speakIt = Voice.supported && (!!opts.voice || prefs.speakAll);
    let fedLen = 0, curEmo = '';
    if (speakIt) Voice.begin();
    Mic.hold(true);
    showInterim('');
    S.busy = true;
    S.photos = []; renderStrip();
    els.form.classList.add('busy');
    const sentTo = S.chatId;
    els.convo.querySelector('.welcome')?.remove();
    if (S.gemini === 'missing_key') els.convo.querySelector('.msg.err')?.remove();
    const mine = addMsg('you', text);
    photos.forEach((p) => mine.querySelector('.body').append(el('img', { class: 'thumb', src: p.url, alt: 'your photo' })));
    const typing = addTyping();
    els.input.value = '';
    setState('THINKING', 'Thinking…');

    let r = null;
    let live = null;
    let liveText = '';
    try {
      r = await apiSend({ chat_id: sentTo, text, images: photos.map((p) => ({ mime: p.mime, data: p.data })) }, (piece) => {
        liveText += piece;
        const { emotion, body } = parseEmotion(liveText);
        if (emotion && emotion !== curEmo) { curEmo = emotion; Voice.setEmotion(emotion); document.body.dataset.emotion = emotion; }
        if (speakIt && body.length > fedLen) { Voice.feed(body.slice(fedLen)); fedLen = body.length; }
        if (!live) { typing.remove(); live = addMsg('luna', liveText); } else { setBody(live, liveText); scrollDown(); }
      }, (status) => setState('THINKING', status));
    } catch (e) {
      r = { ok: false, text: e.message, error_kind: 'ai', restore_text: text };
    }
    typing.remove();
    if (live && !r.ok) { live.remove(); live = null; Voice.stop(); }

    if (!r.ok) {
      mine.remove();
      S.photos = photos; renderStrip(); // keep the photos so they can be sent again
      els.input.value = r.restore_text || text;
      const missing = r.error_kind === 'missing_key';
      if (missing) applyStatus({ gemini: 'missing_key', setup_message: r.text });
      else if (S.gemini !== 'missing_key') applyStatus({ gemini: 'error', setup_message: S.setup });
      if (S.chatId === sentTo || !sentTo) addMsg('err', r.text, missing ? 'SETUP NEEDED' : 'ERROR');
      setState('ERROR', missing ? 'API key needed' : firstSentence(r.text));
      S.lastVoice = false;
      if (missing) settingsDialog();
    } else if (r.action) {
      renderChat(r.chat);
      toast(r.text);
      setState('IDLE');
    } else {
      applyStatus({ gemini: 'ready', setup_message: '' });
      const parsed = parseEmotion(r.text);
      if (r.chat && (S.chatId === sentTo || !sentTo)) {
        S.chatId = r.chat.id;
        if (live) setBody(live, r.text); else addMsg('luna', r.text);
        els.convoTitle.textContent = (r.chat.project ? `${r.chat.project.name} / ${r.chat.title}` : r.chat.title).toUpperCase();
        const blocks = extractCode(parsed.body);
        if (blocks.length && prefs.codePopup) codePopup(blocks);
      } else if (r.chat) {
        toast(`${S.name} replied in “${r.chat.title}”.`);
      }
      if (speakIt) {
        if (!fedLen) { Voice.setEmotion(parsed.emotion); document.body.dataset.emotion = parsed.emotion; Voice.feed(parsed.body); }
        Voice.finish();
      }
      setState(Voice.speaking ? 'SPEAKING' : 'IDLE', Voice.speaking ? 'Speaking…' : undefined);
    }

    S.busy = false;
    if (!Voice.speaking) onIdle();
    els.form.classList.remove('busy');
    els.input.focus();
    refreshMenu();
    refreshActivity();
  }

  // ------------------------------------------------------------------ menu drawer

  function openDrawer() {
    els.drawer.classList.add('open');
    els.drawer.removeAttribute('inert');
    els.drawer.setAttribute('aria-hidden', 'false');
    els.scrim.hidden = false;
    els.menuBtn.setAttribute('aria-expanded', 'true');
    refreshMenu();
    $('#newChatBtn').focus();
  }
  function closeDrawer() {
    if (!els.drawer.classList.contains('open')) return;
    els.drawer.classList.remove('open');
    els.drawer.setAttribute('inert', '');
    els.drawer.setAttribute('aria-hidden', 'true');
    els.scrim.hidden = true;
    els.menuBtn.setAttribute('aria-expanded', 'false');
    els.menuBtn.focus();
  }
  const toggleDrawer = () => (els.drawer.classList.contains('open') ? closeDrawer() : openDrawer());

  async function refreshMenu() {
    try { S.overview = await api('overview', { query: S.query, keep_id: S.chatId || '' }); } catch (_) { return; }
    renderMenu();
  }

  function highlightActive() {
    els.list.querySelectorAll('.row[data-chat]').forEach((row) => row.classList.toggle('active', row.dataset.chat === S.chatId));
  }

  function actBtn(label, path, cls, handler) {
    const b = el('button', { class: 'row-act ' + (cls || ''), 'aria-label': label, title: label, type: 'button' }, icon(path));
    b.addEventListener('click', (e) => { e.stopPropagation(); handler(); });
    return b;
  }

  function chatRow(c) {
    const main = el('button', { class: 'row-main', type: 'button', title: c.title },
      icon(ICON.chat), el('span', { class: 't', text: c.title }), el('span', { class: 'n', text: c.count ? String(c.count) : '' }));
    main.addEventListener('click', () => openChat(c.id));
    const row = el('div', { class: 'row', 'data-chat': c.id }, main,
      el('div', { class: 'row-acts' },
        actBtn('Rename chat', ICON.edit, '', () => inlineRename(row, main, c.title, (v) => api('rename_chat', { chat_id: c.id, title: v }))),
        actBtn('Delete chat', ICON.trash, 'del', () => deleteChat(c))));
    if (c.id === S.chatId) row.classList.add('active');
    return row;
  }

  function projectRow(p) {
    const open = !S.closed.has(p.id) || (S.query && p.chats.length > 0);
    const chev = icon(ICON.chev);
    chev.classList.add('chev');
    const main = el('button', { class: 'row-main', type: 'button', 'aria-expanded': String(open) },
      chev, icon(ICON.folder), el('span', { class: 't', text: p.name }), el('span', { class: 'n', text: String(p.chats.length) }));
    const wrap = el('div', { class: 'proj' + (open ? ' open' : '') });
    main.addEventListener('click', () => {
      wrap.classList.toggle('open');
      const isOpen = wrap.classList.contains('open');
      main.setAttribute('aria-expanded', String(isOpen));
      isOpen ? S.closed.delete(p.id) : S.closed.add(p.id);
      store('luna.closedProjects', [...S.closed]);
    });
    const head = el('div', { class: 'row' }, main,
      el('div', { class: 'row-acts' },
        actBtn('New chat in this project', ICON.plus, '', async () => {
          try { renderChat(await api('new_chat', { project_id: p.id })); } catch (e) { toast(e.message); return; }
          S.closed.delete(p.id); store('luna.closedProjects', [...S.closed]);
          setState('IDLE'); await refreshMenu(); closeDrawer(); els.input.focus();
        }),
        actBtn('Rename project', ICON.edit, '', () => inlineRename(head, main, p.name, (v) => api('rename_project', { project_id: p.id, name: v }))),
        actBtn('Delete project', ICON.trash, 'del', () => deleteProject(p))));
    const body = el('div', { class: 'proj-body' }, ...p.chats.map(chatRow));
    if (!p.chats.length) body.append(el('p', { class: 'none-yet', text: 'No chats yet' }));
    wrap.append(head, body);
    return wrap;
  }

  function renderMenu() {
    const { projects, chats } = S.overview;
    const nodes = [];
    nodes.push(el('div', { class: 'sec' }, el('span', { text: 'PROJECTS' }), el('span', { text: String(projects.length) })));
    if (!projects.length) nodes.push(el('p', { class: 'none-yet', text: S.query ? 'No matches' : 'No projects yet' }));
    projects.forEach((p) => nodes.push(projectRow(p)));
    nodes.push(el('div', { class: 'sec' }, el('span', { text: 'CHATS' }), el('span', { text: String(chats.length) })));
    if (!chats.length) nodes.push(el('p', { class: 'none-yet', text: S.query ? 'No matches' : 'No chats yet' }));
    chats.forEach((c) => nodes.push(chatRow(c)));
    els.list.replaceChildren(...nodes);
  }

  function inlineRename(row, main, current, commit) {
    const input = el('input', { class: 'row-edit', type: 'text', maxlength: '60', value: current, 'aria-label': 'New name' });
    let finished = false;
    const finish = async (save) => {
      if (finished) return;
      finished = true;
      const value = input.value.trim();
      if (save && value && value !== current) {
        try { await commit(value); } catch (e) { toast(e.message); }
      }
      await refreshMenu();
      if (S.chatId) { try { renderChat(await api('open_chat', { chat_id: S.chatId })); } catch (_) { /* chat may be gone */ } }
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
    main.replaceWith(input);
    input.focus();
    input.select();
  }

  async function openChat(id) {
    try { renderChat(await api('open_chat', { chat_id: id })); } catch (e) { toast(e.message); refreshMenu(); return; }
    setState('IDLE');
    closeDrawer();
    els.input.focus();
  }

  async function reopenAfterDelete() {
    try { renderChat(await api('start')); } catch (e) { toast(e.message); }
    await refreshMenu();
  }

  async function deleteChat(c) {
    const ok = await confirmDialog('DELETE CHAT', `Delete “${c.title}”? This can't be undone.`, 'DELETE');
    if (!ok) return;
    try { await api('delete_chat', { chat_id: c.id }); } catch (e) { toast(e.message); return; }
    toast('Chat deleted.');
    if (c.id === S.chatId) await reopenAfterDelete(); else await refreshMenu();
  }

  async function deleteProject(p) {
    const n = p.chats.length;
    const msg = n ? `Delete the project “${p.name}” and its ${n} chat${n === 1 ? '' : 's'}? This can't be undone.` : `Delete the empty project “${p.name}”?`;
    const ok = await confirmDialog('DELETE PROJECT', msg, 'DELETE');
    if (!ok) return;
    const wasInside = p.chats.some((c) => c.id === S.chatId);
    try { await api('delete_project', { project_id: p.id }); } catch (e) { toast(e.message); return; }
    toast('Project deleted.');
    if (wasInside) await reopenAfterDelete(); else await refreshMenu();
  }

  async function newChat() {
    try { renderChat(await api('new_chat')); } catch (e) { toast(e.message); return; }
    setState('IDLE');
    await refreshMenu();
    closeDrawer();
    els.input.focus();
  }

  async function newProject() {
    const name = await promptDialog('NEW PROJECT', 'Project name (optional)', '', 'CREATE');
    if (name === null) return;
    try { renderChat(await api('new_project', { name: name.trim() })); } catch (e) { toast(e.message); return; }
    setState('IDLE');
    await refreshMenu();
    closeDrawer();
    els.input.focus();
  }

  // ------------------------------------------------------------------ side panels

  function setMeter(id, valId, value, extra) {
    const bar = $('#' + id), val = $('#' + valId);
    if (value === null || value === undefined) { bar.style.width = '0'; val.textContent = '—'; return; }
    bar.style.width = value + '%';
    bar.classList.toggle('hot', value >= 85);
    val.textContent = value + '%';
    if (extra !== undefined) val.title = extra;
  }

  async function pollSystem() {
    if (!document.hidden) {
      try {
        const s = await api('system');
        setMeter('mCpu', 'vCpu', s.cpu);
        setMeter('mRam', 'vRam', s.ram);
        setMeter('mDisk', 'vDisk', s.disk);
        setMeter('mBat', 'vBat', s.battery, s.charging ? 'Charging' : 'On battery');
      } catch (_) { /* engine briefly busy; try again next tick */ }
    }
    setTimeout(pollSystem, 3000);
  }

  const hhmm = (ts) => new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  async function refreshActivity() {
    let items;
    try { items = (await api('activity')).items; } catch (_) { return; }
    $('#actCount').textContent = String(items.length);
    const list = $('#activity');
    if (!items.length) { list.replaceChildren(el('li', { class: 'none', text: 'No activity yet' })); return; }
    list.replaceChildren(...items.slice(0, 4).map((i) => el('li', { 'data-kind': i.kind }, el('span', { text: i.detail, title: i.detail }), el('time', { text: hhmm(i.ts) }))));
  }

  // ------------------------------------------------------------------ language helpers

  const LANGS = [
    ['en-US', 'English (US)', 'EN'], ['en-IN', 'English (India)', 'EN'], ['en-GB', 'English (UK)', 'EN'],
    ['hi-IN', 'Hindi · हिन्दी', 'HI'], ['bn-IN', 'Bengali · বাংলা', 'BN'], ['ta-IN', 'Tamil · தமிழ்', 'TA'],
    ['te-IN', 'Telugu · తెలుగు', 'TE'], ['mr-IN', 'Marathi · मराठी', 'MR'], ['gu-IN', 'Gujarati · ગુજરાતી', 'GU'],
    ['kn-IN', 'Kannada · ಕನ್ನಡ', 'KN'], ['ml-IN', 'Malayalam · മലയാളം', 'ML'], ['pa-IN', 'Punjabi · ਪੰਜਾਬੀ', 'PA'],
    ['ur-IN', 'Urdu · اردو', 'UR'], ['es-ES', 'Spanish', 'ES'], ['fr-FR', 'French', 'FR'], ['de-DE', 'German', 'DE'],
    ['it-IT', 'Italian', 'IT'], ['pt-BR', 'Portuguese', 'PT'], ['ru-RU', 'Russian', 'RU'], ['ar-SA', 'Arabic', 'AR'],
    ['tr-TR', 'Turkish', 'TR'], ['id-ID', 'Indonesian', 'ID'], ['nl-NL', 'Dutch', 'NL'], ['th-TH', 'Thai', 'TH'],
    ['vi-VN', 'Vietnamese', 'VI'], ['ja-JP', 'Japanese', 'JA'], ['ko-KR', 'Korean', 'KO'], ['zh-CN', 'Chinese', 'ZH'],
  ];
  const langShort = (code) => (LANGS.find((l) => l[0] === code) || [0, 0, (code || 'EN').slice(0, 2).toUpperCase()])[2];

  // Devanagari (Hindi) -> Hinglish: Hindi pronunciation written in English letters.
  const HINGLISH_WORDS = {
    'में': 'mein', 'है': 'hai', 'हैं': 'hain', 'नहीं': 'nahi', 'क्या': 'kya', 'कैसे': 'kaise', 'कौन': 'kaun', 'क्यों': 'kyun',
    'और': 'aur', 'मैं': 'main', 'हूँ': 'hoon', 'हूं': 'hoon', 'हो': 'ho', 'तुम': 'tum', 'आप': 'aap', 'हम': 'hum', 'यह': 'yeh',
    'वह': 'woh', 'ये': 'ye', 'वो': 'wo', 'का': 'ka', 'की': 'ki', 'के': 'ke', 'को': 'ko', 'से': 'se', 'पर': 'par', 'भी': 'bhi',
    'तो': 'to', 'ही': 'hi', 'एक': 'ek', 'कुछ': 'kuch', 'बहुत': 'bahut', 'अच्छा': 'accha', 'ठीक': 'theek', 'मुझे': 'mujhe',
    'तुम्हें': 'tumhe', 'बताओ': 'batao', 'बताइए': 'bataiye', 'बनाओ': 'banao', 'दो': 'do', 'कर': 'kar', 'करो': 'karo',
    'नाम': 'naam', 'आज': 'aaj', 'कल': 'kal', 'अभी': 'abhi', 'धन्यवाद': 'dhanyavaad', 'शुक्रिया': 'shukriya',
    'नमस्ते': 'namaste', 'चाहिए': 'chahiye', 'चाहिये': 'chahiye', 'हाँ': 'haan', 'हां': 'haan', 'जी': 'ji', 'लूना': 'luna', 'लुना': 'luna', 'सर': 'sir',
    'कहाँ': 'kahan', 'कहां': 'kahan', 'कब': 'kab', 'कितना': 'kitna', 'लिए': 'liye', 'साथ': 'saath', 'सब': 'sab',
  };
  const D_CONS = { 'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'ng', 'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'ny',
    'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n', 'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n', 'प': 'p',
    'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm', 'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'श': 'sh', 'ष': 'sh', 'स': 's',
    'ह': 'h', 'ळ': 'l' };
  const D_NUKTA = { 'क': 'q', 'ख': 'kh', 'ग': 'g', 'ज': 'z', 'ड': 'r', 'ढ': 'rh', 'फ': 'f' };
  const D_VOWEL = { 'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee', 'उ': 'u', 'ऊ': 'oo', 'ऋ': 'ri', 'ए': 'e', 'ऐ': 'ai', 'ओ': 'o',
    'औ': 'au', 'ऑ': 'o', 'ऍ': 'e' };
  const D_MATRA = { 'ा': 'aa', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo', 'ृ': 'ri', 'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au',
    'ॉ': 'o', 'ॅ': 'e' };

  function hindiWord(w) {
    if (HINGLISH_WORDS[w]) return HINGLISH_WORDS[w];
    const units = [];
    for (let i = 0; i < w.length; i++) {
      const ch = w[i];
      if (D_CONS[ch]) {
        let c = D_CONS[ch];
        if (w[i + 1] === '\u093c') { c = D_NUKTA[ch] || c; i++; }
        if (w[i + 1] === '\u094d') { units.push({ c, v: '', halant: true }); i++; continue; }
        if (D_MATRA[w[i + 1]]) { units.push({ c, v: D_MATRA[w[i + 1]] }); i++; } else units.push({ c, v: 'a', inherent: true });
      } else if (D_VOWEL[ch]) units.push({ c: '', v: D_VOWEL[ch] });
      else if ((ch === 'ं' || ch === 'ँ') && units.length) units[units.length - 1].nasal = true;
      else if (ch === 'ः' && units.length) units[units.length - 1].visarga = true;
      else if (ch >= '०' && ch <= '९') units.push({ c: String(ch.charCodeAt(0) - 0x966), v: '' });
      else if (ch === '।' || ch === '॥') units.push({ c: '.', v: '' });
    }
    // Hindi drops many inherent "a" sounds: at the end of a word, and between two sounded syllables.
    for (let k = units.length - 1; k >= 0; k--) {
      const u = units[k];
      if (!u.inherent) continue;
      if (k === units.length - 1) { if (units.length > 1) u.v = ''; continue; }
      const prev = units[k - 1], next = units[k + 1];
      if (k > 0 && !prev.halant && next && !next.halant && next.v !== '') u.v = '';
    }
    const last = units[units.length - 1];
    if (last && units.length > 1 && !last.nasal) {
      if (last.v === 'aa') last.v = 'a'; else if (last.v === 'ee') last.v = 'i'; else if (last.v === 'oo') last.v = 'u';
    }
    return units.map((u, k) => {
      let n = '';
      if (u.nasal) { const nx = units[k + 1]; n = nx && /^(p|b|m|ph|bh)/.test(nx.c) ? 'm' : 'n'; }
      return u.c + u.v + n + (u.visarga ? 'h' : '');
    }).join('');
  }
  function hinglish(text) {
    if (!/[\u0900-\u097F]/.test(text)) return text;
    return text.normalize('NFC').replace(/[\u0900-\u097F]+/g, hindiWord);
  }
  const display = (text) => (prefs.hinglish ? hinglish(text) : text);

  // Which language is this text written in? (used to pick the right spoken voice)
  function scriptLang(t) {
    if (/[\u0900-\u097F]/.test(t)) return 'hi-IN';
    if (/[\u0B80-\u0BFF]/.test(t)) return 'ta-IN';
    if (/[\u0C00-\u0C7F]/.test(t)) return 'te-IN';
    if (/[\u0C80-\u0CFF]/.test(t)) return 'kn-IN';
    if (/[\u0D00-\u0D7F]/.test(t)) return 'ml-IN';
    if (/[\u0980-\u09FF]/.test(t)) return 'bn-IN';
    if (/[\u0A80-\u0AFF]/.test(t)) return 'gu-IN';
    if (/[\u0A00-\u0A7F]/.test(t)) return 'pa-IN';
    if (/[\u0600-\u06FF]/.test(t)) return 'ar-SA';
    if (/[\u0E00-\u0E7F]/.test(t)) return 'th-TH';
    if (/[\u3040-\u30FF]/.test(t)) return 'ja-JP';
    if (/[\uAC00-\uD7AF]/.test(t)) return 'ko-KR';
    if (/[\u4E00-\u9FFF]/.test(t)) return 'zh-CN';
    if (/[\u0400-\u04FF]/.test(t)) return 'ru-RU';
    return null;
  }

  // ------------------------------------------------------------------ emotions

  const EMO = {
    happy: { p: 1.08, r: 1.05, e: '😊' }, excited: { p: 1.18, r: 1.15, e: '🤩' }, calm: { p: 0.98, r: 0.95, e: '😌' },
    sad: { p: 0.88, r: 0.88, e: '😢' }, caring: { p: 1.0, r: 0.95, e: '🤗' }, curious: { p: 1.06, r: 1.0, e: '🤔' },
    playful: { p: 1.12, r: 1.08, e: '😄' }, serious: { p: 0.94, r: 1.0, e: '🧐' },
  };
  // "[happy] Yes sir..." -> { emotion: 'happy', body: 'Yes sir...' }; the tag is never shown or spoken.
  function parseEmotion(text) {
    const m = /^\s*\[([a-z]+)\]\s*/i.exec(text);
    if (m && EMO[m[1].toLowerCase()]) return { emotion: m[1].toLowerCase(), body: text.slice(m[0].length) };
    if (/^\s*\[[a-z]{0,10}$/i.test(text)) return { emotion: '', body: '' }; // the tag is still arriving
    return { emotion: '', body: text };
  }

  // ------------------------------------------------------------------ files: save, zip, code

  const EXT = { python: 'py', py: 'py', javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', html: 'html', css: 'css', json: 'json',
    java: 'java', kotlin: 'kt', c: 'c', cpp: 'cpp', 'c++': 'cpp', csharp: 'cs', 'c#': 'cs', go: 'go', rust: 'rs', php: 'php',
    ruby: 'rb', swift: 'swift', sql: 'sql', bash: 'sh', sh: 'sh', shell: 'sh', powershell: 'ps1', xml: 'xml', yaml: 'yml',
    yml: 'yml', markdown: 'md', md: 'md', dart: 'dart', r: 'r', lua: 'lua', jsx: 'jsx', tsx: 'tsx', text: 'txt', '': 'txt' };
  const DEFAULT_NAME = { py: 'main.py', js: 'script.js', html: 'index.html', css: 'style.css', java: 'Main.java', cpp: 'main.cpp', c: 'main.c',
    sh: 'script.sh', json: 'data.json', ts: 'index.ts', go: 'main.go', rs: 'main.rs', php: 'index.php', kt: 'Main.kt', cs: 'Program.cs' };

  function extractCode(text) {
    const blocks = [];
    const used = new Set();
    const re = /(?:^|\n)((?:[^\n]*\n)??)[ \t]*```([\w+#.-]*)[^\n]*\n([\s\S]*?)(?:```|$)/g;
    let m;
    while ((m = re.exec(text))) {
      const lang = (m[2] || '').toLowerCase();
      const code = m[3].replace(/\n$/, '');
      if (!code.trim()) continue;
      const prev = m[1].trim().split('\n').pop() || '';
      const named = /^\W*(?:file(?:name)?)\s*[:\-]\s*`?([\w./\\-]+\.\w+)`?\W*$/i.exec(prev);
      const ext = EXT[lang] || (lang && /^\w{1,5}$/.test(lang) ? lang : 'txt');
      let name = named ? named[1].split(/[\\/]/).pop() : (DEFAULT_NAME[ext] || 'code.' + ext);
      for (let i = 2; used.has(name); i++) name = name.replace(/(\.\w+)?$/, (x) => '-' + i + (x || ''));
      used.add(name);
      blocks.push({ name, lang: lang || ext, code });
    }
    return blocks;
  }

  const CRC = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function makeZip(files) { // store-only .zip, no library needed
    const enc = new TextEncoder(), chunks = [], central = [];
    let offset = 0;
    const u16 = (n) => [n & 255, (n >> 8) & 255], u32 = (n) => [n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >>> 24) & 255];
    files.forEach((f) => {
      const name = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data);
      const head = new Uint8Array([0x50, 0x4B, 3, 4, 20, 0, 0, 8, 0, 0, 0, 0, 0x21, 0, ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), 0, 0]);
      chunks.push(head, name, data);
      central.push(new Uint8Array([0x50, 0x4B, 1, 2, 20, 0, 20, 0, 0, 8, 0, 0, 0, 0, 0x21, 0, ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ...u32(offset)]), name);
      offset += head.length + name.length + data.length;
    });
    const cdSize = central.reduce((n, c) => n + c.length, 0);
    const end = new Uint8Array([0x50, 0x4B, 5, 6, 0, 0, 0, 0, ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(offset), 0, 0]);
    return new Blob([...chunks, ...central, end], { type: 'application/zip' });
  }

  async function saveFile(name, mime, data) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime });
    if (window.LunaNative && window.LunaNative.saveFile) {
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let bin = '';
      for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      window.LunaNative.saveFile(name, mime, btoa(bin));
      return;
    }
    const url = URL.createObjectURL(blob);
    const a = el('a', { href: url, download: name });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast('Saved ' + name);
  }
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); toast('Copied.'); } catch (_) {
      const t = el('textarea', { style: 'position:fixed;opacity:0' }); t.value = text; document.body.append(t); t.select();
      try { document.execCommand('copy'); toast('Copied.'); } catch (__) { toast('Could not copy.'); }
      t.remove();
    }
  }
  const dlBlock = (b) => saveFile(b.name, 'text/plain', b.code);

  function codePopup(blocks) {
    const body = el('div', { class: 'code-pop' });
    blocks.forEach((b) => {
      body.append(el('div', { class: 'code-pop-head' }, el('b', { text: b.name }), el('span', { text: b.lang + ' · ' + b.code.split('\n').length + ' lines' }),
        el('button', { class: 'btn small', type: 'button', text: 'COPY', onclick: () => copyText(b.code) }),
        el('button', { class: 'btn small primary', type: 'button', text: 'DOWNLOAD', onclick: () => dlBlock(b) })),
      el('pre', { class: 'code-full' }, el('code', { text: b.code })));
    });
    const actions = [];
    if (blocks.length > 1) actions.push(el('button', { class: 'btn primary', text: 'DOWNLOAD ALL (.ZIP)', onclick: () => saveFile('code.zip', 'application/zip', makeZip(blocks.map((b) => ({ name: b.name, text: b.code })))) }));
    else actions.push(el('button', { class: 'btn primary', text: 'DOWNLOAD ' + blocks[0].name, onclick: () => dlBlock(blocks[0]) }));
    actions.push(el('button', { class: 'btn', text: 'CLOSE', onclick: closeModal }));
    openModal(blocks.length > 1 ? blocks.length + ' CODE FILES' : 'CODE · ' + blocks[0].name, body, actions);
  }

  function picturePopup(name, label) {
    const src = '/img/' + name;
    const dl = () => downloadPicture(name);
    openModal('PICTURE', el('img', { class: 'pic-full', src, alt: label || 'picture' }),
      [el('button', { class: 'btn primary', text: 'DOWNLOAD', onclick: dl }), el('button', { class: 'btn', text: 'CLOSE', onclick: closeModal })]);
  }
  async function downloadPicture(name) {
    try {
      const res = await fetch('/img/' + name);
      if (!res.ok) throw new Error('missing');
      const blob = await res.blob();
      await saveFile('luna-' + name, blob.type || 'image/png', blob);
    } catch (_) { toast('That picture is not on this device.'); }
  }

  // ------------------------------------------------------------------ rich message bodies

  const IMG_RE = /\[\[image:([0-9a-f]{24}\.(?:png|jpg|webp))\|([^\]]*)\]\]/g;
  function renderRich(text) {
    const nodes = [];
    const pushText = (t, hideFileLine) => {
      let s = t;
      if (hideFileLine) s = s.replace(/(?:^|\n)\W*file(?:name)?\s*[:\-]\s*`?[\w./\\-]+\.\w+`?\W*$/i, '');
      let last = 0, m;
      IMG_RE.lastIndex = 0;
      while ((m = IMG_RE.exec(s))) {
        if (m.index > last) nodes.push(document.createTextNode(display(s.slice(last, m.index))));
        nodes.push(pictureCard(m[1], m[2]));
        last = m.index + m[0].length;
      }
      if (last < s.length) nodes.push(document.createTextNode(display(s.slice(last))));
    };
    const blocks = extractCode(text);
    const fence = /```([\w+#.-]*)[^\n]*\n([\s\S]*?)(?:```|$)/g;
    let last = 0, m, i = 0;
    while ((m = fence.exec(text))) {
      if (!m[2].trim()) continue;
      pushText(text.slice(last, m.index), true);
      nodes.push(codeCard(blocks[i] || { name: 'code.txt', lang: m[1], code: m[2] }, blocks));
      i++;
      last = m.index + m[0].length;
    }
    pushText(text.slice(last), false);
    return nodes;
  }
  function codeCard(b, all) {
    const lines = b.code.split('\n');
    const card = el('div', { class: 'code-card', role: 'button', tabindex: '0', title: 'Tap to open' },
      el('div', { class: 'code-head' }, el('b', { text: b.name }), el('span', { text: b.lang + ' · ' + lines.length + ' lines' }),
        el('button', { class: 'btn small', type: 'button', text: 'COPY', onclick: (e) => { e.stopPropagation(); copyText(b.code); } }),
        el('button', { class: 'btn small primary', type: 'button', text: 'DOWNLOAD', onclick: (e) => { e.stopPropagation(); dlBlock(b); } })),
      el('pre', { class: 'code-prev' }, el('code', { text: lines.slice(0, 7).join('\n') + (lines.length > 7 ? '\n…' : '') })));
    const open = () => codePopup(all.length ? all : [b]);
    card.addEventListener('click', open);
    card.addEventListener('keydown', (e) => { if (e.key === 'Enter') open(); });
    return card;
  }
  function pictureCard(name, label) {
    const img = el('img', { src: '/img/' + name, alt: label || 'picture', loading: 'lazy' });
    img.addEventListener('click', () => picturePopup(name, label));
    img.addEventListener('error', () => { img.replaceWith(el('span', { class: 'pic-missing', text: '(picture is not on this device)' })); });
    return el('figure', { class: 'pic' }, img,
      el('button', { class: 'btn small primary', type: 'button', text: 'DOWNLOAD', onclick: () => downloadPicture(name) }));
  }

  function setBody(node, text) {
    const role = node.dataset.role;
    let shown = text;
    if (role === 'luna') {
      const p = parseEmotion(text);
      shown = p.body;
      node.dataset.emotion = p.emotion;
      node.querySelector('.who').textContent = node.dataset.label + (p.emotion ? ' ' + EMO[p.emotion].e : '');
    }
    node.querySelector('.body').replaceChildren(...renderRich(shown));
    node.dataset.raw = text;
  }

  // ------------------------------------------------------------------ photos to send

  const MAX_PHOTOS = 4;
  function renderStrip() {
    const strip = $('#attachStrip');
    strip.hidden = !S.photos.length;
    strip.replaceChildren(...S.photos.map((p, i) => el('div', { class: 'thumb-wrap' }, el('img', { src: p.url, alt: 'attached photo ' + (i + 1) }),
      el('button', { type: 'button', 'aria-label': 'Remove photo', text: '×', onclick: () => { S.photos.splice(i, 1); renderStrip(); } }))));
    $('#attachBtn').classList.toggle('on', S.photos.length > 0);
  }
  function shrink(file) { // resize to at most 1280px and re-encode as JPEG so uploads stay small
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, 1280 / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
        const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        const dataUrl = c.toDataURL('image/jpeg', 0.85);
        resolve({ mime: 'image/jpeg', data: dataUrl.split(',')[1], url: dataUrl });
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad image')); };
      img.src = url;
    });
  }
  async function addPhotos(files) {
    for (const f of Array.from(files || [])) {
      if (!/^image\//.test(f.type)) { toast('Only photos can be attached.'); continue; }
      if (S.photos.length >= MAX_PHOTOS) { toast('You can attach up to ' + MAX_PHOTOS + ' photos.'); break; }
      try { S.photos.push(await shrink(f)); } catch (_) { toast('That photo could not be opened.'); }
    }
    renderStrip();
  }

  // ------------------------------------------------------------------ voice: Luna speaks and listens

  const defaultLang = () => { const n = navigator.language || 'en-US'; return LANGS.some((l) => l[0] === n) ? n : 'en-US'; };
  const prefs = Object.assign({
    speakAll: true, voiceName: '', openaiVoice: false, lang: defaultLang(), lang2: 'hi-IN', useSecond: false,
    wake: true, wakeWord: '', hinglish: true, codePopup: true, muted: false,
  }, store('luna.voice') || {});
  const savePrefs = () => store('luna.voice', prefs);
  const curLang = () => (prefs.useSecond ? prefs.lang2 : prefs.lang) || 'en-US';

  const Voice = (() => {
    const synth = window.speechSynthesis || null;
    const nativeTts = !!(window.LunaNative && window.LunaNative.speak);
    let voices = [], active = 0, token = 0, chain = Promise.resolve(), audioEl = null, buf = '', inCode = false, emo = 'calm', voicesCb = null;
    let nativeWaiters = [];
    const FEMALE = /zira|aria|jenny|michelle|emma|ava|libby|sonia|natasha|clara|hazel|susan|samantha|victoria|karen|moira|tessa|fiona|allison|joanna|kendra|salli|ivy|swara|kalpana|heera|neerja|female|woman|girl|google us english|lekha|veena/i;
    const MALE = /\b(david|mark|guy|james|george|richard|daniel|alex|fred|ryan|brian|madhur|prabhat|hemant|male|man|boy)\b/i;

    function loadVoices() { voices = synth ? synth.getVoices() : []; if (voicesCb) voicesCb(); }
    if (synth) { loadVoices(); if (synth.addEventListener) synth.addEventListener('voiceschanged', loadVoices); }

    function pick(lang) {
      if (!voices.length) return null;
      if (prefs.voiceName && (!lang || lang.slice(0, 2) === (curLang() || '').slice(0, 2))) {
        const chosen = voices.find((x) => x.name === prefs.voiceName); if (chosen) return chosen;
      }
      const norm = (v) => v.lang.replace('_', '-').toLowerCase();
      const want = (lang || navigator.language || 'en-US').toLowerCase();
      const same = voices.filter((v) => norm(v).startsWith(want.slice(0, 2)));
      const pool = same.length ? same : voices;
      const score = (v) => (FEMALE.test(v.name) ? 4 : 0) - (MALE.test(v.name) ? 5 : 0)
        + (/natural|neural|online/i.test(v.name) ? 2 : 0) + (norm(v) === want ? 2 : 0);
      return pool.slice().sort((a, b) => score(b) - score(a))[0];
    }
    function textLang(text) {
      const sl = scriptLang(text); if (sl) return sl;
      const cur = curLang();
      return cur === 'hi-IN' ? 'en-IN' : cur;
    }
    const idleCheck = () => { if (active <= 0 && !S.busy) { active = 0; onIdle(); } };
    const shape = () => { const e = EMO[emo] || EMO.calm; return { pitch: Math.min(2, 1.1 * e.p), rate: Math.min(2, 1.05 * e.r) }; };

    function deviceUtterance(text, lang, done) {
      const u = new SpeechSynthesisUtterance(text);
      const v = pick(lang);
      if (v) { u.voice = v; u.lang = v.lang; } else u.lang = lang;
      const s = shape(); u.pitch = s.pitch; u.rate = s.rate;
      u.onend = u.onerror = done;
      synth.speak(u);
    }
    function speakDevice(text, lang) {
      if (nativeTts) { active++; const s = shape(); window.LunaNative.speak(text, lang, s.pitch, s.rate); return; }
      if (!synth) return;
      const t = token; active++;
      deviceUtterance(text, lang, () => { if (t !== token) return; active--; idleCheck(); });
    }
    function playB64(b64) {
      const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: 'audio/mpeg' }));
      const a = new Audio(url); audioEl = a;
      return new Promise((res, rej) => {
        a.onended = () => { URL.revokeObjectURL(url); res(); };
        a.onerror = () => { URL.revokeObjectURL(url); rej(new Error('audio')); };
        a.play().catch(rej);
      });
    }
    function speakCloud(text, lang) {
      const t = token; active++;
      const fetched = api('speak', { text }).then((r) => r.audio).catch(() => null);
      chain = chain.then(async () => {
        if (t !== token) return;
        const b64 = await fetched;
        if (t !== token) return;
        let ok = false;
        if (b64) { try { await playB64(b64); ok = true; } catch (_) { ok = false; } }
        if (!ok && nativeTts && t === token) await new Promise((res) => { nativeWaiters.push(res); const s = shape(); window.LunaNative.speak(text, lang, s.pitch, s.rate); });
        else if (!ok && synth && t === token) await new Promise((res) => deviceUtterance(text, lang, res));
        if (t !== token) return;
        active--; idleCheck();
      });
    }
    function say(raw) {
      const text = String(raw)
        .replace(/\[\[image:[^\]]*\]\]/g, ' ').replace(/(?:^|\n)\W*file(?:name)?\s*[:\-]\s*`?[\w./\\-]+\.\w+`?\W*(?=\n|$)/gi, ' ')
        .replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '').replace(/[*_`#>~|]+/g, '').replace(/\s+/g, ' ').trim();
      if (!/[\p{L}\p{N}]/u.test(text)) return;
      Mic.hold(true);
      if (S.state !== 'SPEAKING') setState('SPEAKING', 'Speaking…');
      const lang = textLang(text);
      if (prefs.openaiVoice && S.openaiReady) speakCloud(text, lang); else speakDevice(text, lang);
    }
    function flush(force) {
      let m;
      while ((m = /[.!?…।]["')\]]*\s|\n/.exec(buf))) {
        const end = m.index + m[0].length;
        const sentence = buf.slice(0, end); buf = buf.slice(end); say(sentence);
      }
      if (force && buf.trim()) { const rest = buf; buf = ''; say(rest); }
    }

    return {
      supported: !!synth || nativeTts,
      list: () => voices,
      onVoices: (cb) => { voicesCb = cb; },
      say,
      setEmotion(e) { emo = EMO[e] ? e : 'calm'; },
      begin() { buf = ''; inCode = false; emo = 'calm'; },
      feed(piece) { // speak each finished sentence while the rest is still arriving; never read code aloud
        piece.split('```').forEach((part, idx) => {
          if (idx > 0) { if (!inCode) flush(true); inCode = !inCode; }
          if (!inCode) { buf += part; flush(false); }
        });
      },
      finish() { if (!inCode) flush(true); buf = ''; inCode = false; idleCheck(); },
      stop() {
        token++; active = 0; buf = ''; inCode = false; chain = Promise.resolve(); nativeWaiters = [];
        if (nativeTts) window.LunaNative.stopSpeaking();
        if (synth) synth.cancel();
        if (audioEl) { try { audioEl.pause(); } catch (_) { /* ignore */ } audioEl = null; }
      },
      get speaking() { return active > 0; },
      done() { // the Android app calls this each time the phone finishes one sentence
        if (nativeWaiters.length) { nativeWaiters.shift()(); return; }
        if (active > 0) { active--; idleCheck(); }
      },
    };
  })();
  window.__lunaSpeechDone = () => Voice.done();

  function onIdle() {
    if (S.state === 'SPEAKING') setState('IDLE');
    document.body.dataset.emotion = '';
    Mic.hold(false);
    if (S.lastVoice) Mic.extend();
  }

  // --- the wake word: "Hey <name>"
  const GREET = new Set(['hey', 'hay', 'hi', 'hello', 'he', 'ae', 'aye', 'arey', 'are', 'ok', 'okay', 'hei', 'hai', 'oye']);
  const phon = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, '').replace(/oo|ou/g, 'u').replace(/ee/g, 'i').replace(/aa/g, 'a')
    .replace(/ph/g, 'f').replace(/w/g, 'v').replace(/(.)\1+/g, '$1');
  function lev(a, b) {
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...new Array(b.length).fill(0)]);
    for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[a.length][b.length];
  }
  const fuzzy = (a, b) => { a = phon(a); b = phon(b); if (!a || !b) return false; if (a === b) return true; return b.length >= 4 && lev(a, b) <= 1; };
  const wakeWords = () => (prefs.wakeWord || ('hey ' + S.name)).toLowerCase().split(/\s+/).filter(Boolean);
  function wakeSplit(text) {
    const tokens = text.trim().split(/\s+/);
    const roman = tokens.map((t) => hinglish(t).toLowerCase().replace(/[^a-z0-9]/g, ''));
    const W = wakeWords();
    const name = W[W.length - 1];
    for (let i = 0; i < tokens.length; i++) {
      const hit = fuzzy(roman[i], name) || (S.name.toLowerCase() === 'luna' && !prefs.wakeWord && /^(लूना|लुना|லூனா|لونا|луна|ルナ|루나)/.test(tokens[i]));
      if (!hit) continue;
      if (W.length > 1 && !(W.length === 2 && GREET.has(W[0]))) { // a custom phrase: every word must match in order
        let ok = true;
        for (let k = 0; k < W.length; k++) { const j = i - (W.length - 1) + k; if (j < 0 || !fuzzy(roman[j], W[k])) { ok = false; break; } }
        if (!ok) continue;
      }
      return { hit: true, rest: tokens.slice(i + 1).join(' ').replace(/^[,.:;!?\s]+/, '') };
    }
    return { hit: false, rest: '' };
  }

  let actx = null;
  function chime() {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const t = actx.currentTime;
      [[660, 0], [880, 0.12]].forEach(([f, d]) => {
        const o = actx.createOscillator(), g = actx.createGain();
        o.frequency.value = f; g.gain.setValueAtTime(0.0001, t + d);
        g.gain.exponentialRampToValueAtTime(0.1, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.14);
        o.connect(g); g.connect(actx.destination); o.start(t + d); o.stop(t + d + 0.16);
      });
    } catch (_) { /* no audio */ }
  }

  let liveNode = null;
  function showInterim(text) {
    if (!text) { if (liveNode) { liveNode.remove(); liveNode = null; } return; }
    els.convo.querySelector('.welcome')?.remove();
    if (!liveNode) {
      liveNode = el('div', { class: 'msg you live' }, el('span', { class: 'who', text: 'YOU…' }), el('div', { class: 'body' }));
      els.convo.append(liveNode);
    }
    liveNode.querySelector('.body').textContent = display(text);
    scrollDown();
  }

  const idleHint = () => {
    if (!Mic.available) return greeting();
    if (!Mic.on) return 'Microphone muted. Tap the mic at the top to talk to me.';
    if (prefs.wake) return `Say “Hey ${S.name}” and then your question. Or type below.`;
    return 'I’m listening…';
  };

  // --- always-on microphone: listens continuously unless muted
  const Mic = (() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const native = !!(window.LunaNative && window.LunaNative.startListening);
    const available = native || !!SR;
    const WINDOW = 12000;
    let on = false, paused = false, running = false, rec = null, timer = null, awakeUntil = 0, talk = false, fails = 0, warned = false;

    function ui() {
      const mb = $('#muteBtn'), lb = $('#langBtn'), chip = $('#chipVoice');
      if (mb) { mb.classList.toggle('muted', !on); mb.setAttribute('aria-pressed', String(!on)); mb.title = on ? 'Mute microphone' : 'Unmute microphone'; mb.hidden = !available; }
      if (lb) { lb.textContent = langShort(curLang()); lb.title = 'Speaking ' + curLang() + '. Tap to switch language'; lb.hidden = !available; }
      if (chip) {
        chip.textContent = !available ? (Voice.supported ? 'SPEAK ONLY' : 'OFF') : !on ? 'MUTED' : Date.now() < awakeUntil ? 'LISTENING' : prefs.wake ? 'WAKE WORD' : 'LISTENING';
        chip.dataset.tone = available && on ? 'ok' : 'dim';
      }
      if (S.state === 'IDLE') els.stateLine.textContent = idleHint();
    }
    function schedule(ms) { clearTimeout(timer); timer = setTimeout(spawn, ms); }
    function halt() {
      clearTimeout(timer);
      if (native) { if (running) window.LunaNative.cancelListening(); running = false; }
      else if (rec) { try { rec.abort(); } catch (_) { /* ignore */ } }
      showInterim('');
    }
    function fatal(msg) { on = false; running = false; halt(); toast(msg); ui(); }

    function spawn() {
      if (!available || !on || paused || running || S.busy) { if (on && !paused && !running && S.busy) schedule(800); return; }
      running = true;
      if (native) { window.LunaNative.startListening(curLang()); return; }
      try {
        rec = new SR();
        rec.lang = curLang(); rec.continuous = true; rec.interimResults = true; rec.maxAlternatives = 1;
        rec.onresult = (e) => {
          fails = 0;
          let interim = '';
          for (let i = e.resultIndex; i < e.results.length; i++) {
            const r = e.results[i];
            if (r.isFinal) heardFinal(r[0].transcript); else interim += r[0].transcript;
          }
          if (running) showInterim(interim);
        };
        rec.onerror = (e) => {
          if (e.error === 'not-allowed' || e.error === 'service-not-allowed') return fatal('Allow the microphone for ' + S.name + ', then tap the mic at the top to start listening.');
          if (e.error === 'language-not-supported') return fatal('This browser cannot listen in that language.');
          if (e.error === 'network') { fails++; if (!warned) { warned = true; toast('Voice needs the internet. Check your connection.'); } }
          else if (e.error !== 'no-speech' && e.error !== 'aborted') fails++;
        };
        rec.onend = () => { running = false; rec = null; showInterim(''); if (on && !paused) schedule(fails > 3 ? 3000 : 250); };
        rec.start();
      } catch (_) { running = false; schedule(1500); }
    }

    function command(text) {
      awakeUntil = Date.now() + WINDOW; talk = false;
      S.lastVoice = true;
      send(text, { voice: true });
    }
    function heardFinal(raw) {
      showInterim('');
      const text = (raw || '').trim();
      if (!text) return;
      if (!prefs.wake || talk || Date.now() < awakeUntil) return command(text);
      const w = wakeSplit(text);
      if (!w.hit) return;                       // not meant for me
      if (w.rest) return command(w.rest);
      awakeUntil = Date.now() + WINDOW; chime();
      setState('LISTENING', `Yes ${S.title}? I’m listening…`); ui();
    }

    // Android app callbacks
    window.__lunaHeard = (text, isFinal) => { if (!running) return; fails = 0; if (isFinal) heardFinal(text); else showInterim(text); };
    window.__lunaVoiceEnd = () => { running = false; showInterim(''); if (on && !paused) schedule(fails > 3 ? 3000 : 250); };
    window.__lunaVoiceError = (msg, isFatal) => { if (isFatal) fatal(msg); else { fails++; window.__lunaVoiceEnd(); } };

    return {
      available,
      get on() { return on; },
      get listening() { return on && running; },
      ui,
      start() { if (!available || prefs.muted) return ui(); on = true; schedule(600); ui(); },
      toggle() {
        if (!available) return toast('This device cannot listen. Type instead.');
        on = !on; prefs.muted = !on; savePrefs();
        if (on) { schedule(0); toast(`${S.name} is listening.`); } else { halt(); running = false; toast(`${S.name} can't hear you now.`); }
        ui();
      },
      talkNow() { // the round mic button next to the text box: "listen to me right now"
        if (!available) return toast('This device cannot listen. Type instead.');
        Voice.stop();
        talk = true; awakeUntil = Date.now() + 8000; chime();
        if (!on) { on = true; prefs.muted = false; savePrefs(); schedule(0); }
        setState('LISTENING', 'I’m listening…'); ui();
      },
      hold(flag) { paused = flag; if (flag) { halt(); running = false; } else if (on) schedule(450); ui(); },
      extend() { awakeUntil = Date.now() + WINDOW; ui(); },
      restart() { if (!on) return ui(); halt(); running = false; schedule(300); ui(); },
    };
  })();

  function switchLanguage() {
    if (!Mic.available) return;
    prefs.useSecond = !prefs.useSecond; savePrefs();
    const code = curLang(), name = (LANGS.find((l) => l[0] === code) || [0, code])[1];
    toast('Listening in ' + name + '.');
    Mic.restart();
  }

  // --- the assistant's name, and what she calls you
  function applyProfile(a) {
    if (!a) return;
    S.name = a.name || 'Luna'; S.title = a.title || 'sir';
    $('#brandName').textContent = S.name.toUpperCase();
    document.title = S.name;
    els.input.placeholder = `Ask ${S.name} anything…`;
    els.input.setAttribute('aria-label', `Message ${S.name}`);
    Mic.ui();
  }

  // ------------------------------------------------------------------ settings + pairing screens

  async function settingsDialog() {
    let st, ks;
    try { st = await api('status'); ks = await api('keys_status'); } catch (e) { toast(e.message); return; }
    const labels = { missing_key: 'No key yet', configured: 'Key set (not tested)', ready: 'Connected', error: 'Error' };
    const statusDd = el('dd', { text: labels[st.gemini] || st.gemini });
    const result = el('p', { class: 'result', hidden: true });
    const sel = (opts, value) => { const s = el('select', { class: 'modal-input' }, ...opts.map(([v, t]) => el('option', { value: v, text: t }))); s.value = value; return s; };
    const check = (id, on, text, disabled) => { const c = el('input', { type: 'checkbox', id, disabled: !!disabled }); c.checked = !!on; return [c, el('label', { class: 'check', for: id }, c, document.createTextNode(' ' + text))]; };
    const lab = (t) => el('label', { class: 'field-label', text: t });

    // assistant
    const nameBox = el('input', { class: 'modal-input', type: 'text', value: S.name, maxlength: '24', 'aria-label': 'Assistant name' });
    const titleBox = el('input', { class: 'modal-input', type: 'text', value: S.title, maxlength: '20', 'aria-label': 'What the assistant calls you' });
    const wakeBox = el('input', { class: 'modal-input', type: 'text', value: prefs.wakeWord, placeholder: 'hey ' + S.name.toLowerCase(), maxlength: '40', 'aria-label': 'Wake word' });
    const [wakeCb, wakeRow] = check('cbWake', prefs.wake, 'Only listen after I say the wake word');
    const webSel = sel([['smart', 'Smart: look things up when needed'], ['always', 'Always search the internet'], ['off', 'Off']], (st.assistant && st.assistant.web) || 'smart');
    const pinBtn = window.LunaNative && window.LunaNative.pinShortcut
      ? el('button', { class: 'btn', type: 'button', text: 'ADD TO HOME SCREEN', onclick: () => window.LunaNative.pinShortcut(nameBox.value.trim() || S.name) }) : null;

    // keys
    const keyBoxes = {}, modelBoxes = {}, removeBoxes = {};
    const keyRows = ks.providers.map((p) => {
      keyBoxes[p.id] = el('input', { class: 'modal-input', type: 'password', autocomplete: 'off', spellcheck: 'false',
        placeholder: p.configured ? 'Saved. Leave empty to keep it' : 'Paste your ' + p.label + ' key', 'aria-label': p.label + ' API key' });
      modelBoxes[p.id] = el('input', { class: 'modal-input small', type: 'text', value: p.model_override || '', autocomplete: 'off', spellcheck: 'false',
        placeholder: 'Model: ' + p.default_model, 'aria-label': p.label + ' model' });
      removeBoxes[p.id] = el('input', { type: 'checkbox', id: 'rm-' + p.id });
      const kids = [lab(p.label.toUpperCase() + (p.configured ? '  ✓' : '')), keyBoxes[p.id], modelBoxes[p.id]];
      if (p.saved_in_app) kids.push(el('label', { class: 'check', for: 'rm-' + p.id }, removeBoxes[p.id], document.createTextNode(' Remove the saved ' + p.label + ' key')));
      return el('div', { class: 'field' }, ...kids);
    });
    const preferred = sel([['', 'Automatic: whichever is fastest'], ...ks.providers.map((p) => [p.id, p.label + ' first'])], ks.preferred || '');

    // language
    const langOpts = LANGS.map((l) => [l[0], l[1]]);
    const langSel = sel(langOpts, prefs.lang), lang2Sel = sel(langOpts, prefs.lang2);
    const [hingCb, hingRow] = check('cbHing', prefs.hinglish, 'Show Hindi in English letters (Hinglish)');

    // voice
    const voiceSel = el('select', { class: 'modal-input', 'aria-label': 'Voice' });
    const fillVoices = () => {
      voiceSel.replaceChildren(el('option', { value: '', text: 'Automatic (female voice)' }), ...Voice.list().map((v) => el('option', { value: v.name, text: v.name + ' · ' + v.lang })));
      voiceSel.value = prefs.voiceName || '';
    };
    fillVoices();
    const openaiReady = ks.providers.some((p) => p.id === 'openai' && p.configured);
    const [allCb, allRow] = check('cbAll', prefs.speakAll, 'Speak every reply out loud');
    const [cloudCb, cloudRow] = check('cbCloud', prefs.openaiVoice && openaiReady, openaiReady ? 'Use the OpenAI voice (female, nova)' : 'OpenAI voice (needs an OpenAI key)', !openaiReady);
    const [codeCb, codeRow] = check('cbCode', prefs.codePopup, 'Pop up code with a download button');
    const hear = el('button', { class: 'btn', type: 'button', text: 'HEAR ' + S.name.toUpperCase(), onclick: () => {
      prefs.voiceName = voiceSel.value; prefs.openaiVoice = cloudCb.checked; Voice.stop(); Voice.say(`Hi ${S.title}, I'm ${S.name}. This is how I sound.`);
    } });

    const body = el('div', { class: 'settings' },
      el('dl', {}, el('dt', { text: 'STATUS' }), statusDd),
      el('h3', { text: 'YOUR ASSISTANT' }),
      lab('NAME'), nameBox, lab('CALLS YOU'), titleBox, lab('WAKE WORD (EMPTY = “HEY ” + NAME)'), wakeBox, wakeRow,
      lab('INTERNET'), webSel, ...(pinBtn ? [pinBtn] : []),
      el('h3', { text: 'API KEYS' }), ...keyRows,
      lab('ANSWERS FROM'), preferred,
      el('p', { class: 'note', text: 'Add one or more keys. Gemini and Groq have free plans. Luna tries them in order and switches by herself if one fails. Keys stay on this device and are never shown again.' }),
      result,
      el('h3', { text: 'LANGUAGE' }), lab('I SPEAK'), langSel, lab('SECOND LANGUAGE (TAP THE LANGUAGE BUTTON AT THE TOP TO SWITCH)'), lang2Sel, hingRow,
      el('h3', { text: 'VOICE' }), voiceSel, allRow, cloudRow, codeRow, hear,
      el('h3', { text: 'PAIR WITH ANOTHER DEVICE' }),
      el('button', { class: 'btn', type: 'button', text: 'PHONE ↔ LAPTOP…', onclick: () => pairDialog() }));

    const saveBtn = el('button', { class: 'btn primary', text: 'SAVE' });
    saveBtn.addEventListener('click', async () => {
      const keys = {}, models = {}, clear = [];
      ks.providers.forEach((p) => {
        if (keyBoxes[p.id].value.trim()) keys[p.id] = keyBoxes[p.id].value.trim();
        models[p.id] = modelBoxes[p.id].value.trim();
        if (removeBoxes[p.id].checked) clear.push(p.id);
      });
      prefs.voiceName = voiceSel.value; prefs.speakAll = allCb.checked; prefs.openaiVoice = cloudCb.checked; prefs.codePopup = codeCb.checked;
      prefs.wake = wakeCb.checked; prefs.wakeWord = wakeBox.value.trim().toLowerCase(); prefs.hinglish = hingCb.checked;
      const langChanged = prefs.lang !== langSel.value || prefs.lang2 !== lang2Sel.value;
      prefs.lang = langSel.value; prefs.lang2 = lang2Sel.value;
      savePrefs();
      saveBtn.disabled = true;
      try {
        await api('save_keys', { keys, models, clear, preferred: preferred.value });
        await api('profile_set', { name: nameBox.value.trim(), title: titleBox.value.trim(), web: webSel.value });
        const fresh = await api('status');
        applyStatus(fresh);
        if (langChanged) Mic.restart(); else Mic.ui();
        toast('Saved.');
        closeModal();
        refreshActivity();
      } catch (e) {
        result.hidden = false; result.className = 'result bad'; result.textContent = e.message;
      }
      saveBtn.disabled = false;
    });
    const testBtn = el('button', { class: 'btn', text: 'TEST CONNECTION' });
    testBtn.addEventListener('click', async () => {
      testBtn.disabled = true; testBtn.textContent = 'TESTING…';
      try {
        const r = await api('test_connection');
        applyStatus(r);
        statusDd.textContent = labels[r.gemini] || r.gemini;
        result.hidden = false;
        result.className = 'result ' + (r.gemini === 'ready' ? 'ok' : 'bad');
        result.textContent = r.gemini === 'ready' ? (r.gemini_detail || 'Ready.')
          : r.gemini === 'missing_key' ? 'No key saved yet. Paste one above and tap SAVE.' : (r.gemini_detail || 'The AI did not answer.');
      } catch (e) { result.hidden = false; result.className = 'result bad'; result.textContent = e.message; }
      testBtn.disabled = false; testBtn.textContent = 'TEST CONNECTION';
      refreshActivity();
    });
    openModal('SETTINGS', body, [saveBtn, testBtn, el('button', { class: 'btn', text: 'CLOSE', onclick: closeModal })]);
    Voice.onVoices(fillVoices);
  }

  async function pairDialog() {
    const body = el('div', { class: 'pair' });
    const info = el('p', { class: 'note' });
    const codeBox = el('div', { class: 'pair-code', hidden: true });
    const codeInput = el('input', { class: 'modal-input', type: 'text', inputmode: 'numeric', maxlength: '7', placeholder: '6-digit code', 'aria-label': 'Pairing code' });
    const addrInput = el('input', { class: 'modal-input small', type: 'text', placeholder: 'Only if it is not found: other device address, like 192.168.1.5:47822', 'aria-label': 'Other device address' });
    const msg = el('p', { class: 'result', hidden: true });
    const joinBox = el('div', { hidden: true }, codeInput, addrInput);
    const btns = el('div', { class: 'pair-btns' });
    body.append(info, codeBox, joinBox, msg, btns);

    const say = (t, bad) => { msg.hidden = !t; msg.className = 'result ' + (bad ? 'bad' : 'ok'); msg.textContent = t || ''; };
    const wrap = async (fn) => { try { const r = await fn(); if (r && r.pair) draw(r.pair); return r; } catch (e) { say(e.message, true); } return null; };
    const btn = (text, fn, primary) => el('button', { class: 'btn' + (primary ? ' primary' : ''), type: 'button', text, onclick: fn });

    function draw(p) {
      btns.replaceChildren();
      codeBox.hidden = !p.code; joinBox.hidden = true;
      if (p.paired) {
        const ago = p.last_sync ? Math.max(1, Math.round(Date.now() / 1000 - p.last_sync)) + 's ago' : 'not yet';
        info.textContent = `Paired with ${p.peer || 'another device'}. Last sync: ${ago}. Chats from both devices appear on both while they are on the same Wi-Fi.` + (p.error ? ' ' + p.error : '');
        btns.append(btn('SYNC NOW', () => wrap(() => api('sync_now')), true), btn('UNPAIR', () => wrap(() => api('pair_unpair'))));
        return;
      }
      if (p.code) {
        info.textContent = 'On the other device open Settings, then PHONE ↔ LAPTOP, then ENTER A CODE, and type these numbers. Both devices must be on the same Wi-Fi.';
        codeBox.replaceChildren(el('div', { class: 'big', text: p.code.slice(0, 3) + ' ' + p.code.slice(3) }),
          el('div', { class: 'small', text: `Expires in ${Math.floor(p.code_expires_in / 60)}:${String(p.code_expires_in % 60).padStart(2, '0')}` + (p.addresses.length ? ' · address ' + p.addresses.join(', ') : '') }));
        btns.append(btn('CANCEL', () => wrap(() => api('pair_stop'))));
        return;
      }
      info.textContent = 'Pair this device with your other one (phone and laptop) on the same Wi-Fi. Nothing goes through the internet. The first step is to show a code on one device and type it on the other.';
      btns.append(btn('SHOW A CODE ON THIS DEVICE', () => wrap(() => api('pair_start')), true), btn('ENTER A CODE FROM THE OTHER DEVICE', () => {
        joinBox.hidden = false; btns.replaceChildren(btn('PAIR', async () => { say('Looking for the other device…'); await wrap(() => api('pair_join', { code: codeInput.value, address: addrInput.value.trim() })); }, true), btn('BACK', () => wrap(() => api('pair_status'))));
        codeInput.focus();
      }));
    }
    const first = await wrap(() => api('pair_status'));
    openModal('PAIR DEVICES', body, [el('button', { class: 'btn', text: 'CLOSE', onclick: closeModal })]);
    if (!first) return;
    const timer = setInterval(async () => {
      if ($('#modal').hidden || !body.isConnected) { clearInterval(timer); return; }
      if (!joinBox.hidden) return;
      try { draw((await api('pair_status')).pair); } catch (_) { /* ignore */ }
    }, 2000);
  }

  // keep this device's chats in step with a paired one
  async function syncTick() {
    if (!S.syncPaired || document.hidden) return;
    try {
      const st = await api('status');
      if (!st.sync) return;
      if (st.sync.revision !== S.syncRev) {
        S.syncRev = st.sync.revision;
        refreshMenu();
        if (S.chatId && !S.busy) { const c = await api('open_chat', { chat_id: S.chatId }); if (c && c.messages && c.messages.length !== els.convo.querySelectorAll('.msg:not(.live)').length) renderChat(c); }
      }
    } catch (_) { /* offline: try again next time */ }
  }

  function tickClock() {
    const now = new Date();
    $('#clockTime').textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }).formatToParts(now).map((x) => [x.type, x.value]));
    $('#clockDate').textContent = `${p.weekday} · ${p.day} ${p.month} ${p.year}`.toUpperCase();
  }

  // ------------------------------------------------------------------ wiring

  els.form.addEventListener('submit', (e) => { e.preventDefault(); send(els.input.value); });
  els.menuBtn.addEventListener('click', toggleDrawer);
  $('#drawerClose').addEventListener('click', closeDrawer);
  els.scrim.addEventListener('click', closeDrawer);
  $('#newChatBtn').addEventListener('click', newChat);
  $('#newProjectBtn').addEventListener('click', newProject);
  $('#settingsBtn').addEventListener('click', () => { closeDrawer(); settingsDialog(); });
  els.mic.addEventListener('click', () => Mic.talkNow());
  els.stop.addEventListener('click', () => { Voice.stop(); S.lastVoice = false; setState('IDLE'); onIdle(); });
  $('#muteBtn').addEventListener('click', () => Mic.toggle());
  $('#langBtn').addEventListener('click', switchLanguage);
  $('#attachBtn').addEventListener('click', () => $('#fileInput').click());
  $('#fileInput').addEventListener('change', (e) => { addPhotos(e.target.files); e.target.value = ''; });
  els.input.addEventListener('paste', (e) => { const f = Array.from((e.clipboardData && e.clipboardData.files) || []).filter((x) => /^image\//.test(x.type)); if (f.length) { e.preventDefault(); addPhotos(f); } });
  ['dragover', 'drop'].forEach((ev) => document.addEventListener(ev, (e) => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) { e.preventDefault(); if (ev === 'drop') addPhotos(e.dataTransfer.files); } }));

  // On a phone the conversation box lives at the bottom, right above the message bar.
  const narrow = window.matchMedia('(max-width: 760px)');
  function placeConvo() {
    const panel = $('#pConvo');
    if (narrow.matches) $('.center').insertBefore(panel, $('#attachStrip')); else $('.col-right').append(panel);
  }
  narrow.addEventListener('change', placeConvo);
  placeConvo();

  let searchTimer = null;
  els.search.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { S.query = els.search.value; refreshMenu(); }, 180);
  });

  $('#quick').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-fill]');
    if (!b) return;
    els.input.value = b.dataset.fill;
    els.input.focus();
    els.input.setSelectionRange(els.input.value.length, els.input.value.length);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!modal.root.hidden) { modal.onEsc && modal.onEsc(); return; }
      closeDrawer();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') {
      e.preventDefault(); els.input.focus(); els.input.select();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'm') {
      e.preventDefault(); toggleDrawer();
    }
  });

  document.addEventListener('visibilitychange', () => {
    document.documentElement.classList.toggle('paused', document.hidden);
    if (!document.hidden) wave.restart();
  });

  // Public hooks: the voice engine (next phase) drives these.
  window.Luna = {
    setState: (name, line) => { if (['IDLE', 'LISTENING', 'THINKING', 'SPEAKING', 'ERROR'].includes(name)) setState(name, line); },
    setLevel: (v) => wave.setLevel(v),
    get state() { return S.state; },
  };

  async function init() {
    tickClock();
    setInterval(tickClock, 10000);
    setState('IDLE');
    try {
      const st0 = await api('status');
      applyStatus(st0);
      renderChat(await api('start'));
      if (st0.gemini === 'missing_key' && !store('luna.askedKeys')) { store('luna.askedKeys', true); settingsDialog(); }
    } catch (e) {
      setState('ERROR', firstSentence(e.message));
      addMsg('err', e.message, 'ERROR');
    }
    refreshMenu();
    refreshActivity();
    pollSystem();
    setInterval(refreshActivity, 6000);
    setInterval(syncTick, 8000);
    if (!navigator.webdriver) Mic.start(); else Mic.ui();
    els.input.focus();
  }
  init();
})();
