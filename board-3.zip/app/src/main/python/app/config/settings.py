"""Luna configuration.

The Gemini API key is read ONLY from the environment, which is populated from the
`.env` file next to main.py. It is never hard-coded, printed or logged.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import dotenv_values

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ENV_FILE = PROJECT_ROOT / ".env"

API_KEY_VAR = "GEMINI_API_KEY"
MODEL_VAR = "GEMINI_MODEL"
DEFAULT_MODEL = "gemini-flash-lite-latest"  # free tier, and the quickest Gemini
DEFAULT_TIMEOUT_SECONDS = 30.0

OPENAI_KEY_VAR = "OPENAI_API_KEY"
ANTHROPIC_KEY_VAR = "ANTHROPIC_API_KEY"
OPENAI_MODEL_VAR = "OPENAI_MODEL"
ANTHROPIC_MODEL_VAR = "ANTHROPIC_MODEL"
DEFAULT_OPENAI_MODEL = "gpt-5.4-mini"
DEFAULT_ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"
KEYSTORE_FILE = PROJECT_ROOT / "data" / "keys.json"
GROQ_KEY_VAR = "GROQ_API_KEY"
XAI_KEY_VARS = ("XAI_API_KEY", "GROK_API_KEY")
DEFAULT_GROQ_MODEL = "openai/gpt-oss-120b"  # free on Groq
DEFAULT_XAI_MODEL = "grok-4.3"
# Free ones first: they are tried first when you have not picked an AI yourself.
PROVIDER_IDS = ("gemini", "groq", "xai", "openai", "anthropic")

# Values that mean "the user has not put a real key in yet".
_PLACEHOLDER_VALUES = {"", "changeme", "none", "null"}


def _clean_key(value: Optional[str]) -> Optional[str]:
    """Return a usable key, or None if the value is empty or a placeholder."""
    if value is None:
        return None
    cleaned = value.strip().strip("\"'").strip()
    lowered = cleaned.lower()
    if lowered in _PLACEHOLDER_VALUES or "your_gemini_api_key" in lowered:
        return None
    return cleaned


@dataclass(frozen=True)
class Settings:
    # repr=False so the key can never leak through print(settings) or logging.
    gemini_api_key: Optional[str] = field(default=None, repr=False)
    gemini_model: str = DEFAULT_MODEL
    request_timeout: float = DEFAULT_TIMEOUT_SECONDS
    env_file: Path = ENV_FILE
    openai_api_key: Optional[str] = field(default=None, repr=False)
    anthropic_api_key: Optional[str] = field(default=None, repr=False)
    openai_model: str = DEFAULT_OPENAI_MODEL
    anthropic_model: str = DEFAULT_ANTHROPIC_MODEL
    preferred_provider: Optional[str] = None  # None = automatic (fastest wins)
    keystore_file: Path = KEYSTORE_FILE
    groq_api_key: Optional[str] = field(default=None, repr=False)
    xai_api_key: Optional[str] = field(default=None, repr=False)
    groq_model: str = DEFAULT_GROQ_MODEL
    xai_model: str = DEFAULT_XAI_MODEL
    assistant_name: str = "Luna"
    user_title: str = "sir"
    web_mode: str = "smart"  # smart | always | off

    @property
    def has_api_key(self) -> bool:
        return any(self.key_for(p) for p in PROVIDER_IDS)

    def key_for(self, provider: str) -> Optional[str]:
        return {
            "gemini": self.gemini_api_key,
            "openai": self.openai_api_key,
            "anthropic": self.anthropic_api_key,
            "groq": self.groq_api_key,
            "xai": self.xai_api_key,
        }.get(provider)

    def model_for(self, provider: str) -> str:
        return {
            "gemini": self.gemini_model,
            "openai": self.openai_model,
            "anthropic": self.anthropic_model,
            "groq": self.groq_model,
            "xai": self.xai_model,
        }.get(provider, "")

    def configured_providers(self) -> list:
        """Provider ids that have a key, preferred one first."""
        ids = [p for p in PROVIDER_IDS if self.key_for(p)]
        if self.preferred_provider in ids:
            ids.remove(self.preferred_provider)
            ids.insert(0, self.preferred_provider)
        return ids


def _timeout() -> float:
    """Seconds to wait for an AI. The Android app raises it with LUNA_REQUEST_TIMEOUT for slow mobile networks."""
    try:
        value = float(os.environ.get("LUNA_REQUEST_TIMEOUT", ""))
        return value if 5 <= value <= 300 else DEFAULT_TIMEOUT_SECONDS
    except ValueError:
        return DEFAULT_TIMEOUT_SECONDS


def load_settings(env_file: Optional[Path] = None, keystore_file: Optional[Path] = None) -> Settings:
    """Load settings from the OS environment and the .env file.

    Real OS environment variables win over the .env file. The .env file is read with
    `utf-8-sig` because Windows Notepad often saves a BOM that would otherwise corrupt
    the first variable name. Nothing is written into os.environ.
    """
    path = Path(env_file) if env_file is not None else ENV_FILE
    file_values: dict = {}
    if path.is_file():
        try:
            file_values = dotenv_values(path, encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError):
            file_values = {}

    from . import keystore

    store_path = Path(keystore_file) if keystore_file is not None else KEYSTORE_FILE
    saved = keystore.load(store_path)
    saved_keys, saved_models = saved["keys"], saved["models"]

    def lookup(name: str, saved_value: Optional[str] = None) -> Optional[str]:
        return os.environ.get(name) or saved_value or file_values.get(name)

    def model_of(var: str, provider: str, default: str) -> str:
        return (lookup(var, saved_models.get(provider)) or "").strip() or default

    preferred = saved.get("preferred")
    return Settings(
        gemini_api_key=_clean_key(lookup(API_KEY_VAR, saved_keys.get("gemini"))),
        gemini_model=model_of(MODEL_VAR, "gemini", DEFAULT_MODEL),
        env_file=path,
        openai_api_key=_clean_key(lookup(OPENAI_KEY_VAR, saved_keys.get("openai"))),
        anthropic_api_key=_clean_key(lookup(ANTHROPIC_KEY_VAR, saved_keys.get("anthropic"))),
        openai_model=model_of(OPENAI_MODEL_VAR, "openai", DEFAULT_OPENAI_MODEL),
        anthropic_model=model_of(ANTHROPIC_MODEL_VAR, "anthropic", DEFAULT_ANTHROPIC_MODEL),
        preferred_provider=preferred if preferred in PROVIDER_IDS else None,
        keystore_file=store_path,
        groq_api_key=_clean_key(lookup(GROQ_KEY_VAR, saved_keys.get("groq"))),
        xai_api_key=_clean_key(
            os.environ.get(XAI_KEY_VARS[0]) or os.environ.get(XAI_KEY_VARS[1]) or saved_keys.get("xai")
            or file_values.get(XAI_KEY_VARS[0]) or file_values.get(XAI_KEY_VARS[1])
        ),
        groq_model=model_of("GROQ_MODEL", "groq", DEFAULT_GROQ_MODEL),
        xai_model=model_of("XAI_MODEL", "xai", DEFAULT_XAI_MODEL),
        request_timeout=_timeout(),
        assistant_name=(saved.get("profile", {}).get("name") or "Luna")[:24],
        user_title=(saved.get("profile", {}).get("title") or "sir")[:20],
        web_mode=saved.get("profile", {}).get("web") if saved.get("profile", {}).get("web") in ("smart", "always", "off") else "smart",
    )


def missing_key_message(env_file: Optional[Path] = None) -> str:
    """Clear, key-free setup instructions shown when no Gemini key is configured."""
    path = Path(env_file) if env_file is not None else ENV_FILE
    lines = [
        "Luna needs a Google Gemini API key before she can think.",
        "",
        "1. Get a key from Google AI Studio (aistudio.google.com).",
        f"2. Open this file in a text editor: {path}",
        f"3. Set the line  {API_KEY_VAR}=  to your key (no quotes, no spaces).",
        "4. Save the file and restart Luna.",
        "",
        "Never paste your key into the source code or into a chat.",
        "",
        "Tip: you can also open Settings (menu, bottom left) and paste a Gemini, Claude or OpenAI key there.",
    ]
    hidden = path.with_name(path.name + ".txt")
    if not path.exists() and hidden.exists():
        lines.append("")
        lines.append(
            f"Found '{hidden.name}' instead of '{path.name}'. Windows Notepad adds .txt "
            "automatically; rename the file so it has no .txt extension."
        )
    return "\n".join(lines)
