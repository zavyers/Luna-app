"""Keys and model choices saved from Luna's Settings screen (a small local JSON file).

The file never leaves this device. Keys are never sent back to the UI or written to logs.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict


def load(path: Path) -> Dict[str, Any]:
    data: Dict[str, Any] = {"keys": {}, "models": {}, "preferred": None, "profile": {}}
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return data
    if not isinstance(raw, dict):
        return data
    for section in ("keys", "models", "profile"):
        value = raw.get(section)
        if isinstance(value, dict):
            data[section] = {str(k): str(v) for k, v in value.items() if isinstance(v, str) and v}
    preferred = raw.get("preferred")
    data["preferred"] = preferred if isinstance(preferred, str) and preferred else None
    return data


def save(path: Path, data: Dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)
