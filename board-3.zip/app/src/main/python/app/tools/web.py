"""Internet access for Luna: searches the web and reads pages, then hands the facts to the AI.

No API key is needed. It asks DuckDuckGo (and Bing as a backup) and reads the top pages.
Pages on private networks (your own PC or router) are never fetched.
"""
from __future__ import annotations

import ipaddress
import re
import socket
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from html.parser import HTMLParser
from typing import Any, Dict, List, Optional

import requests

UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
MAX_PAGE_BYTES = 600_000
PAGE_CHARS = 2800
TIMEOUT = 7

_SMALLTALK = re.compile(
    r"^\s*(?:hi|hello|hey|thanks|thank you|ok|okay|yes|no|bye|good (?:morning|night|evening)|how are you|"
    r"who are you|what(?:'s| is) your name|tell me a joke|namaste|kaise ho|kya haal|shukriya|dhanyavaad)\b",
    re.IGNORECASE,
)
_CURRENT = re.compile(
    r"\b(?:search|google|internet|web|online|latest|news|today|tonight|tomorrow|yesterday|current|currently|now|"
    r"live|weather|temperature|forecast|price|prices|rate|score|scores|match|stock|share|bitcoin|crypto|"
    r"release date|released|this week|this month|this year|2025|2026|2027|trending|"
    r"aaj|abhi|taaza|khabar|samachar|mausam|kal|bhav|kimat|"
    r"आज|अभी|ताज़ा|ताजा|खबर|समाचार|मौसम|कल|भाव|कीमत|खोज)\b",
    re.IGNORECASE,
)
_QUESTION = re.compile(
    r"(?:\?\s*$|^\s*(?:who|what|when|where|which|how much|how many|how old|is|are|does|do|did|can|will|"
    r"kaun|kya|kab|kahan|kitna|kitne|kaise|क्या|कौन|कब|कहाँ|कहां|कितना|कितने)\b)",
    re.IGNORECASE,
)
_CODE_OR_TASK = re.compile(r"\b(?:code|program|script|function|write|translate|summari[sz]e|rewrite|poem|story)\b", re.IGNORECASE)
_URL = re.compile(r"https?://\S+")


def should_search(text: str, mode: str = "smart") -> bool:
    """mode: 'off' never, 'always' every message, 'smart' when it looks like it needs fresh facts."""
    text = (text or "").strip()
    if mode == "off" or len(text) < 3:
        return False
    if mode == "always":
        return not _SMALLTALK.match(text)
    if text.lower().startswith(("/search", "search:", "google ")) or _URL.search(text):
        return True
    if _SMALLTALK.match(text) or _CODE_OR_TASK.search(text):
        return False
    return bool(_CURRENT.search(text) or (_QUESTION.search(text) and len(text.split()) >= 4))


# --------------------------------------------------------------------- safety

def is_public_url(url: str) -> bool:
    try:
        parts = urllib.parse.urlsplit(url)
        if parts.scheme not in ("http", "https") or not parts.hostname:
            return False
        for info in socket.getaddrinfo(parts.hostname, parts.port or 443):
            if not ipaddress.ip_address(info[4][0]).is_global:
                return False
        return True
    except (OSError, ValueError):
        return False


# --------------------------------------------------------------------- parsing

class _Results(HTMLParser):
    """Pulls (title, url, snippet) out of DuckDuckGo html/lite and Bing result pages."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.items: List[Dict[str, str]] = []
        self._mode: Optional[str] = None   # "title" | "snippet"
        self._buf: List[str] = []
        self._in_bing_li = False

    def handle_starttag(self, tag: str, attrs: list) -> None:
        a = dict(attrs)
        cls = a.get("class") or ""
        if tag == "li" and "b_algo" in cls:
            self._in_bing_li = True
            self.items.append({"title": "", "url": "", "snippet": ""})
        elif tag == "a" and ("result__a" in cls or "result-link" in cls):
            self.items.append({"title": "", "url": _real_url(a.get("href", "")), "snippet": ""})
            self._mode, self._buf = "title", []
        elif tag == "a" and self._in_bing_li and self.items and not self.items[-1]["url"] and a.get("href", "").startswith("http"):
            self.items[-1]["url"] = a["href"]
            self._mode, self._buf = "title", []
        elif ("result__snippet" in cls or "result-snippet" in cls) and tag in ("a", "td", "div"):
            self._mode, self._buf = "snippet", []
        elif tag == "p" and self._in_bing_li and self.items and not self.items[-1]["snippet"]:
            self._mode, self._buf = "snippet", []

    def handle_data(self, data: str) -> None:
        if self._mode:
            self._buf.append(data)

    def handle_endtag(self, tag: str) -> None:
        if self._mode and tag in ("a", "td", "div", "p") and self.items:
            text = " ".join("".join(self._buf).split())
            if self._mode == "title" and not self.items[-1]["title"]:
                self.items[-1]["title"] = text
            elif self._mode == "snippet" and not self.items[-1]["snippet"]:
                self.items[-1]["snippet"] = text
            self._mode = None


def _real_url(href: str) -> str:
    """DuckDuckGo wraps links as //duckduckgo.com/l/?uddg=<real url>."""
    if "uddg=" in href:
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(href).query)
        if qs.get("uddg"):
            return qs["uddg"][0]
    return "https:" + href if href.startswith("//") else href


class _Text(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "nav", "footer", "header", "form", "iframe", "aside"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: List[str] = []
        self._skip = 0

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in self.SKIP:
            self._skip += 1

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP and self._skip:
            self._skip -= 1

    def handle_data(self, data: str) -> None:
        if not self._skip and data.strip():
            self.parts.append(data.strip())


def parse_results(html: str) -> List[Dict[str, str]]:
    parser = _Results()
    try:
        parser.feed(html)
    except Exception:
        pass
    return [i for i in parser.items if i["url"].startswith("http") and i["title"]]


def page_text(html: str, limit: int = PAGE_CHARS) -> str:
    parser = _Text()
    try:
        parser.feed(html)
    except Exception:
        pass
    text = " ".join(parser.parts)
    return re.sub(r"\s+", " ", text)[:limit]


# --------------------------------------------------------------------- network

def search(query: str, session: Optional[Any] = None, limit: int = 5) -> List[Dict[str, str]]:
    session = session or requests.Session()
    engines = [
        ("https://html.duckduckgo.com/html/", {"q": query}),
        ("https://lite.duckduckgo.com/lite/", {"q": query}),
        ("https://www.bing.com/search", {"q": query}),
    ]
    for url, params in engines:
        try:
            r = session.get(url, params=params, headers={"User-Agent": UA, "Accept-Language": "en,hi;q=0.8"}, timeout=TIMEOUT)
            if r.status_code == 200:
                found = parse_results(r.text)
                if found:
                    return found[:limit]
        except requests.exceptions.RequestException:
            continue
    return []


def fetch_page(url: str, session: Optional[Any] = None) -> str:
    session = session or requests.Session()
    for _ in range(4):  # follow a few redirects, checking each hop
        if not is_public_url(url):
            return ""
        try:
            r = session.get(url, headers={"User-Agent": UA}, timeout=TIMEOUT, stream=True, allow_redirects=False)
        except requests.exceptions.RequestException:
            return ""
        if r.status_code in (301, 302, 303, 307, 308) and r.headers.get("Location"):
            url = urllib.parse.urljoin(url, r.headers["Location"])
            continue
        if r.status_code != 200 or "text" not in (r.headers.get("Content-Type") or "").lower():
            return ""
        body = r.raw.read(MAX_PAGE_BYTES, decode_content=True) if hasattr(r, "raw") and r.raw else r.content[:MAX_PAGE_BYTES]
        return page_text(body.decode(r.encoding or "utf-8", errors="replace"))
    return ""


def build_context(query: str, session: Optional[Any] = None) -> str:
    """Search, read the top pages, and return a block of text the AI can answer from ('' if nothing found)."""
    query = re.sub(r"^(?:/search|search:|google)\s*", "", query.strip(), flags=re.IGNORECASE)[:300]
    urls_in_text = _URL.findall(query)
    results: List[Dict[str, str]] = []
    if urls_in_text and len(urls_in_text) and len(query.replace(urls_in_text[0], "").strip()) < 40:
        results = [{"title": "Page you linked", "url": urls_in_text[0].rstrip(").,"), "snippet": ""}]
    else:
        results = search(query, session)
    if not results:
        return ""
    with ThreadPoolExecutor(max_workers=3) as pool:
        pages = list(pool.map(lambda r: fetch_page(r["url"], session), results[:3]))
    lines = [f"WEB RESULTS fetched just now ({datetime.now().strftime('%d %b %Y')}) for: {query}"]
    for i, r in enumerate(results, 1):
        host = urllib.parse.urlsplit(r["url"]).hostname or ""
        lines.append(f"[{i}] {r['title']} ({host}) {r['url']}")
        if r["snippet"]:
            lines.append(f"    {r['snippet']}")
        if i <= len(pages) and pages[i - 1]:
            lines.append(f"    Page text: {pages[i - 1]}")
    lines.append("Answer using these results. Name the site you used in a few words. If they do not answer it, say so.")
    return "\n".join(lines)
