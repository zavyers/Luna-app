"""Helpers that keep secrets out of logs, error messages and the UI."""
from __future__ import annotations

import re
from typing import Optional

_GOOGLE_KEY_PATTERN = re.compile(r"(?:AIza|sk-)[0-9A-Za-z_\-]{20,}")
REDACTED = "[REDACTED]"


def redact(text: str, *secrets: Optional[str]) -> str:
    """Remove the given secrets (and anything shaped like a Google API key) from text."""
    for secret in secrets:
        if secret:
            text = text.replace(secret, REDACTED)
    return _GOOGLE_KEY_PATTERN.sub(REDACTED, text)
