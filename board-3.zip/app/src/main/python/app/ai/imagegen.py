"""Makes pictures on request. Tries a Gemini image model (if you have a Gemini key), then a
free keyless service, then OpenAI images (if you have credit). Whatever works first wins."""
from __future__ import annotations

import base64
import os
import secrets
import time
import urllib.parse
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import requests

from app.config import Settings

from .base import AIError

GEMINI_IMAGE_MODEL = "gemini-2.5-flash-image"
MAX_IMAGE_BYTES = 12 * 1024 * 1024
KEEP_IMAGES = 80
COOLDOWN_SECONDS = 600
_EXT = {"image/png": "png", "image/jpeg": "jpg", "image/jpg": "jpg", "image/webp": "webp"}


class ImageError(AIError):
    pass


class ImageService:
    def __init__(self, settings: Settings, session: Optional[Any] = None) -> None:
        self.settings = settings
        self._session = session if session is not None else requests.Session()
        self._cool: Dict[str, float] = {}

    # ------------------------------------------------------------------ making

    def make(self, prompt: str) -> Tuple[bytes, str]:
        steps: List[Tuple[str, Callable[[str], Tuple[bytes, str]]]] = []
        if self.settings.gemini_api_key:
            steps.append(("gemini", self._gemini))
        steps.append(("free", self._free))
        if self.settings.openai_api_key:
            steps.append(("openai", self._openai))
        problems: List[str] = []
        for name, fn in steps:
            if self._cool.get(name, 0) > time.time():
                continue
            try:
                return fn(prompt)
            except (ImageError, AIError) as error:
                problems.append(str(error))
            except requests.exceptions.RequestException:
                problems.append("a network problem")
            self._cool[name] = time.time() + COOLDOWN_SECONDS
        # Everything was skipped or failed: forget the cool-downs and say why.
        self._cool.clear()
        detail = problems[-1] if problems else "no image service answered"
        raise ImageError(f"Luna couldn't make the picture ({detail}). Try again in a moment.")

    @staticmethod
    def _check(data: bytes, mime: str) -> Tuple[bytes, str]:
        mime = (mime or "").split(";")[0].strip().lower()
        if mime not in _EXT or not data or len(data) > MAX_IMAGE_BYTES:
            raise ImageError("the service did not return a picture")
        return data, mime

    def _gemini(self, prompt: str) -> Tuple[bytes, str]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_IMAGE_MODEL}:generateContent"
        r = self._session.post(
            url, headers={"x-goog-api-key": str(self.settings.gemini_api_key), "Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"responseModalities": ["IMAGE"]}},
            timeout=90,
        )
        if r.status_code >= 400:
            raise ImageError("Gemini could not draw it")
        try:
            body = r.json()
            for cand in body.get("candidates") or []:
                for part in (cand.get("content") or {}).get("parts") or []:
                    blob = part.get("inlineData") or part.get("inline_data")
                    if blob and blob.get("data"):
                        return self._check(base64.b64decode(blob["data"]), blob.get("mimeType") or blob.get("mime_type") or "image/png")
        except (ValueError, AttributeError, TypeError):
            pass
        raise ImageError("Gemini returned no picture")

    def _free(self, prompt: str) -> Tuple[bytes, str]:
        url = ("https://image.pollinations.ai/prompt/" + urllib.parse.quote(prompt[:600])
               + "?width=1024&height=1024&nologo=true&seed=" + str(secrets.randbelow(10**6)))
        r = self._session.get(url, headers={"User-Agent": "Luna/1.0"}, timeout=90)
        if r.status_code >= 400:
            raise ImageError("the free picture service is busy")
        return self._check(r.content, r.headers.get("Content-Type", ""))

    def _openai(self, prompt: str) -> Tuple[bytes, str]:
        r = self._session.post(
            "https://api.openai.com/v1/images/generations",
            headers={"Authorization": f"Bearer {self.settings.openai_api_key}", "Content-Type": "application/json"},
            json={"model": "gpt-image-1", "prompt": prompt, "size": "1024x1024"}, timeout=120,
        )
        if r.status_code >= 400:
            raise ImageError("OpenAI could not draw it")
        try:
            return self._check(base64.b64decode(r.json()["data"][0]["b64_json"]), "image/png")
        except (ValueError, KeyError, IndexError, TypeError):
            raise ImageError("OpenAI returned no picture") from None

    # ------------------------------------------------------------------ keeping

    @staticmethod
    def save(data: bytes, mime: str, folder: Path) -> str:
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        name = f"{secrets.token_hex(12)}.{_EXT.get(mime, 'png')}"
        (folder / name).write_bytes(data)
        old = sorted(folder.glob("*.*"), key=lambda p: p.stat().st_mtime)
        for extra in old[:-KEEP_IMAGES]:
            try:
                extra.unlink()
            except OSError:
                pass
        return name
