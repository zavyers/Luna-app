"""Uses every API key you have saved: tries the preferred (or currently fastest) AI first
and quietly falls back to the next one if it fails, is slow to start, or runs out of quota.
If a model name has been retired it also tries the next known free model of the same AI."""
from __future__ import annotations

import dataclasses
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Iterator, List, Optional, Tuple

import requests

from app.config import Settings

from .anthropic import AnthropicService
from .base import (
    AIError, AIProvider, AIResponse, AIResponseError, ChatMessage, MissingAPIKeyError, ModelNotFoundError,
)
from .compat import GroqService, XAIService
from .gemini import GeminiService
from .openai import OpenAIService

LABELS = {"gemini": "Gemini", "groq": "Groq", "xai": "Grok", "openai": "OpenAI", "anthropic": "Claude"}
_CLASSES = {"gemini": GeminiService, "groq": GroqService, "xai": XAIService,
            "openai": OpenAIService, "anthropic": AnthropicService}
CAN_SEE_PHOTOS = {"gemini", "openai", "anthropic", "xai"}
MODEL_FIELD = {"gemini": "gemini_model", "groq": "groq_model", "xai": "xai_model",
               "openai": "openai_model", "anthropic": "anthropic_model"}
# Tried in this order when the chosen model name is not found. Free models come first.
FALLBACK_MODELS = {
    "gemini": ["gemini-flash-lite-latest", "gemini-flash-latest", "gemini-3.6-flash", "gemini-2.5-flash-lite"],
    "groq": ["openai/gpt-oss-120b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
    "xai": ["grok-4.3", "grok-4", "grok-3-mini"],
    "openai": ["gpt-5.4-mini", "gpt-5.4-nano", "gpt-5-mini", "gpt-4o-mini"],
    "anthropic": ["claude-haiku-4-5-20251001"],
}


class MultiProvider(AIProvider):
    name = "multi"

    def __init__(self, settings: Settings, session: Optional[Any] = None) -> None:
        self._settings = settings
        self._session = session if session is not None else requests.Session()
        self.last_used = ""
        self._speed: Dict[str, float] = {}   # seconds until the first words, smoothed
        self._working: Dict[str, str] = {}   # model that last worked for each AI

    @property
    def settings(self) -> Settings:
        return self._settings

    @settings.setter
    def settings(self, value: Settings) -> None:
        self._settings = value
        self._working = {}

    # ------------------------------------------------------------------ helpers

    def _service(self, provider_id: str, model: Optional[str] = None) -> AIProvider:
        settings = self._settings
        if model is not None:
            settings = dataclasses.replace(settings, **{MODEL_FIELD[provider_id]: model})
        return _CLASSES[provider_id](settings, self._session)

    def _candidates(self, pid: str) -> List[str]:
        first = self._working.get(pid) or self._settings.model_for(pid)
        models = [first]
        for m in FALLBACK_MODELS.get(pid, []):
            if m not in models:
                models.append(m)
        return models

    def _order(self, messages: Optional[List[ChatMessage]] = None) -> List[str]:
        ids = self._settings.configured_providers()
        if messages and any(getattr(m, "images", None) for m in messages):
            ids = [i for i in ids if i in CAN_SEE_PHOTOS]
            if not ids and self._settings.has_api_key:
                raise AIResponseError("Photos need a Gemini, OpenAI, Claude or Grok key. Add one in Settings.")
        if self._settings.preferred_provider in ids:
            return ids  # the user's choice goes first, the rest are the fallback
        return sorted(ids, key=lambda i: self._speed.get(i, 0.0))  # automatic: fastest first

    def _note_speed(self, provider_id: str, seconds: float) -> None:
        old = self._speed.get(provider_id)
        self._speed[provider_id] = seconds if old is None else 0.6 * old + 0.4 * seconds

    @staticmethod
    def _combined(errors: List[AIError]) -> AIError:
        """One error that tells the person what EVERY AI said, not just the first."""
        if len(errors) == 1:
            return errors[0]
        lines = "\n".join("- " + str(e) for e in errors)
        return type(errors[0])(f"Luna tried {len(errors)} AIs and none answered.\n{lines}")

    def _generate_one(self, pid: str, messages: List[ChatMessage], system: Optional[str]) -> AIResponse:
        last: Optional[AIError] = None
        for model in self._candidates(pid):
            try:
                response = self._service(pid, model).generate(messages, system_instruction=system)
            except ModelNotFoundError as error:
                last = last or error
                continue
            self._working[pid] = model
            return response
        raise last or AIError(f"{LABELS[pid]} has no usable model.")

    def _stream_one(self, pid: str, messages: List[ChatMessage], system: Optional[str]) -> Iterator[str]:
        last: Optional[AIError] = None
        for model in self._candidates(pid):
            began = False
            try:
                for piece in self._service(pid, model).stream(messages, system_instruction=system):
                    if not began:
                        began = True
                        self._working[pid] = model
                    yield piece
                return
            except ModelNotFoundError as error:
                if began:
                    raise
                last = last or error
        raise last or AIError(f"{LABELS[pid]} has no usable model.")

    # --------------------------------------------------------------- AIProvider

    def generate(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> AIResponse:
        errors: List[AIError] = []
        for pid in self._order(messages):
            started = time.time()
            try:
                response = self._generate_one(pid, messages, system_instruction)
            except AIError as error:
                errors.append(error)
                continue
            self._note_speed(pid, time.time() - started)
            self.last_used = pid
            return response
        raise self._combined(errors) if errors else MissingAPIKeyError("No API key is configured.")

    def stream(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> Iterator[str]:
        errors: List[AIError] = []
        for pid in self._order(messages):
            started = time.time()
            began = False
            try:
                for piece in self._stream_one(pid, messages, system_instruction):
                    if not began:
                        began = True
                        self.last_used = pid
                        self._note_speed(pid, time.time() - started)
                    yield piece
                if began:
                    return
                errors.append(AIError(f"{LABELS[pid]} sent an empty answer."))
            except AIError as error:
                if began:
                    raise  # words already reached the screen; keep them
                errors.append(error)
        raise self._combined(errors) if errors else MissingAPIKeyError("No API key is configured.")

    def check_all(self) -> Dict[str, Tuple[bool, str]]:
        """Ask each saved AI one tiny real question, all at once. Returns {id: (worked, message)}."""
        ids = self._order()
        probe = [ChatMessage("user", "Reply with just the word: ok")]

        def one(pid: str) -> Tuple[str, Tuple[bool, str]]:
            started = time.time()
            try:
                self._generate_one(pid, probe, None)
            except AIError as error:
                return pid, (False, str(error))
            except Exception:  # never let one provider break the test
                return pid, (False, f"{LABELS[pid]} failed in an unexpected way.")
            note = f" (model {self._working[pid]})" if self._working.get(pid) else ""
            return pid, (True, f"answered in {time.time() - started:.1f}s{note}")

        if not ids:
            return {}
        with ThreadPoolExecutor(max_workers=len(ids)) as pool:
            return dict(pool.map(one, ids))

    def check_connection(self) -> None:
        results = self.check_all()
        if not results:
            raise MissingAPIKeyError("No API key is configured.")
        if not any(ok for ok, _ in results.values()):
            raise self._combined([AIError(msg) for _, msg in results.values()])

    def speak(self, text: str) -> bytes:
        if not self._settings.openai_api_key:
            raise MissingAPIKeyError("The cloud voice needs an OpenAI key.")
        return OpenAIService(self._settings, self._session).speak(text)
