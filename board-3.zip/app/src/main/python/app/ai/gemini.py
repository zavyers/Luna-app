"""Google Gemini provider (the only AI provider Luna uses).

Talks to the Gemini REST API directly with `requests`. The API key is sent in the
`x-goog-api-key` header, never in the URL, so it cannot end up in URL logs. Every error
message is passed through redact() before it can reach the UI or a log.
"""
from __future__ import annotations

import json

from typing import Any, Dict, List, Optional, Iterator

import requests

from app.config.settings import Settings
from app.security.redaction import redact

from .base import (
    AIError,
    AINetworkError,
    AIProvider,
    AIRateLimitError,
    AIResponse,
    AIResponseError,
    AITimeoutError,
    ChatMessage,
    InvalidAPIKeyError,
    MissingAPIKeyError,
    ModelNotFoundError,
)

BASE_URL = "https://generativelanguage.googleapis.com/v1beta"



def _parts(message: Any) -> list:
    parts: list = [{"text": message.text}]
    for mime, data in getattr(message, "images", ()) or ():
        parts.append({"inlineData": {"mimeType": mime, "data": data}})
    return parts


class GeminiService(AIProvider):
    name = "gemini"

    def __init__(self, settings: Settings, session: Optional[Any] = None) -> None:
        self._settings = settings
        self._session = session if session is not None else requests.Session()

    # ------------------------------------------------------------------ public

    @property
    def model(self) -> str:
        return self._settings.gemini_model

    def generate(
        self, messages: List[ChatMessage], system_instruction: Optional[str] = None
    ) -> AIResponse:
        if not messages:
            raise AIResponseError("There was nothing to send to Gemini.")
        payload: Dict[str, Any] = {
            "contents": [
                {
                    "role": "model" if m.role == "assistant" else "user",
                    "parts": _parts(m),
                }
                for m in messages
            ]
        }
        if system_instruction:
            payload["systemInstruction"] = {"parts": [{"text": system_instruction}]}

        url = f"{BASE_URL}/models/{self.model}:generateContent"
        response = self._request("post", url, json=payload)
        return self._parse_generate(response)

    def stream(
        self, messages: List[ChatMessage], system_instruction: Optional[str] = None
    ) -> Iterator[str]:
        """Yield the reply in pieces as Gemini produces it, so the UI can show words at once."""
        if not messages:
            raise AIResponseError("There was nothing to send to Gemini.")
        payload: Dict[str, Any] = {
            "contents": [
                {
                    "role": "model" if m.role == "assistant" else "user",
                    "parts": _parts(m),
                }
                for m in messages
            ]
        }
        if system_instruction:
            payload["systemInstruction"] = {"parts": [{"text": system_instruction}]}

        key = self._settings.gemini_api_key
        url = f"{BASE_URL}/models/{self.model}:streamGenerateContent?alt=sse"
        response = self._request("post", url, json=payload, stream=True)
        try:
            response.encoding = "utf-8"
            for raw in response.iter_lines(decode_unicode=True):
                if not raw or not raw.startswith("data:"):
                    continue
                try:
                    data = json.loads(raw[5:].strip())
                except ValueError:
                    continue
                if not isinstance(data, dict):
                    continue
                block_reason = (data.get("promptFeedback") or {}).get("blockReason")
                if block_reason:
                    raise AIResponseError(
                        f"Gemini declined to answer that request ({redact(str(block_reason), key)})."
                    )
                for candidate in data.get("candidates") or []:
                    parts = ((candidate or {}).get("content") or {}).get("parts") or []
                    for part in parts:
                        if isinstance(part, dict) and part.get("text") and not part.get("thought"):
                            yield redact(part["text"], key)
        except requests.exceptions.Timeout:
            raise AITimeoutError("Gemini took too long to answer. Please try again.") from None
        except requests.exceptions.RequestException:
            raise AINetworkError("The connection to Gemini was interrupted.") from None
        finally:
            try:
                response.close()
            except Exception:
                pass

    def check_connection(self) -> None:
        url = f"{BASE_URL}/models/{self.model}"
        self._request("get", url)

    # ---------------------------------------------------------------- internals

    def _headers(self) -> Dict[str, str]:
        key = self._settings.gemini_api_key
        if not key:
            raise MissingAPIKeyError("No Gemini API key is configured.")
        return {"x-goog-api-key": key, "Content-Type": "application/json"}

    def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        headers = self._headers()  # raises MissingAPIKeyError before any network call
        try:
            response = getattr(self._session, method)(
                url, headers=headers, timeout=self._settings.request_timeout, **kwargs
            )
        except requests.exceptions.Timeout:
            raise AITimeoutError("Gemini took too long to answer. Please try again.") from None
        except requests.exceptions.ConnectionError:
            raise AINetworkError(
                "Luna can't reach Gemini. Check your internet connection."
            ) from None
        except requests.exceptions.RequestException:
            raise AINetworkError("The request to Gemini failed because of a network error.") from None

        self._raise_for_status(response)
        return response

    def _raise_for_status(self, response: Any) -> None:
        status = response.status_code
        if status < 400:
            return

        key = self._settings.gemini_api_key
        message = ""
        try:
            body = response.json()
            message = str(body.get("error", {}).get("message", ""))
        except (ValueError, AttributeError):
            pass
        message = redact(message, key)[:300]
        lowered = message.lower()

        if status in (401, 403) or (status == 400 and "api key" in lowered):
            raise InvalidAPIKeyError(
                "Gemini rejected the API key. Check GEMINI_API_KEY in your .env file "
                "and make sure the Gemini API is enabled for that key."
            )
        if status == 404:
            raise ModelNotFoundError(
                f"Gemini model '{self.model}' was not found. Set GEMINI_MODEL in your "
                ".env file to a model your key can use."
            )
        if status == 429:
            raise AIRateLimitError(
                "Gemini says Luna is sending requests too quickly or the quota is used up. "
                "Wait a moment and try again."
            )
        if status >= 500:
            raise AIResponseError("Gemini is having trouble right now. Please try again shortly.")
        detail = f" ({message})" if message else ""
        raise AIResponseError(f"Gemini could not process the request{detail}.")

    def _parse_generate(self, response: Any) -> AIResponse:
        key = self._settings.gemini_api_key
        try:
            data = response.json()
        except ValueError:
            raise AIResponseError("Gemini sent a response Luna could not read.") from None
        if not isinstance(data, dict):
            raise AIResponseError("Gemini sent a response Luna could not read.")

        block_reason = (data.get("promptFeedback") or {}).get("blockReason")
        if block_reason:
            raise AIResponseError(
                f"Gemini declined to answer that request ({redact(str(block_reason), key)})."
            )

        candidates = data.get("candidates") or []
        if not candidates:
            raise AIResponseError("Gemini returned no answer.")

        candidate = candidates[0] or {}
        parts = (candidate.get("content") or {}).get("parts") or []
        text = "".join(
            part.get("text", "")
            for part in parts
            if isinstance(part, dict) and not part.get("thought")
        ).strip()
        finish_reason = candidate.get("finishReason")
        if not text:
            reason = f" (reason: {finish_reason})" if finish_reason else ""
            raise AIResponseError(f"Gemini returned an empty answer{reason}.")

        return AIResponse(
            text=redact(text, key),
            provider=self.name,
            model=self.model,
            finish_reason=finish_reason,
        )


__all__ = ["GeminiService", "AIError"]
