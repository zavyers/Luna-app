"""OpenAI (ChatGPT models) provider, plus OpenAI text-to-speech for Luna's optional cloud voice."""
from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional

import requests

from app.security.redaction import redact

from ._http import HTTPService, sse_json
from .base import (
    AINetworkError,
    AIResponse,
    AIResponseError,
    AITimeoutError,
    ChatMessage,
)

BASE_URL = "https://api.openai.com/v1"
TTS_MODEL = "tts-1"
FEMALE_VOICE = "nova"


class OpenAIService(HTTPService):
    """Also the base of Groq and Grok, which speak the same OpenAI-style protocol."""

    name = "openai"
    label = "OpenAI"
    base_url = BASE_URL

    @property
    def model(self) -> str:
        return self._settings.model_for(self.name)

    def _key(self) -> Optional[str]:
        return self._settings.key_for(self.name)

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self._key()}", "Content-Type": "application/json"}

    def _payload(self, messages: List[ChatMessage], system_instruction: Optional[str], stream: bool) -> Dict[str, Any]:
        if not messages:
            raise AIResponseError("There was nothing to send to OpenAI.")
        turns = []
        for t in self._alternating(messages):
            if t["images"]:
                content: Any = [{"type": "text", "text": t["content"]}] + [
                    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}} for mime, data in t["images"]
                ]
            else:
                content = t["content"]
            turns.append({"role": t["role"], "content": content})
        if system_instruction:
            turns.insert(0, {"role": "system", "content": system_instruction})
        payload: Dict[str, Any] = {"model": self.model, "messages": turns}
        if stream:
            payload["stream"] = True
        return payload

    def generate(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> AIResponse:
        response = self._request("post", f"{self.base_url}/chat/completions", json=self._payload(messages, system_instruction, False))
        data = self._read_json(response, self.label)
        choices = data.get("choices") or []
        message = (choices[0] or {}).get("message") or {} if choices else {}
        text = str(message.get("content") or "").strip()
        if not text:
            raise AIResponseError("OpenAI returned an empty answer.")
        return AIResponse(text=redact(text, self._key()), provider=self.name, model=self.model,
                          finish_reason=(choices[0] or {}).get("finish_reason"))

    def stream(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> Iterator[str]:
        response = self._request("post", f"{self.base_url}/chat/completions",
                                 json=self._payload(messages, system_instruction, True), stream=True)
        key = self._key()
        try:
            for data in sse_json(response):
                for choice in data.get("choices") or []:
                    piece = ((choice or {}).get("delta") or {}).get("content")
                    if piece:
                        yield redact(piece, key)
        except requests.exceptions.Timeout:
            raise AITimeoutError("OpenAI took too long to answer. Please try again.") from None
        except requests.exceptions.RequestException:
            raise AINetworkError("The connection to OpenAI was interrupted.") from None
        finally:
            try:
                response.close()
            except Exception:
                pass

    def check_connection(self) -> None:
        self._request("get", f"{self.base_url}/models/{self.model}")

    def speak(self, text: str, voice: str = FEMALE_VOICE) -> bytes:
        """Return mp3 audio of `text` in a female OpenAI voice."""
        response = self._request("post", f"{BASE_URL}/audio/speech",
                                 json={"model": TTS_MODEL, "input": text[:600], "voice": voice, "response_format": "mp3"})
        return response.content
