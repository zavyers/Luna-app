"""Shared plumbing for the Claude and OpenAI providers: requests, errors, streaming lines."""
from __future__ import annotations

import json
from typing import Any, Dict, Iterator, List, Optional

import requests

from app.config import Settings
from app.security.redaction import redact

from .base import (
    AIError,
    AINetworkError,
    AIProvider,
    AIRateLimitError,
    AIResponseError,
    AITimeoutError,
    ChatMessage,
    InvalidAPIKeyError,
    MissingAPIKeyError,
    ModelNotFoundError,
)


def sse_json(response: Any) -> Iterator[Dict[str, Any]]:
    """Yield the JSON object of every `data:` line of a server-sent-events response."""
    response.encoding = "utf-8"
    for raw in response.iter_lines(decode_unicode=True):
        if not raw or not raw.startswith("data:"):
            continue
        payload = raw[5:].strip()
        if payload == "[DONE]":
            return
        try:
            data = json.loads(payload)
        except ValueError:
            continue
        if isinstance(data, dict):
            yield data


class HTTPService(AIProvider):
    label = "AI"

    def __init__(self, settings: Settings, session: Optional[Any] = None) -> None:
        self._settings = settings
        self._session = session if session is not None else requests.Session()

    def _key(self) -> Optional[str]:  # pragma: no cover - overridden
        return None

    def _headers(self) -> Dict[str, str]:  # pragma: no cover - overridden
        return {}

    def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        key = self._key()
        if not key:
            raise MissingAPIKeyError(f"No {self.label} API key is configured.")
        try:
            response = getattr(self._session, method)(
                url, headers=self._headers(), timeout=self._settings.request_timeout, **kwargs
            )
        except requests.exceptions.Timeout:
            raise AITimeoutError(f"{self.label} took too long to answer. Please try again.") from None
        except requests.exceptions.ConnectionError:
            raise AINetworkError("Luna can't reach the internet. Check your connection.") from None
        except requests.exceptions.RequestException:
            raise AINetworkError(f"The request to {self.label} failed because of a network error.") from None
        self._raise_for_status(response)
        return response

    def _raise_for_status(self, response: Any) -> None:
        status = response.status_code
        if status < 400:
            return
        message = ""
        try:
            body = response.json()
            err = body.get("error", {})
            message = str(err.get("message", "") if isinstance(err, dict) else err)
        except (ValueError, AttributeError):
            pass
        message = redact(message, self._key())[:300]
        if status in (401, 403):
            raise InvalidAPIKeyError(f"{self.label} did not accept the API key. Check it in Settings.")
        if status == 404:
            raise ModelNotFoundError(f"{self.label} model '{self.model}' was not found. Change the model in Settings.")
        if status == 429:
            raise AIRateLimitError(f"{self.label} says the quota is used up or Luna is going too fast. Try again soon.")
        if status >= 500:
            raise AIResponseError(f"{self.label} is having trouble right now. Please try again shortly.")
        detail = f" ({message})" if message else ""
        raise AIResponseError(f"{self.label} could not process the request{detail}.")

    @staticmethod
    def _read_json(response: Any, label: str) -> Dict[str, Any]:
        try:
            data = response.json()
        except ValueError:
            raise AIResponseError(f"{label} sent a response Luna could not read.") from None
        if not isinstance(data, dict):
            raise AIResponseError(f"{label} sent a response Luna could not read.")
        return data

    @staticmethod
    def _alternating(messages: List[ChatMessage]) -> List[Dict[str, Any]]:
        """user/assistant turns that start with the user and never repeat a role.
        Each item: {"role", "content": str, "images": [(mime, base64), ...]}"""
        out: List[Dict[str, Any]] = []
        for m in messages:
            role = "assistant" if m.role == "assistant" else "user"
            images = list(getattr(m, "images", ()) or ())
            if out and out[-1]["role"] == role:
                out[-1]["content"] += "\n\n" + m.text
                out[-1]["images"] += images
            elif out or role == "user":
                out.append({"role": role, "content": m.text, "images": images})
        return out
