"""Groq and Grok (xAI): free-to-start AIs that use the same protocol as OpenAI."""
from __future__ import annotations

from .openai import OpenAIService


class GroqService(OpenAIService):
    name = "groq"
    label = "Groq"
    base_url = "https://api.groq.com/openai/v1"


class XAIService(OpenAIService):
    name = "xai"
    label = "Grok"
    base_url = "https://api.x.ai/v1"
