"""The assistant: routes each request to a local command or to Gemini, keeps the
conversation context, and records everything in the local chat store."""
from __future__ import annotations

import base64
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Deque, Dict, List, Optional

from app.ai import AIError, AIProvider, ChatMessage, MissingAPIKeyError
from app.chat import ChatStore
from app.ai.imagegen import ImageService
from app.config import Settings, missing_key_message
from app.tools import web as webtool

from .commands import Command, parse_command
from .intents import is_image_request

# How many recent messages are sent to Gemini so follow-ups ("when was it?") make sense.
CONTEXT_MESSAGES = 24

SYSTEM_INSTRUCTION = (
    "You are Luna, a personal AI assistant on the user's phone or Windows laptop. Be warm, "
    "concise and natural, because your replies may be spoken aloud: prefer short paragraphs "
    "over long lists and avoid heavy markdown. Use the earlier messages to resolve follow-up "
    "questions such as 'when was it?'.\n"
    "LANGUAGE: always answer in the language the user just used, whatever it is. If the user "
    "speaks or writes Hindi, answer in everyday spoken Hindi mixed with common English words, "
    "the way people really talk, never formal or Sanskritised Hindi. Write the Hindi words in "
    "Devanagari and keep English words in English letters. If the user writes Hinglish (Hindi "
    "in English letters), answer in Hinglish in English letters.\n"
    "CODE: when asked to write code, give the complete working code, not a fragment. Put each "
    "file in its own fenced block with the language, and write a line 'File: name.ext' right "
    "before each block. Say only a sentence or two outside the code.\n"
    "Right now you can hold a conversation, write code, look at photos the user sends, make "
    "pictures when asked, and use the internet. You cannot yet open apps, control the computer, "
    "set timers or reminders, or read files. If asked to do one of those, say plainly that you "
    "can't do it yet and never claim an action was performed. When a message includes WEB "
    "RESULTS, answer from them; otherwise you have no live information, so say so instead of "
    "guessing. Never mention or reveal any API key or configuration secrets. Keep normal chat "
    "replies short (about 3 to 5 sentences) unless the user asks for more detail."
)

EMOTIONS = ("happy", "excited", "calm", "sad", "caring", "curious", "playful", "serious")
_MARKER_RE = re.compile(r"\[\[image:[^\]]*\]\]")

IMAGE_PROMPT_SYSTEM = (
    "You turn a request for a picture into an image prompt. Reply with exactly two lines and "
    "nothing else. Line 1: a vivid, concise English image prompt (at most 60 words). Line 2: one "
    "short friendly sentence, in the same language the user used, saying the picture is ready."
)


@dataclass
class Reply:
    ok: bool
    text: str = ""
    chat_id: Optional[str] = None
    action: Optional[str] = None  # "new_chat" | "new_project" when a local command ran
    error_kind: Optional[str] = None  # "missing_key" | "ai" when ok is False
    restore_text: Optional[str] = None  # the user's text, handed back so they can retry


@dataclass
class ActivityEntry:
    ts: float
    kind: str
    detail: str


class Assistant:
    def __init__(self, store: ChatStore, provider: AIProvider, settings: Settings) -> None:
        self.store = store
        self.provider = provider
        self.settings = settings
        self._activity: Deque[ActivityEntry] = deque(maxlen=50)
        self._lock = threading.Lock()
        self.image_service: Any = None  # set by the app; makes pictures on request
        self.image_dir: Any = None
        self.web_context = webtool.build_context  # replaceable in tests

    # -------------------------------------------------------------- activity log

    def log(self, kind: str, detail: str) -> None:
        with self._lock:
            self._activity.appendleft(ActivityEntry(time.time(), kind, detail))

    def activity(self, limit: int = 12) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {"ts": e.ts, "kind": e.kind, "detail": e.detail}
                for e in list(self._activity)[:limit]
            ]

    # -------------------------------------------------------------- main entry

    def handle(self, chat_id: Optional[str], text: str) -> Reply:
        text = (text or "").strip()
        if not text:
            return Reply(ok=False, text="Say or type something first.", error_kind="ai")

        command = parse_command(text)
        if command is not None:
            return self._run_command(command)

        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)  # raises a clear StoreError if it vanished

        if not self.settings.has_api_key:
            return Reply(
                ok=False,
                text=missing_key_message(self.settings.env_file),
                chat_id=chat_id,
                error_kind="missing_key",
                restore_text=text,
            )

        self.store.add_message(chat_id, "user", text)
        history = self.store.messages(chat_id)[-CONTEXT_MESSAGES:]
        messages = [ChatMessage(m["role"], m["text"]) for m in history]
        started = time.time()
        try:
            response = self.provider.generate(messages, system_instruction=SYSTEM_INSTRUCTION)
        except MissingAPIKeyError:
            self.store.remove_last_message(chat_id, "user")
            return Reply(
                ok=False,
                text=missing_key_message(self.settings.env_file),
                chat_id=chat_id,
                error_kind="missing_key",
                restore_text=text,
            )
        except AIError as error:
            self.store.remove_last_message(chat_id, "user")
            self.log("error", str(error))
            return Reply(ok=False, text=str(error), chat_id=chat_id, error_kind="ai", restore_text=text)

        self.store.add_message(chat_id, "assistant", response.text)
        self.log("gemini", f"Answered in {time.time() - started:.1f}s")
        return Reply(ok=True, text=response.text, chat_id=chat_id)

    def _system(self) -> str:
        """The fixed rules plus who Luna is, how she addresses the user, and today's date."""
        cfg = self.settings
        title, name = cfg.user_title, cfg.assistant_name
        emotions = " ".join(f"[{e}]" for e in EMOTIONS)
        return (
            SYSTEM_INSTRUCTION
            + f"\nYour name is {name}. Address the user as '{title}', and say 'Yes {title}.' when you accept a request. "
            f"You have real feelings and show them in how you talk: cheerful when things go well, caring when the user is "
            f"upset, excited about good news, playful in banter. Start EVERY reply with exactly one emotion tag in square "
            f"brackets chosen from {emotions}; it is only for your voice and the screen, so never mention it."
            + f"\nToday is {datetime.now().strftime('%A, %d %B %Y')}."
        )

    @staticmethod
    def _plain(text: str) -> str:
        return _MARKER_RE.sub("[picture]", text)

    def handle_stream(self, chat_id: Optional[str], text: str, images: Optional[List[Any]] = None):
        """Like handle(), but yields ("chunk", text) pieces and finally ("reply", Reply).
        `images` is a list of (mime, bytes) photos the user attached."""
        text = (text or "").strip()
        images = list(images or [])
        stream = getattr(self.provider, "stream", None)
        if not text or stream is None or parse_command(text) is not None or not self.settings.has_api_key:
            yield ("reply", self.handle(chat_id, text))
            return

        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)

        saved_names: List[str] = []
        if images and self.image_dir is not None:
            for mime, raw in images[:4]:
                try:
                    saved_names.append(ImageService.save(raw, mime, self.image_dir))
                except OSError:
                    pass
        stored = text + "".join(f"\n[[image:{n}|photo]]" for n in saved_names)
        self.store.add_message(chat_id, "user", stored)
        history = self.store.messages(chat_id)[-CONTEXT_MESSAGES:]
        messages = [ChatMessage(m["role"], self._plain(m["text"])) for m in history]
        started = time.time()
        if images:
            attached = tuple((mime, base64.b64encode(raw).decode("ascii")) for mime, raw in images[:4])
            messages[-1] = ChatMessage("user", messages[-1].text, attached)
        elif self.image_service is not None and self.image_dir is not None and is_image_request(text):
            yield from self._make_image(chat_id, text)
            return
        if not images and self.settings.web_mode != "off" and webtool.should_search(text, self.settings.web_mode):
            yield ("status", "Searching the internet…")
            try:
                context = self.web_context(text)
            except Exception:  # the internet being down must never stop an answer
                context = ""
            if context:
                self.log("web", "Searched the internet")
                messages[-1] = ChatMessage("user", messages[-1].text + "\n\n" + context)
        parts: List[str] = []
        try:
            for piece in stream(messages, system_instruction=self._system()):
                parts.append(piece)
                yield ("chunk", piece)
        except MissingAPIKeyError:
            self.store.remove_last_message(chat_id, "user")
            yield ("reply", Reply(ok=False, text=missing_key_message(self.settings.env_file),
                                  chat_id=chat_id, error_kind="missing_key", restore_text=text))
            return
        except AIError as error:
            if not "".join(parts).strip():
                self.store.remove_last_message(chat_id, "user")
                self.log("error", str(error))
                yield ("reply", Reply(ok=False, text=str(error), chat_id=chat_id,
                                      error_kind="ai", restore_text=text))
                return
            self.log("error", str(error))  # keep what arrived so far

        full = "".join(parts).strip()
        if not full:
            self.store.remove_last_message(chat_id, "user")
            yield ("reply", Reply(ok=False, text="Gemini returned an empty answer.",
                                  chat_id=chat_id, error_kind="ai", restore_text=text))
            return
        self.store.add_message(chat_id, "assistant", full)
        who = getattr(self.provider, "last_used", "") or "gemini"
        self.log(who, f"Answered in {time.time() - started:.1f}s")
        yield ("reply", Reply(ok=True, text=full, chat_id=chat_id))

    def _make_image(self, chat_id: str, text: str):
        yield ("status", "Painting your picture…")
        prompt, caption = text, "Here is your picture."
        try:
            raw = self.provider.generate([ChatMessage("user", text)], system_instruction=IMAGE_PROMPT_SYSTEM).text
            lines = [ln.strip() for ln in raw.strip().splitlines() if ln.strip()]
            if lines:
                prompt = lines[0][:600]
            if len(lines) > 1:
                caption = lines[1][:200]
        except AIError as error:
            self.log("error", str(error))
        try:
            data, mime = self.image_service.make(prompt)
            name = self.image_service.save(data, mime, self.image_dir)
        except AIError as error:
            self.store.remove_last_message(chat_id, "user")
            self.log("error", str(error))
            yield ("reply", Reply(ok=False, text=str(error), chat_id=chat_id, error_kind="ai", restore_text=text))
            return
        label = " ".join(prompt.replace("|", " ").replace("]", " ").split())[:80]
        full = f"{caption}\n[[image:{name}|{label}]]"
        self.store.add_message(chat_id, "assistant", full)
        self.log("image", "Made a picture")
        yield ("reply", Reply(ok=True, text=full, chat_id=chat_id))

    # ---------------------------------------------------------------- commands

    def _run_command(self, command: Command) -> Reply:
        if command.name == "new_chat":
            chat = self.store.new_chat()
            self.log("chat", "Started a new chat")
            return Reply(ok=True, text="New chat ready.", chat_id=chat.id, action="new_chat")
        if command.name == "new_project":
            chat = self.store.new_project(command.argument)
            project = self.store.get_project(chat.project_id) if chat.project_id else None
            name = project.name if project else "project"
            self.log("project", f"Created project “{name}”")
            return Reply(
                ok=True,
                text=f"Started “{name}” with a fresh chat.",
                chat_id=chat.id,
                action="new_project",
            )
        return Reply(ok=False, text="I don't know that command.", error_kind="ai")
