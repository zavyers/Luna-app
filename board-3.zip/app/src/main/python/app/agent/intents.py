"""Spots 'make me a picture of ...' requests in English, Hinglish and Hindi."""
from __future__ import annotations

import re

_NOUN_RE = re.compile(
    r"(?:image|images|photo|photos|picture|pictures|pic|pics|photograph|illustration|artwork|wallpaper|"
    r"logo|portrait|drawing|painting|sketch|poster|tasveer|tasvir|foto|chitra|"
    r"तस्वीर|तसवीर|फोटो|फ़ोटो|चित्र|इमेज|पिक्चर)",
    re.IGNORECASE,
)
_VERB_RE = re.compile(
    r"(?:generate|create|make|draw|paint|design|render|produce|show|bana\w*|banao|bnao|dikha\w*|"
    r"बना\w*|दिखा\w*|जनरेट|जेनरेट)",
    re.IGNORECASE,
)
_HOW_RE = re.compile(r"^\s*(?:how|what|why|kaise|kya|can you explain)\b", re.IGNORECASE)


def is_image_request(text: str) -> bool:
    text = (text or "").strip()
    if not text or len(text) > 500:
        return False
    low = text.lower()
    if low.startswith(("/image", "image:", "photo:", "picture:")):
        return True
    if _HOW_RE.match(low) and " of " not in low:
        return False
    return bool(_NOUN_RE.search(text) and _VERB_RE.search(text))
