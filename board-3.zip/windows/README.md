# LUNA

A futuristic desktop AI assistant for Windows, powered by **Google Gemini** (the only AI service Luna uses).

> **Status: Phases 1-2 + the new interface.** Working today: the full Luna interface, Gemini conversations with
> follow-up memory, a menu with every chat and project, the "new chat" / "new project" commands, live system
> status, local activity log, and secure `.env` key handling. Voice, tools (apps, web search, timers...), and
> persistent memory are the next phases. Luna tells you honestly that she can't do those yet.

## 1. What you need

- Windows 10 or 11
- [Python 3.10 or newer](https://www.python.org/downloads/) (tick **"Add python.exe to PATH"** when installing)
- A free Gemini API key from [Google AI Studio](https://aistudio.google.com/)
- Microsoft Edge WebView2 (already on Windows 11 and most Windows 10 PCs; Luna falls back to your browser if missing)

## 2. Install

Open **Command Prompt** inside the `Luna` folder (type `cmd` in the folder's address bar) and run:

```bat
py -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Put your Gemini key in `.env`

1. Open the file named **`.env`** in the Luna folder with Notepad.
   (If it doesn't exist, copy `.env.example` and rename the copy to `.env`. Make sure Windows doesn't call it `.env.txt`.)
2. Make it look like this, using your own key, no quotes and no spaces:

```
GEMINI_API_KEY=your-key-goes-here
```

3. Save the file.

**Never paste your key into the code or into a chat.** `.env` is listed in `.gitignore`, so it can't be committed to Git by accident.
Luna never shows, prints, or logs the key. If it's missing, Luna opens normally and shows these setup steps instead of crashing.

Optional: add `GEMINI_MODEL=...` to `.env` to choose a different Gemini model (default `gemini-3.8-flash`).

## 4. Start Luna

```bat
venv\Scripts\activate
python main.py
```

Other options: `python main.py --browser` (open in your browser instead of a window) and
`python main.py --check` (tests your `.env` and the Gemini connection, then exits).

## 5. Using Luna

| You want to... | Do this |
|---|---|
| Chat | Type in the bar at the bottom and press Enter |
| See all chats and projects | Click the menu button (top left) or press **Ctrl+M** |
| Start a new chat | Type **"new chat"**, or use the menu button |
| Start a new project | Type **"new project"** (or **"new project called Website"**) |
| Rename / delete a chat or project | Menu, then hover over it and use the pencil / bin icons |
| Search every chat | Menu, then the search box |
| Jump to the message box | **Ctrl+L** |
| Check the Gemini connection | Menu, then Settings, then Test connection |

A **project** is a named group of chats. Saying "new project" creates one and opens a fresh chat inside it.
Chats are saved on your PC only, in `data/chats.json`.

The centre of the screen shows Luna's state: **IDLE, LISTENING, THINKING, SPEAKING, ERROR**, each with its own colour and animation.
Right now you'll see IDLE, THINKING and ERROR; LISTENING and SPEAKING arrive with voice.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| "Gemini key missing" | Edit `.env` as in step 3, save, restart Luna |
| "Gemini rejected the API key" | The key is wrong or the Gemini API isn't enabled for it. Create a new key in AI Studio |
| "can't reach Gemini" | Check your internet connection, VPN or firewall |
| "model ... was not found" | Remove `GEMINI_MODEL` from `.env`, or set it to a model your key can use |
| `python` isn't recognised | Reinstall Python and tick "Add python.exe to PATH", or use `py` instead of `python` |
| Window doesn't open, browser opens instead | Install the [WebView2 runtime](https://developer.microsoft.com/microsoft-edge/webview2/); the browser mode works fine meanwhile |
| Animations feel slow | Windows Settings, Accessibility, Visual effects, turn animation effects off; Luna respects that |

## 7. Run the tests

```bat
pip install pytest playwright
python -m unittest discover -s tests -t .
```

(The browser tests are skipped automatically if Playwright/Chromium isn't installed.)

## 8. Project layout

```
main.py                 start here
app/config/             .env loading and setup message
app/ai/                 provider interface + gemini.py (the only provider)
app/agent/              assistant brain: commands + Gemini + conversation context
app/chat/               local chat/project storage
app/ui/                 local server + the web interface (web/)
app/tools/              system information (more tools in later phases)
app/security/           secret redaction
assets/                 logo: logo.svg/png, icon.svg/png, luna.ico, logo-wordmark.svg/png
tests/                  automated tests
```

## Security notes

- The key lives only in `.env`; it is sent only to Google Gemini, in a request header (never in a URL), and is stripped from every error message.
- The interface talks to Luna's engine only over `127.0.0.1`, with a random per-launch token; other websites and programs can't drive it.
- The interface loads no outside fonts, scripts or images, and sends nothing anywhere except your messages to Gemini.


## Voice, and your AI keys (new)

* **Settings → API KEYS**: paste a Gemini, Claude (Anthropic) and/or OpenAI key. Luna uses the one you
  choose first (or whichever is fastest) and switches to another if it fails. Keys are kept in
  `data/keys.json` on your device, never shown again, never committed (`data/` is git-ignored).
  You can still use a `.env` file; the variables are `GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`.
* **Voice in**: tap the mic and speak. **Voice out**: Luna answers out loud in a female voice, sentence by
  sentence while the answer is still arriving. Pick a voice, speak-every-reply and hands-free mode in Settings.
  With an OpenAI key you can also switch on the OpenAI "nova" voice.
* On Windows, `python main.py` opens Luna in an Edge/Chrome app window, which is what makes the microphone work.
