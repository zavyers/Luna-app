"""Luna: start with `python main.py`.

    python main.py            open Luna in her own window
    python main.py --browser  open Luna in your default web browser instead
    python main.py --check    check the .env file and the Gemini connection, then exit
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

from app.config import PROJECT_ROOT, load_settings, missing_key_message

DEFAULT_PORT = 47821  # a fixed port lets the browser remember the microphone permission


def _find_chromium() -> str:
    for name in ("msedge", "chrome", "google-chrome", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            return found
    if sys.platform.startswith("win"):
        for base in filter(None, (os.environ.get("PROGRAMFILES(X86)"), os.environ.get("PROGRAMFILES"), os.environ.get("LOCALAPPDATA"))):
            for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
                path = os.path.join(base, rel)
                if os.path.isfile(path):
                    return path
    return ""


def _open_app_window(url: str) -> bool:
    """Open Luna in an Edge/Chrome app window. Unlike a plain embedded window it supports
    voice input (speech recognition) and Luna's spoken voice."""
    exe = _find_chromium()
    if not exe:
        return False
    profile = Path(PROJECT_ROOT) / "data" / "window-profile"
    profile.mkdir(parents=True, exist_ok=True)
    started = time.time()
    try:
        proc = subprocess.Popen([
            exe, f"--app={url}", f"--user-data-dir={profile}", "--window-size=1360,820",
            "--no-first-run", "--no-default-browser-check",
        ])
    except OSError:
        return False
    try:
        code = proc.wait()
    except KeyboardInterrupt:
        proc.terminate()
        return True
    return not (code != 0 and time.time() - started < 3)


def _open_window(url: str) -> bool:
    """Show the UI in a native window. Returns False if that isn't possible."""
    try:
        import webview  # pywebview; uses Microsoft Edge WebView2 on Windows 10/11
    except ImportError:
        return False
    try:
        webview.create_window("Luna", url, width=1360, height=800, min_size=(1000, 640), background_color="#050b14")
        webview.start()
        return True
    except Exception as error:  # e.g. WebView2 runtime missing
        print(f"Luna couldn't open her window ({type(error).__name__}). Using your browser instead.")
        return False


def main() -> int:
    parser = argparse.ArgumentParser(prog="luna", description="Luna, your Gemini-powered assistant.")
    parser.add_argument("--check", action="store_true", help="check setup and the Gemini connection")
    parser.add_argument("--browser", action="store_true", help="open in the default browser")
    parser.add_argument("--port", type=int, default=0, help=f"local port (default: {DEFAULT_PORT}, or any free port)")
    args = parser.parse_args()

    if args.check:
        from app.diagnostics import main as run_check

        return run_check()

    from app.ui.server import LunaServer, build_app

    settings = load_settings()
    if not settings.has_api_key:
        # Not an error: the UI shows the same setup steps. This is just a heads-up.
        print(missing_key_message(settings.env_file))
        print("\nLuna will still open so you can see the interface.\n")

    luna = build_app(settings)
    try:
        server = LunaServer(luna, port=args.port or DEFAULT_PORT)
    except OSError:
        server = LunaServer(luna, port=0)
    server.start()
    print(f"Luna is running at {server.url}  (Ctrl+C to quit)")

    try:
        if not args.browser and (_open_app_window(server.url) or _open_window(server.url)):
            return 0
        webbrowser.open(server.url)
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
