package com.luna.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 7;

    private WebView web;
    private SpeechRecognizer recognizer;
    private boolean pendingListen = false;
    private boolean started = false;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final ArrayList<String> ttsBacklog = new ArrayList<>();
    private int utteranceCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050b14"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "LunaNative");
        setContentView(web);
        startSpeech();
        startLuna();
    }

    /** What the Luna screen calls when you tap the microphone. */
    public class Bridge {
        @JavascriptInterface
        public void startListening() {
            runOnUiThread(() -> beginListening());
        }

        @JavascriptInterface
        public void speak(final String text) {
            runOnUiThread(() -> speakNow(text));
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> {
                ttsBacklog.clear();
                if (tts != null) tts.stop();
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.stopListening();
            });
        }
    }

    /** Luna's own voice: the phone's text-to-speech, with a female voice chosen when one exists. */
    private void startSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            int r = tts.setLanguage(Locale.getDefault());
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US);
            }
            chooseFemaleVoice();
            tts.setPitch(1.1f);
            tts.setSpeechRate(1.05f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
                @Override public void onError(String utteranceId) { js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
            });
            ttsReady = true;
            for (String t : ttsBacklog) speakNow(t);
            ttsBacklog.clear();
        });
    }

    private void chooseFemaleVoice() {
        try {
            Voice current = tts.getVoice();
            Locale want = current != null ? current.getLocale() : Locale.getDefault();
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            Voice best = null;
            int bestScore = -99;
            for (Voice v : all) {
                if (!v.getLocale().getLanguage().equals(want.getLanguage())) continue;
                String name = v.getName().toLowerCase(Locale.ROOT);
                int score = 0;
                if (name.contains("female")) score += 4;
                else if (name.contains("male")) score -= 5;
                if (!v.isNetworkConnectionRequired()) score += 1;
                if (v.getLocale().equals(want)) score += 1;
                if (score > bestScore) { best = v; bestScore = score; }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) {
            // keep the phone's default voice
        }
    }

    private void speakNow(String text) {
        if (!ttsReady || tts == null) {
            ttsBacklog.add(text);
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "luna" + (utteranceCount++));
    }

    private void js(String call) {
        runOnUiThread(() -> web.evaluateJavascript(call, null));
    }

    private void heard(String text, boolean done) {
        js("window.__lunaHeard && window.__lunaHeard(" + JSONObject.quote(text) + "," + done + ")");
    }

    private void voiceError(String message) {
        js("window.__lunaVoiceError && window.__lunaVoiceError(" + JSONObject.quote(message) + ")");
    }

    private void beginListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceError("This phone has no speech recognition. Install or enable the Google app.");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), false);
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    heard(list != null && !list.isEmpty() ? list.get(0) : "", true);
                }

                @Override
                public void onError(int error) {
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        voiceError("I didn't hear anything. Tap the mic and try again.");
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        voiceError("Voice needs internet. Check your connection.");
                    } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        voiceError("Allow the microphone for Luna in the phone's settings.");
                    } else if (error == SpeechRecognizer.ERROR_CLIENT) {
                        // Stopped by us; nothing to report.
                    } else {
                        voiceError("Voice input stopped (code " + error + ").");
                    }
                }
            });
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != MIC_REQUEST) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (ok && pendingListen) {
            pendingListen = false;
            beginListening();
        } else {
            pendingListen = false;
            voiceError("Luna needs the microphone permission to hear you. Tap the mic again and allow it.");
        }
    }

    private void startLuna() {
        if (started) return;
        started = true;
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                PyObject mod = Python.getInstance().getModule("luna_android");
                final String url = mod.callAttr("start", getFilesDir().getAbsolutePath() + "/luna").toString();
                runOnUiThread(() -> web.loadUrl(url));
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Luna failed to start: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
