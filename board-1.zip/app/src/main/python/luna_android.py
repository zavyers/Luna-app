"""Starts Luna's local server inside the Android app and returns its address."""
import dataclasses
from pathlib import Path


def start(data_dir):
    from app.chat.store import ChatStore
    from app.config import load_settings
    from app.ui.server import LunaServer, build_app

    folder = Path(data_dir)
    folder.mkdir(parents=True, exist_ok=True)
    # Keys are entered in Luna's Settings screen and saved on this phone.
    settings = load_settings(folder / "none.env", folder / "keys.json")
    settings = dataclasses.replace(settings, request_timeout=120.0)
    server = LunaServer(build_app(settings, store=ChatStore(folder / "chats.json")))
    server.start()
    return server.url
