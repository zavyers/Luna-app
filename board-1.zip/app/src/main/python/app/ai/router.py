"""Uses every API key you have saved: tries the preferred (or currently fastest) AI first
and quietly falls back to the next one if it fails, is slow to start, or runs out of quota."""
from __future__ import annotations

import time
from typing import Any, Dict, Iterator, List, Optional

import requests

from app.config import Settings

from .anthropic import AnthropicService
from .base import AIError, AIProvider, AIResponse, ChatMessage, MissingAPIKeyError
from .gemini import GeminiService
from .openai import OpenAIService

_CLASSES = {"gemini": GeminiService, "anthropic": AnthropicService, "openai": OpenAIService}


class MultiProvider(AIProvider):
    name = "multi"

    def __init__(self, settings: Settings, session: Optional[Any] = None) -> None:
        self.settings = settings
        self._session = session if session is not None else requests.Session()
        self.last_used = ""
        self._speed: Dict[str, float] = {}  # seconds until the first words, smoothed

    # ------------------------------------------------------------------ helpers

    def _service(self, provider_id: str) -> AIProvider:
        return _CLASSES[provider_id](self.settings, self._session)

    def _order(self) -> List[str]:
        ids = self.settings.configured_providers()
        if self.settings.preferred_provider in ids:
            return ids  # the user's choice goes first, the rest are the fallback
        return sorted(ids, key=lambda i: self._speed.get(i, 0.0))  # automatic: fastest first

    def _note_speed(self, provider_id: str, seconds: float) -> None:
        old = self._speed.get(provider_id)
        self._speed[provider_id] = seconds if old is None else 0.6 * old + 0.4 * seconds

    # --------------------------------------------------------------- AIProvider

    def generate(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> AIResponse:
        first_error: Optional[AIError] = None
        for pid in self._order():
            started = time.time()
            try:
                response = self._service(pid).generate(messages, system_instruction=system_instruction)
            except AIError as error:
                first_error = first_error or error
                continue
            self._note_speed(pid, time.time() - started)
            self.last_used = pid
            return response
        raise first_error or MissingAPIKeyError("No API key is configured.")

    def stream(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> Iterator[str]:
        first_error: Optional[AIError] = None
        for pid in self._order():
            started = time.time()
            began = False
            try:
                for piece in self._service(pid).stream(messages, system_instruction=system_instruction):
                    if not began:
                        began = True
                        self.last_used = pid
                        self._note_speed(pid, time.time() - started)
                    yield piece
                if began:
                    return
                first_error = first_error or AIError("The answer was empty.")
            except AIError as error:
                if began:
                    raise  # words already reached the screen; keep them
                first_error = first_error or error
        raise first_error or MissingAPIKeyError("No API key is configured.")

    def check_connection(self) -> None:
        ids = self._order()
        if not ids:
            raise MissingAPIKeyError("No API key is configured.")
        first_error: Optional[AIError] = None
        passed = False
        for pid in ids:
            try:
                self._service(pid).check_connection()
                passed = True
            except AIError as error:
                first_error = first_error or error
        if not passed and first_error:
            raise first_error

    def speak(self, text: str) -> bytes:
        if not self.settings.openai_api_key:
            raise MissingAPIKeyError("The cloud voice needs an OpenAI key.")
        return OpenAIService(self.settings, self._session).speak(text)
