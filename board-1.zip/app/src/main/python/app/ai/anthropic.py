"""Anthropic (Claude) provider."""
from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional

import requests

from app.security.redaction import redact

from ._http import HTTPService, sse_json
from .base import (
    AINetworkError,
    AIResponse,
    AIResponseError,
    AITimeoutError,
    ChatMessage,
)

BASE_URL = "https://api.anthropic.com/v1"
API_VERSION = "2023-06-01"
MAX_TOKENS = 1024


class AnthropicService(HTTPService):
    name = "anthropic"
    label = "Claude"

    @property
    def model(self) -> str:
        return self._settings.anthropic_model

    def _key(self) -> Optional[str]:
        return self._settings.anthropic_api_key

    def _headers(self) -> Dict[str, str]:
        return {"x-api-key": str(self._key()), "anthropic-version": API_VERSION, "Content-Type": "application/json"}

    def _payload(self, messages: List[ChatMessage], system_instruction: Optional[str], stream: bool) -> Dict[str, Any]:
        turns = self._alternating(messages)
        if not turns:
            raise AIResponseError("There was nothing to send to Claude.")
        payload: Dict[str, Any] = {"model": self.model, "max_tokens": MAX_TOKENS, "messages": turns}
        if system_instruction:
            payload["system"] = system_instruction
        if stream:
            payload["stream"] = True
        return payload

    def generate(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> AIResponse:
        response = self._request("post", f"{BASE_URL}/messages", json=self._payload(messages, system_instruction, False))
        data = self._read_json(response, self.label)
        blocks = data.get("content") or []
        text = "".join(b.get("text", "") for b in blocks if isinstance(b, dict) and b.get("type") == "text").strip()
        if not text:
            raise AIResponseError("Claude returned an empty answer.")
        return AIResponse(text=redact(text, self._key()), provider=self.name, model=self.model,
                          finish_reason=data.get("stop_reason"))

    def stream(self, messages: List[ChatMessage], system_instruction: Optional[str] = None) -> Iterator[str]:
        response = self._request("post", f"{BASE_URL}/messages",
                                 json=self._payload(messages, system_instruction, True), stream=True)
        key = self._key()
        try:
            for data in sse_json(response):
                kind = data.get("type")
                if kind == "content_block_delta":
                    delta = data.get("delta") or {}
                    if delta.get("type") == "text_delta" and delta.get("text"):
                        yield redact(delta["text"], key)
                elif kind == "error":
                    raise AIResponseError("Claude stopped in the middle of answering. Please try again.")
        except requests.exceptions.Timeout:
            raise AITimeoutError("Claude took too long to answer. Please try again.") from None
        except requests.exceptions.RequestException:
            raise AINetworkError("The connection to Claude was interrupted.") from None
        finally:
            try:
                response.close()
            except Exception:
                pass

    def check_connection(self) -> None:
        self._request("get", f"{BASE_URL}/models/{self.model}")
