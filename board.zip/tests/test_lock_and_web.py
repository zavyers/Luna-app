import sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app" / "src" / "main" / "python"))

from app.agent.fast import FastIntents  # noqa: E402

MAIN = ROOT / "app" / "src" / "main"


class Phone:
    def find_app(self, name):
        return None

    def contacts_enabled(self):
        return False


def say(text):
    return FastIntents("android", Phone()).match(text)


def args(text):
    r = say(text)
    return r.actions[0]["args"] if r and r.actions else None


class ScreenshotAndWebTests(unittest.TestCase):
    def test_screenshot_even_with_typos(self):
        for t in ["take a screenshot", "screnshot please", "Hey Luna take a screen shot", "capture the screen", "ss lo", "take a screeshot"]:
            self.assertEqual(args(t), {"action": "screenshot"}, t)

    def test_questions_about_screenshots_are_not_commands(self):
        for t in ["what is a screenshot", "how do I take a screenshot on iphone"]:
            self.assertIsNone(say(t), t)

    def test_google_search(self):
        self.assertEqual(args("google best phones under 20000"), {"action": "a_search_web", "query": "best phones under 20000"})
        self.assertEqual(args("search cats on google"), {"action": "a_search_web", "query": "cats"})
        self.assertEqual(args("gogle pixel price"), {"action": "a_search_web", "query": "pixel price"})
        self.assertIsNone(say("google maps"))  # an app, not a question

    def test_websites(self):
        self.assertEqual(args("open flipkart.com"), {"action": "a_open_url", "url": "https://flipkart.com"})
        self.assertEqual(args("Hey Luna, go to wikipedia.org"), {"action": "a_open_url", "url": "https://wikipedia.org"})
        self.assertEqual(args("open the amazon website"), {"action": "a_search_web", "query": "amazon official website"})
        self.assertEqual(args("open flipkart webiaye"), {"action": "a_search_web", "query": "flipkart official website"})


class WiringTests(unittest.TestCase):
    """The Android parts can't run here, so check that the pieces are connected."""

    def test_third_voice_everywhere(self):
        js = (MAIN / "python/app/ui/web/app.js").read_text()
        self.assertIn("'female2'", js)
        for f in ["Voices.java", "MainActivity.java", "ListenService.java"]:
            self.assertNotIn("Voices.choose(tts, want, Voices.male(this))", (MAIN / "java/com/luna/app" / f).read_text(), f)
        self.assertIn('"female2"', (MAIN / "java/com/luna/app/Voices.java").read_text())

    def test_lock_is_connected(self):
        act = (MAIN / "java/com/luna/app/MainActivity.java").read_text()
        for needle in ["AppLock.check(this, typed)", "showLock(true)", "welcome()", "BiometricPrompt", "public String setLock(", "if (locked)"]:
            self.assertIn(needle, act)
        self.assertIn("USE_BIOMETRIC", (MAIN / "AndroidManifest.xml").read_text())
        js = (MAIN / "python/app/ui/web/app.js").read_text()
        for needle in ["window.__lunaWelcome", "nat.setLock(", "takeWelcome"]:
            self.assertIn(needle, js)

    def test_lock_stores_only_a_hash(self):
        lock = (MAIN / "java/com/luna/app/AppLock.java").read_text()
        self.assertIn("PBKDF2WithHmacSHA256", lock)
        self.assertIn("MessageDigest.isEqual", lock)
        self.assertNotIn('putString("secret"', lock)

    def test_home_icon_follows_the_name(self):
        act = (MAIN / "java/com/luna/app/MainActivity.java").read_text()
        for needle in ['"luna-home"', "sm.updateShortcuts(", "homeShortcut(clean, true)"]:
            self.assertIn(needle, act)

    def test_windows_copy_matches(self):
        for rel in ["agent/fast.py", "ui/web/app.js"]:
            self.assertEqual((MAIN / "python/app" / rel).read_text(), (ROOT / "windows/app" / rel).read_text(), rel)


if __name__ == "__main__":
    unittest.main()
