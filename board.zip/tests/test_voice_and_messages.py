import sys, time, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from test_fast import FakePhone, msgs  # noqa: E402
from app.agent.fast import FastIntents  # noqa: E402
from app.agent.voice import call_decision, yes_no  # noqa: E402


class WordsTest(unittest.TestCase):
    def test_yes_no(self):
        for t in ("yes", "Yes please", "yeah send it", "haan", "हाँ", "Hey Luna, yes", "go ahead", "ok"):
            self.assertEqual(yes_no(t), "yes", t)
        for t in ("no", "nope", "cancel", "nahi", "नहीं", "don't send it", "no don't do it", "yes no"):
            self.assertEqual(yes_no(t), "no", t)
        for t in ("", "what time is it", "open whatsapp and tell me about the weather today please luna", "maybe later"):
            self.assertEqual(yes_no(t), "", t)

    def test_call_decision(self):
        for t in ("accept", "answer", "pick up", "pick it up", "yes", "haan utha lo", "उठाओ", "answer the call", "take it"):
            self.assertEqual(call_decision(t), "accept", t)
        for t in ("decline", "reject", "cut", "hang up", "no", "kaat do", "काट दो", "not now", "I'm busy", "don't answer", "no don't accept"):
            self.assertEqual(call_decision(t), "decline", t)
        for t in ("", "who is it", "what is the weather like in chennai today", "lovely"):
            self.assertEqual(call_decision(t), "", t)


class MessageSendingTest(unittest.TestCase):
    def setUp(self):
        self.now = time.time()
        self.phone = FakePhone(rows=msgs(self.now))
        self.fast = FastIntents("android", self.phone, None, {}, lambda q, c: "S", now=lambda: self.now)

    def draft(self, text):
        hit = self.fast.match(text)
        self.assertIsNotNone(hit, text)
        self.assertEqual(len(hit.actions), 1, text)
        entry = hit.actions[0]
        self.assertEqual(entry["status"], "confirm", text)  # never sent without an OK
        return entry["args"]

    def test_drafts(self):
        self.assertEqual(self.draft("message Rahul saying I'm coming"), {"action": "send_message", "to": "Rahul", "text": "I'm coming"})
        self.assertEqual(self.draft("send a whatsapp message to Rahul saying hello there")["app"], "whatsapp")
        self.assertEqual(self.draft("text mom that I'll be late")["text"], "I'll be late")
        self.assertEqual(self.draft("tell Rahul I'm coming")["to"], "Rahul")
        self.assertEqual(self.draft("Hey Luna, message Mom saying hi")["to"], "Mom")
        self.assertEqual(self.draft("Rahul ko message karo ki main aa raha hoon")["text"], "main aa raha hoon")

    def test_replies_go_to_the_latest_chat(self):
        for t in ("reply yes", "reply to him yes", "reply to the last message saying yes", "reply saying yes"):
            a = self.draft(t)
            self.assertEqual((a["to"], a["text"]), ("Rahul", "yes"), t)
        self.assertEqual(self.draft("reply to Rahul saying ok see you")["text"], "ok see you")

    def test_not_a_message(self):
        for t in ("tell me about the watch", "tell me a joke", "text me when it is done", "message from rahul saying hi",
                  "reply to this email using a formal tone", "reply", "message Rahul about dinner"):
            hit = self.fast.match(t)
            self.assertTrue(hit is None or not any(a["status"] == "confirm" for a in hit.actions), t)

    def test_unknown_person(self):
        hit = self.fast.match("message zed saying hi")
        self.assertFalse(hit.ok)
        self.assertEqual(hit.actions, [])

    def test_reading_in_hinglish(self):
        for t in ("mera last message padho", "last message kya hai", "what is the last message"):
            self.assertIn("Rahul", self.fast.match(t).text, t)

    def test_no_messages_explains_why(self):
        self.phone.rows = []
        self.phone.message_status = lambda: {"enabled": True, "connected": False, "seen": 0, "kept": 0}
        hit = self.fast.match("what is the last message")
        self.assertFalse(hit.ok)
        self.assertIn("reconnect", hit.text)
        self.phone.message_status = lambda: {"enabled": True, "connected": True, "seen": 0, "kept": 0}
        self.assertIn("notifications are switched on", self.fast.match("what is the last message").text)


class FakeRunner:
    def __init__(self):
        self.calls = []

    def execute(self, action, confirmed=False, remote=False):
        self.calls.append(action)
        if action["action"] in ("shutdown", "restart", "sleep_pc", "close_app", "call_contact", "send_message") and not confirmed:
            return {"action": action["action"], "label": action["action"].capitalize() + " (other device)", "status": "confirm", "text": "Needs your OK", "args": action}
        return {"action": action["action"], "label": action["action"], "status": "sent", "text": "Sent"}


class OtherDeviceTest(unittest.TestCase):
    def test_phone_controls_laptop(self):
        runner = FakeRunner()
        fast = FastIntents("android", FakePhone(rows=[]), runner, {"chrome": 1}, lambda q, c: "S")
        cases = {"open chrome on my laptop": ("open_app", "name", "chrome"), "lock my laptop": ("lock_screen", None, None),
                 "volume up on my laptop": ("volume", "direction", "up"), "pause the music on my computer": ("media", "control", "play_pause"),
                 "search for best watches on my pc": ("search_web", "query", "best watches"), "put my laptop to sleep": ("sleep_pc", None, None)}
        for text, (act, key, value) in cases.items():
            self.assertIsNotNone(fast.match(text), text)
            sent = runner.calls[-1]
            self.assertEqual(sent["action"], act, text)
            self.assertEqual(sent["on"], "other", text)
            if key:
                self.assertEqual(sent[key], value, text)
        hit = fast.match("shut down my laptop")
        self.assertEqual(hit.actions[0]["status"], "confirm")  # shutting down always asks first
        self.assertIsNone(fast.match("tell me about my laptop"))

    def test_laptop_controls_phone(self):
        runner = FakeRunner()
        fast = FastIntents("windows", None, runner, {}, None)
        fast.match("call mom on my phone")
        self.assertEqual(runner.calls[-1], {"action": "call_contact", "contact": "mom", "on": "other"})
        fast.match("message mom saying hi on my phone")
        self.assertEqual((runner.calls[-1]["action"], runner.calls[-1]["text"]), ("send_message", "hi"))


class SpokenConfirmTest(unittest.TestCase):
    def _app(self):
        from app.ui.server import LunaApp

        class Runner:
            def execute(self, action, confirmed=False, remote=False):
                return {"status": "client", "args": {"action": action["action"], "to": action["to"], "text": action["text"]}}

        stub = type("Stub", (), {})()
        stub._pending_voice = {"action": {"action": "send_message", "to": "Rahul", "text": "I'm coming"}, "until": time.time() + 30}
        stub.runner = Runner()
        stub._say = LunaApp._say.__get__(stub)
        return stub, LunaApp

    def test_yes_sends_no_cancels_other_words_wait(self):
        stub, App = self._app()
        self.assertIsNone(App._voice_confirm(stub, "what is the weather"))
        self.assertIsNotNone(stub._pending_voice)  # still waiting for a real answer
        out = App._voice_confirm(stub, "yes")
        self.assertEqual(out["actions"][0]["action"], "send_message")
        self.assertIsNone(stub._pending_voice)
        stub, App = self._app()
        out = App._voice_confirm(stub, "no")
        self.assertEqual(out["actions"], [])
        stub, App = self._app()
        stub._pending_voice["until"] = time.time() - 1
        self.assertIsNone(App._voice_confirm(stub, "yes"))  # too late: the question has expired

    def test_ask_reads_the_plan_back(self):
        from app.ui.server import LunaApp
        ask = LunaApp._ask_for({"label": "x", "args": {"action": "send_message", "to": "Rahul", "text": "I'm coming"}})
        self.assertEqual(ask, "Send “I'm coming” to Rahul?")


if __name__ == "__main__":
    unittest.main()
