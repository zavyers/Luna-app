import sys, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app" / "src" / "main" / "python"))

from app.agent.fast import FastIntents  # noqa: E402
from app.agent import speech  # noqa: E402
from app.agent.assistant import EMOTIONS  # noqa: E402


class Phone:
    def find_app(self, name): return ""
    def contacts_enabled(self): return True
    def messages_enabled(self): return False
    def find_contact(self, name): return []
    def recent_messages(self, limit=5, who=""): return []


def fast(sites=None):
    calls = []
    def search(q):
        calls.append(q)
        return sites if sites is not None else [{"title": "Amazon.in", "url": "https://www.amazon.in/"}]
    f = FastIntents("android", Phone(), websites=search)
    f._calls = calls
    return f


class WebsiteLinks(unittest.TestCase):
    def test_asks_give_tappable_links_and_a_google_button(self):
        for said, topic in [("give me the website of amazon", "amazon"), ("show me the link for taj mahal", "taj mahal"),
                            ("google amazon website", "amazon"), ("amazon official website", "amazon")]:
            f = fast()
            r = f.match(said)
            self.assertIsNotNone(r, said)
            links = [a for a in r.actions if a["status"] == "link"]
            self.assertEqual(links[0]["args"]["url"], "https://www.amazon.in/", said)
            self.assertIn("google.com/search?q=", links[-1]["args"]["url"], said)
            self.assertIn(topic, f._calls[0], said)

    def test_still_works_when_the_web_is_unreachable(self):
        f = FastIntents("android", Phone(), websites=lambda q: (_ for _ in ()).throw(OSError("offline")))
        r = f.match("give me the website of amazon")
        self.assertEqual([a["status"] for a in r.actions], ["link"])
        self.assertIn("Google", r.actions[-1]["label"])

    def test_other_talk_is_not_hijacked(self):
        for said in ["open whatsapp", "what is the capital of france", "tell me a joke"]:
            r = fast().match(said)
            self.assertTrue(r is None or not any(a.get("status") == "link" for a in r.actions), said)


class SelfUpdate(unittest.TestCase):
    def test_update_yourself_is_a_phone_action(self):
        f = FastIntents("android", Phone(), runner=None)
        self.assertIn("self_update", (ROOT / "app/src/main/python/app/agent/fast.py").read_text())
        self.assertIn("self_update", (ROOT / "app/src/main/python/app/agent/actions.py").read_text())
        self.assertIn('case "self_update"', (ROOT / "app/src/main/java/com/luna/app/PhoneActions.java").read_text())
        self.assertTrue((ROOT / "app/src/main/java/com/luna/app/Updater.java").exists())
        self.assertIn("REQUEST_INSTALL_PACKAGES", (ROOT / "app/src/main/AndroidManifest.xml").read_text())


class Emotions(unittest.TestCase):
    def test_new_feelings_are_known_to_voice_text_and_screen(self):
        for e in ["surprised", "worried", "proud", "grateful", "sleepy", "thinking"]:
            self.assertIn(e, EMOTIONS, e)
            self.assertIn(e, speech.EMOTIONS, e)
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text()
        for e in ["surprised", "worried", "proud", "grateful", "sleepy", "thinking"]:
            self.assertIn(f"{e}: {{ p:", js, e)


if __name__ == "__main__":
    unittest.main()
