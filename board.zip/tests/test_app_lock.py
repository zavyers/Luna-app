import sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app" / "src" / "main" / "python"))

from app.security.lock import LockError, LockStore  # noqa: E402


class LockStoreTests(unittest.TestCase):
    def setUp(self):
        self.t = [1000.0]
        self.s = LockStore(Path(tempfile.mkdtemp()) / "lock.json", now=lambda: self.t[0])

    def test_pin_password_pattern_work(self):
        self.s.set("pin", "1234")
        self.assertTrue(self.s.check("1234")[0])
        self.s.set("pattern", "1-2-3-6", current="1234")
        self.assertTrue(self.s.check("1-2-3-6")[0])
        self.s.set("password", "hunter22", current="1-2-3-6")
        self.assertTrue(self.s.check("hunter22")[0])
        self.assertFalse(self.s.check("hunter2")[0])

    def test_wrong_tries_wait_then_recover(self):
        self.s.set("pin", "1234")
        for _ in range(5):
            self.s.check("0000")
        ok, wait = self.s.check("1234")
        self.assertFalse(ok)
        self.assertGreater(wait, 0)
        self.t[0] += 3600
        self.assertTrue(self.s.check("1234")[0])

    def test_bad_codes_are_refused_with_a_reason(self):
        for method, secret in [("pin", "12"), ("pin", "abcd"), ("password", "abc"), ("pattern", "1-2"), ("fingerprint", "x")]:
            with self.assertRaises(LockError, msg=method):
                self.s.set(method, secret)

    def test_changing_or_clearing_needs_the_current_code(self):
        self.s.set("pin", "1234")
        with self.assertRaises(LockError):
            self.s.set("pin", "5678", current="0000")
        with self.assertRaises(LockError):
            self.s.clear("0000")
        self.s.clear("1234")
        self.assertEqual(self.s.status()["method"], "none")

    def test_code_is_never_stored_in_clear(self):
        p = Path(tempfile.mkdtemp()) / "lock.json"
        LockStore(p).set("password", "hunter22")
        self.assertNotIn("hunter22", p.read_text())


class LockWiring(unittest.TestCase):
    def test_api_and_page_have_the_lock(self):
        server = (ROOT / "app/src/main/python/app/ui/server.py").read_text()
        for name in ["lock_status", "lock_check", "lock_set", "lock_clear"]:
            self.assertIn(f'"{name}"', server, name)
        js = (ROOT / "app/src/main/python/app/ui/web/app.js").read_text()
        for needle in ["const Lock = (() =>", "Lock.boot();", "Lock.back();", "APP LOCK"]:
            self.assertIn(needle, js, needle)
        self.assertNotIn("fingerprint", js.lower().split("app lock:")[1][:9000] if "app lock:" in js.lower() else "")
        self.assertIn('id="lock"', (ROOT / "app/src/main/python/app/ui/web/index.html").read_text())


if __name__ == "__main__":
    unittest.main()
