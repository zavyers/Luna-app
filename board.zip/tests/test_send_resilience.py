import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SendResilience(unittest.TestCase):
    def test_both_pages_stop_waiting_and_retry_once(self):
        for p in ["app/src/main/python/app/ui/web/app.js", "windows/app/ui/web/app.js"]:
            js = (ROOT / p).read_text()
            self.assertIn("async function streamSend(", js, p)
            self.assertIn("Promise.race([", js, p)
            self.assertIn("90000", js, p)
            self.assertIn("attempt < 2", js, p)


if __name__ == "__main__":
    unittest.main()
