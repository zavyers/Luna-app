import sys, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.wake import WakeGate  # noqa: E402


class S:
    assistant_name = "Luna"
    wake_word = ""
    wake_required = True


def gate():
    return WakeGate(lambda: S())


class WakeTests(unittest.TestCase):
    def test_the_ways_a_recogniser_writes_hey_luna(self):
        for said, rest in [("hey luna open youtube", "open youtube"), ("heyluna what time is it", "what time is it"),
                           ("hey lu na call mom", "call mom"), ("hey lunar open maps", "open maps"),
                           ("okay luna play music", "play music"), ("hey, Luna! call mom", "call mom")]:
            self.assertEqual(gate().process(said, now=1.0), ("command", rest), said)
        for bare in ["hey luna", "hello luna", "hey loona", "hey looner", "hey lunah"]:
            self.assertEqual(gate().process(bare, now=1.0)[0], "awake", bare)

    def test_talk_in_the_room_is_still_ignored(self):
        for said in ["the moon is bright", "helena called me", "i like lunch", "hey lunch", "how are you doing"]:
            self.assertEqual(gate().process(said, now=1.0)[0], "ignore", said)

    def test_listener_has_watchdogs_and_a_spoken_hello(self):
        src = (Path(__file__).resolve().parents[1] / "app/src/main/java/com/luna/app/ListenService.java").read_text()
        self.assertIn("restartListening", src)
        self.assertIn("busySince", src)
        self.assertIn('"Yes?"', src)


if __name__ == "__main__":
    unittest.main()
