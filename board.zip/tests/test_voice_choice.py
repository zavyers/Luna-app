import unittest
from pathlib import Path

JS = (Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python" / "app" / "ui" / "web" / "app.js").read_text()


class VoiceChoiceTest(unittest.TestCase):
    def test_only_the_authentic_voice_and_nova_remain(self):
        for gone in ["voiceSel", "genderSel", "fillVoices", "prefs.voiceName", "Male voice", "onVoices"]:
            self.assertNotIn(gone, JS, gone)
        self.assertIn("Authentic voice", JS)
        self.assertIn("Use Nova (OpenAI voice)", JS)


if __name__ == "__main__":
    unittest.main()
