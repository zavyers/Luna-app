import unittest
from pathlib import Path

JAVA = Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "java" / "com" / "luna" / "app"


class NoMainThreadWork(unittest.TestCase):
    """Sending and other phone actions must run on background threads, or Android shows "not responding"."""

    def test_voice_actions_run_off_the_main_thread(self):
        src = (JAVA / "ListenService.java").read_text()
        self.assertIn('"luna-actions"', src)
        self.assertIn("finishReply(r, done)", src)
        self.assertNotIn("PhoneActions.run(this, actions.getJSONObject(i))", src)

    def test_laptop_orders_run_off_the_main_thread(self):
        src = (JAVA / "ListenService.java").read_text()
        self.assertNotIn("main.post(() -> {\n                        try {\n                            for (int i = 0; i < list.length()", src)

    def test_multi_person_send_and_chat_steps_are_threaded(self):
        self.assertIn('"luna-send"', (JAVA / "Calls.java").read_text())
        self.assertIn('"luna-chat"', (JAVA / "ChatSend.java").read_text())


if __name__ == "__main__":
    unittest.main()
