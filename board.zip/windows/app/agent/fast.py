"""Instant answers for the requests that never need the AI: opening an app, "who messaged me",
"open my latest message" and "read my screen". Going straight to the phone/PC makes them feel
immediate, because the usual path waits for a full AI round trip first.

`match()` returns None when the text isn't one of these, and Luna carries on as usual.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

_STRIP = re.compile(r"[^\w\s'+-]", re.UNICODE)
_FILLER = r"(?:\s+(?:app|application|please|pls|for me|now|ok|okay|sir|ma'?am))*"

_OPEN = re.compile(r"^(?:(?:hey|ok|okay)\s+)?(?:luna\s+)?(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:please\s+)?(?:open|launch|start|run|go to|switch to|take me to)\s+(?:up\s+)?(?:the\s+|my\s+)?(.{1,40}?)" + _FILLER + r"$")
_OPEN_HI = re.compile(r"^(?:please\s+)?(.{1,40}?)\s+(?:kholo|khol do|khol de|kholna|open karo|open kar do|chalu karo|chalao|chala do|start karo)" + _FILLER + r"$")
_NOT_APPS = {"calendar", "my calendar", "the calendar", "calendar view", "todo", "to do", "to do list", "todo list", "tasks", "task list",
             "my tasks", "list", "new chat", "a new chat", "new project", "a new project", "chat", "message", "messages", "my messages",
             "latest message", "last message", "my latest message", "my last message", "new message", "recent message", "notifications"}

_MSG_WORDS = r"(?:messages?|msgs?|texts?|whatsapp|chats?|notifications?|dms?|conversations?)"
_OPEN_WORDS = r"(?:(?:whatsapp|instagram|insta)\s+)?(?:messages?|msgs?|texts?|chats?|dms?|conversations?|notifications?)"
_OPEN_MSG = re.compile(r"^(?:please\s+)?(?:open|show|go to|take me to)\s+(?:me\s+)?(?:the\s+|my\s+)?(?:(?:latest|last|new|recent|newest|unread)\s+)?" + _OPEN_WORDS
                       + r"(?:\s+(?:from|of|by|with|on|in|at)\s+(.{1,30}))?" + _FILLER + r"$")
_OPEN_MSG_HI = re.compile(r"^(?:mera\s+|meri\s+)?(?:(?:latest|last|new|naya|aakhri)\s+)?(?:(?:whatsapp|instagram|insta)\s+)?(?:message|msg)\s+(?:kholo|khol do|dikhao|open karo)$")
_WHO = re.compile(r"\b(?:who|whom|kisne|kaun)\b.{0,30}\b(?:messag\w*|texted|text|msg\w*|called|whatsapp\w*|sent|sent me|dm|dmed|pinged|ne message|ne msg)\b|"
                  r"\bwho(?:'s| is| has| was)?\s+(?:just\s+)?(?:messag\w+|text\w*|call\w*)\b|\bkisne\s+(?:message|msg)\b")
_READ = re.compile(r"^(?:please\s+)?(?:read|tell me|show|what(?:'s| is| are)?|any|check)\b.{0,25}\b" + _MSG_WORDS + r"\b|"
                   r"^(?:do i have|have i got|any)\s+(?:any\s+)?(?:new\s+)?" + _MSG_WORDS + r"\b|"
                   r"^(?:mere|mera|meri)\s+(?:naye\s+|new\s+|latest\s+)?(?:message|msg)\w*\s+(?:padho|sunao|batao|dikhao)")
_WHAT_DID = re.compile(r"^(?:and\s+)?what\s+(?:did|has|was|is)\s+.{1,30}?\s+(?:say|said|saying|send|sent|write|wrote|text|texted|message|messaged)\b")
_FROM = [re.compile(r"\b(?:from|of|with|by)\s+([a-z][\w .'-]{0,28}?)(?:\s+(?:on|in|please|now|today)\b.*)?$"),
         re.compile(r"\bwhat\s+(?:did|has|was)\s+([a-z][\w .'-]{0,28}?)\s+(?:say|said|send|sent|write|wrote|text|texted|message|messaged)\b")]
_SCREEN = re.compile(r"\b(?:read|summari[sz]e|describe|explain|tell me what(?:'s| is)? (?:on|in)|what(?:'s| is)? (?:on|in)|what do you see on)\s+(?:out\s+)?(?:my\s+|the\s+|this\s+)?(?:phone\s+)?(?:screen|page|display)\b|"
                     r"\bscreen\s+(?:par|pe|mein|me)\s+kya\b|\bwhat(?:'s| is)? on screen\b")
# ---- calls and chats with a person
_WA = re.compile(r"\b(?:whatsapp|whats app|watsapp|whatsap)\b")
_IG = re.compile(r"\b(?:instagram|insta)\b")
_CALL_VERB = re.compile(r"\b(?:call|calling|ring|dial|phone|lagao|laga)\b")
_CHAT_VERB = re.compile(r"\b(?:message|msg|chat|text|dm|open)\b")
_NAME_STOP = {"please", "pls", "make", "a", "an", "give", "start", "place", "whatsapp", "whats", "app", "watsapp", "whatsap", "call", "calling",
              "video", "voice", "to", "my", "on", "using", "via", "through", "over", "in", "ko", "ka", "ki", "pe", "par", "karo", "kar", "do",
              "lagao", "laga", "ring", "phone", "dial", "can", "you", "could", "would", "me", "hey", "message", "msg", "chat", "text", "dm",
              "open", "with", "the", "latest", "last", "new", "recent", "newest", "unread", "send", "normal", "normally", "regular", "mobile",
              "sim", "from", "using", "cellular", "audio", "of", "for", "and", "i", "want", "wanna", "need", "let", "s", "lets", "now", "chat's"}
_PLAIN_CALL = re.compile(r"^(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:make\s+a\s+)?(?:(?:normal|regular|phone|mobile|cellular|sim)\s+)?"
                         r"(?:call|ring|dial|phone)\s+(?:to\s+)?(?:my\s+)?(.+?)"
                         r"(?:\s+(?:normally|normal|on (?:my )?(?:phone|sim|mobile)|using (?:the |my )?(?:sim|phone)|from (?:my )?(?:sim|phone)|please))?$")
_PLAIN_CALL_HI = re.compile(r"^(.+?)\s+ko\s+(?:(?:normal|simple|phone)\s+)?call\s+(?:karo|kar do|lagao|laga do|kardo)$")
_NOT_PEOPLE = {"me", "it", "a", "an", "the", "this", "that", "back", "off", "out", "up", "when", "if", "someone", "somebody", "anyone", "us", "them"}
_LATEST = re.compile(r"\b(?:now|latest|last|just|recent|newest|aakhri|naya)\b")
_READ_HI = re.compile(r"^(?:mera\s+|meri\s+|mere\s+)?(?:last|latest|aakhri|naya|naye|new)\s+(?:message|msg)\w*(?:\s+(?:padho|sunao|batao|dikhao|kya hai|kaun sa hai))?$")

# ---- sending a message by voice ("message Rahul saying I'm coming")
_SM_VIA = r"(?:whatsapp|sms|text)"
_SM = re.compile(
    r"^(?:please\s+)?(?:(?:can|could|would)\s+you\s+)?"
    r"(?:send\s+(?:a\s+|an\s+)?(?:(?P<via>" + _SM_VIA + r")\s+)?(?:message|msg|text)\s+to|(?P<via2>whatsapp|message|msg|text|dm|sms)|tell)\s+"
    r"(?P<who>[A-Za-z][\w .'-]{0,38}?)(?:\s+on\s+(?P<app>whatsapp|sms))?\s*[,:]?\s+"
    r"(?:saying|say|says|that|to say|with the message|with)\s+(?P<body>.+)$", re.IGNORECASE)
_SM_TELL = re.compile(
    r"^(?:please\s+)?tell\s+(?P<rest>[A-Za-z][\w .'-]{0,60}?\s+(?:i|i'm|im|i am|i'll|i will|we|we're|it's|its|that|to|good|happy|thank|thanks|sorry|call|come|wait|"
    r"please|ok|okay|yes|no|hello|hi|hey|see|let|don't|dont|can|will|meet|running|stuck|busy)\b.*)$", re.IGNORECASE)
_SM_REPLY = re.compile(r"^(?:please\s+)?reply\s+(?P<tail>.+)$", re.IGNORECASE)
_SEP = re.compile(r"^(?P<a>.+?)\s+(?:saying|with|that|:)\s+(?P<b>.+)$", re.IGNORECASE)
_SEP_LEAD = re.compile(r"^(?:saying|with|that|:)\s+(?P<b>.+)$", re.IGNORECASE)
_LATEST_WORDS = {"the", "this", "that", "my", "last", "latest", "new", "it"}
_LATEST_MSG = re.compile(r"^(?:the|this|that|my)?\s*(?:last|latest|new)?\s*(?:message|msg|text|chat)\b\s*(?P<rest>.*)$", re.IGNORECASE)
_SM_HI = re.compile(
    r"^(?P<who>[A-Za-z][\w .'-]{0,38}?)\s+ko\s+(?:(?P<via>whatsapp|message|msg|text|sms)\s+)?(?:karo|kar do|kardo|bhejo|bhej do|bol do|bolo|bata do|batao)?\s*"
    r"ki\s+(?P<body>.+)$", re.IGNORECASE)
# ---- the OTHER device: "open Chrome on my laptop" (from the phone), "call Mom on my phone" (from the laptop)
_PC_NOUN = r"(?:laptop|pc|computer|windows(?:\s+pc)?|desktop)"
_PHONE_NOUN = r"(?:phone|mobile|android(?:\s+phone)?)"
_DIRECT = re.compile(r"^(?:please\s+)?(?P<verb>lock|shut\s?down|power off|restart|reboot|sleep|mute|unmute)\s+(?:down\s+)?(?:my\s+|the\s+)?(?P<noun>" + _PC_NOUN + "|" + _PHONE_NOUN + r")$", re.IGNORECASE)
_VOL = re.compile(r"^(?:please\s+)?(?:turn\s+)?(?:the\s+)?(?:volume\s+)?(?P<d>up|down|louder|quieter|lower|raise|increase|decrease|mute)(?:\s+(?:the\s+)?volume)?$", re.IGNORECASE)
_MEDIA = re.compile(r"^(?:please\s+)?(?P<c>play|pause|resume|stop|next|skip|previous|go back)(?:\s+(?:the\s+)?(?:music|song|songs|video|track|playback|it))?$", re.IGNORECASE)
_CALL_CORE = re.compile(r"^(?:please\s+)?(?:make\s+a\s+)?(?:(?P<video>video)\s+)?(?:(?P<wa>whatsapp)\s+)?(?:call|ring|dial|phone)\s+(?:to\s+)?(?:(?:a\s+)?(?:video\s+)?)?(?P<who>[A-Za-z][\w .'-]{0,38}?)(?:\s+on\s+(?P<wa2>whatsapp))?$", re.IGNORECASE)
_NOT_WHO = {"me", "my", "from", "of", "the", "a", "an", "latest", "last", "new", "recent", "this", "that", "it", "back", "us", "someone", "somebody",
            "anyone", "luna", "you"}
_PRONOUNS = {"him", "her", "them", "he", "she", "they"}


@dataclass
class FastResult:
    text: str
    actions: List[Dict[str, Any]] = field(default_factory=list)  # shown like any other action: {label,status,text,args}
    ok: bool = True
    note: str = ""


def _clean(text: str) -> str:
    return " ".join(_STRIP.sub(" ", (text or "").lower()).split())


def _ago(seconds: float) -> str:
    s = max(0, int(seconds))
    if s < 60:
        return "just now"
    if s < 3600:
        m = s // 60
        return f"{m} minute{'s' if m != 1 else ''} ago"
    if s < 86400:
        h = s // 3600
        return f"{h} hour{'s' if h != 1 else ''} ago"
    d = s // 86400
    return f"{d} day{'s' if d != 1 else ''} ago"


class FastIntents:
    NEED_ACCESS = ("I can't see your messages yet. Open Luna's Settings and tap “Allow notification access”, switch Luna on, "
                   "and then ask me again. I only read message notifications, and only when you ask.")

    def __init__(self, platform: str, phone: Any = None, runner: Any = None, windows_apps: Optional[Dict[str, Any]] = None,
                 summarise: Optional[Callable[[str, str], str]] = None, now: Optional[Callable[[], float]] = None) -> None:
        self.platform = platform
        self.phone = phone
        self.runner = runner
        self.windows_apps = windows_apps or {}
        self.summarise = summarise
        import time
        self.now = now or time.time

    # ------------------------------------------------------------------ routing

    def match(self, text: str) -> Optional[FastResult]:
        other = self._other_device(text)
        if other is not None:
            return other
        if self.platform == "android" and self.phone is not None:
            sent = self._send_message(text)
            if sent is not None:
                return sent
        t = _clean(text)
        if not t or len(t) > 120:
            return None
        if self.platform == "android" and self.phone is not None:
            for fn in (self._call_person, self._chat_person, self._open_message, self._who_messaged, self._read_screen):
                out = fn(t)
                if out is not None:
                    return out
        return self._open_app(t)

    # ------------------------------------------------------------------ opening apps

    def _app_name(self, t: str) -> Optional[str]:
        for rx in (_OPEN, _OPEN_HI):
            m = rx.match(t)
            if m:
                name = m.group(1).strip()
                if not name or name in _NOT_APPS or len(name.split()) > 4 or re.search(r"\b(and|then|http|www|\.com)\b", name):
                    return None
                return name
        return None

    def _open_app(self, t: str) -> Optional[FastResult]:
        name = self._app_name(t)
        if not name:
            return None
        if self.platform == "android" and self.phone is not None:
            label = self.phone.find_app(name)
            if not label:
                return None  # maybe not an app at all ("open the door"): let the AI decide
            return FastResult(f"[calm] Opening {label}.", [{"label": f"Open app: {label}", "status": "client", "text": "",
                                                           "args": {"action": "a_open_app", "name": label}}], note=f"Opened {label}")
        if self.platform == "windows" and self.runner is not None and name in self.windows_apps:
            res = self.runner.execute({"action": "open_app", "name": name})
            if res.get("status") == "done":
                return FastResult(f"[calm] Opening {name.title() if name.islower() else name}.", note=f"Opened {name}")
            return FastResult("[caring] " + str(res.get("text") or "I couldn't open that."), ok=False)
        return None

    # ------------------------------------------------------------------ calls and chats with a person

    @staticmethod
    def _who_words(t: str) -> str:
        words = [w for w in t.split() if w not in _NAME_STOP]
        return " ".join(words) if 1 <= len(words) <= 3 else ""

    def _resolve(self, name: str):
        """Returns (contact name, None) or (None, FastResult explaining why not). None, None means "not about a contact"."""
        if not self.phone.contacts_enabled():
            return None, self._link_problem() or FastResult("[caring] I need permission to read your contacts first. Open Luna's Settings, tap “Allow contacts and calling”, "
                                    "allow it, and ask me again.", ok=False)
        rows = self.phone.find_contact(name)
        if not rows:
            if set(name.split()) & _NOT_PEOPLE:
                return None, None
            return None, FastResult(f"[caring] I can't find {name} in your contacts.", ok=False)
        exact = [r for r in rows if str(r.get("name", "")).lower() == name.lower()]
        if len(exact) == 1:
            return str(exact[0]["name"]), None
        if len(rows) > 1:
            names = ", ".join(str(r["name"]) for r in rows[:4])
            return None, FastResult(f"[curious] I found more than one: {names}. Say the full name of the one you mean.", ok=False)
        return str(rows[0]["name"]), None

    def _contact_action(self, name: str, action: str, text: str, label: str, **extra: Any) -> FastResult:
        return FastResult(f"[calm] {text}", [{"label": label, "status": "client", "text": "",
                                              "args": {"action": action, "contact": name, **extra}}], note=label)

    def _call_person(self, t: str) -> Optional[FastResult]:
        if not _CALL_VERB.search(t) and "video call" not in t:
            return None
        wa, ig = bool(_WA.search(t)), bool(_IG.search(t))
        video = bool(re.search(r"\bvideo\b", t))
        # Instagram has no way to start a call for another app, so say so instead of pretending
        if ig and not wa:
            return FastResult("[caring] I can't start Instagram calls, because Instagram doesn't allow other apps to. "
                              "I can open your Instagram messages (say “open my latest message on Instagram”), or call them on WhatsApp "
                              "or by phone if you say which.", ok=False)
        if wa:
            name = self._who_words(t)
            if not name:
                return None
            who, problem = self._resolve(name)
            if problem is not None:
                return problem
            if who is None:
                return None
            kind = "video call" if video else "call"
            return self._contact_action(who, "whatsapp_call", f"Starting a WhatsApp {kind} with {who}.", f"WhatsApp {kind}: {who}", video="yes" if video else "no")
        if video:
            return FastResult("[curious] Which app should I use for the video call? Say “video call … on WhatsApp”.", ok=False)
        m = _PLAIN_CALL.match(t) or _PLAIN_CALL_HI.match(t)
        if not m:
            return None
        name = m.group(1).strip()
        if not name or len(name.split()) > 3 or re.search(r"\b(and|then|http|www)\b", name):
            return None
        digits = re.sub(r"[\s-]", "", name)
        if re.fullmatch(r"\+?\d{3,15}", digits):  # a spoken number: open the dialer and let the person press call
            return FastResult(f"[calm] Opening the dialer with {digits}.", [{"label": f"Call: {digits}", "status": "client", "text": "",
                                                                          "args": {"action": "call", "number": digits}}])
        who, problem = self._resolve(name)
        if problem is not None:
            return problem
        if who is None:
            return None
        return self._contact_action(who, "call_contact", f"Calling {who}.", f"Call: {who}")

    def _chat_person(self, t: str) -> Optional[FastResult]:
        if not _WA.search(t) or _CALL_VERB.search(t) or not _CHAT_VERB.search(t):
            return None
        name = self._who_words(t)
        if not name:
            return None  # "open my latest message on whatsapp" is handled as an open-message request
        who, problem = self._resolve(name)
        if problem is not None:
            return problem
        if who is None:
            return None
        return self._contact_action(who, "whatsapp_chat", f"Opening your WhatsApp chat with {who}.", f"WhatsApp chat: {who}")

    # ------------------------------------------------------------------ the other device

    def _other_noun(self) -> str:
        return _PC_NOUN if self.platform == "android" else _PHONE_NOUN if self.platform == "windows" else ""

    def _other_core(self, raw: str):
        """The command with 'on my laptop' taken off, or None when it wasn't about the other device."""
        noun = self._other_noun()
        if not noun:
            return None
        m = re.search(r"\s*,?\s*\b(?:on|in|from|at|for|to)\s+(?:my\s+|the\s+|your\s+)?" + noun + r"\b(?:\s+(?:please|now|for me))?[\s.!?]*$", raw, re.IGNORECASE)
        if m:
            return raw[:m.start()].strip()
        m = re.match(r"^(?:on|in)\s+(?:my\s+|the\s+)?" + noun + r"\s*,?\s+(.+)$", raw, re.IGNORECASE)
        if m:
            return m.group(1).strip()
        m = _DIRECT.match(raw)
        if m and re.fullmatch(noun, m.group("noun"), re.IGNORECASE):
            return m.group("verb").lower().replace(" ", "")
        if re.match(r"^(?:please\s+)?put\s+(?:my\s+|the\s+)?" + noun + r"\s+(?:to\s+sleep|in(?:to)?\s+sleep(?:\s+mode)?)[\s.!?]*$", raw, re.IGNORECASE):
            return "sleep"
        return None

    def _other_action(self, core: str) -> Optional[Dict[str, Any]]:
        c = " ".join(core.split()).strip(" .!?,")
        low = c.lower()
        if not low:
            return None
        if low in ("lock", "lock screen", "lock the screen", "lock it"):
            return {"action": "lock_screen"}
        if low in ("shutdown", "shut down", "power off", "turn off", "switch off", "shut it down"):
            return {"action": "shutdown"}
        if low in ("restart", "reboot"):
            return {"action": "restart"}
        if low in ("sleep", "go to sleep", "put it to sleep", "put to sleep"):
            return {"action": "sleep_pc"}
        if low == "unmute":
            return {"action": "volume", "direction": "mute"}
        v = _VOL.match(low)
        if v:
            d = v.group("d")
            return {"action": "volume", "direction": "mute" if d == "mute" else "down" if d in ("down", "quieter", "lower", "decrease") else "up"}
        md = _MEDIA.match(low)
        if md:
            k = md.group("c")
            return {"action": "media", "control": {"play": "play_pause", "pause": "play_pause", "resume": "play_pause", "stop": "stop",
                                                    "next": "next", "skip": "next", "previous": "previous", "go back": "previous"}[k]}
        m = re.match(r"^(?:please\s+)?(?:search|google|look up)\s+(?:for\s+)?(.{1,200})$", c, re.IGNORECASE)
        if m:
            return {"action": "search_web", "query": m.group(1).strip()}
        m = re.match(r"^(?:please\s+)?close\s+(?:the\s+)?(.{1,40})$", c, re.IGNORECASE)
        if m and self.platform == "android":
            return {"action": "close_app", "name": m.group(1).strip()}
        m = re.match(r"^(?:please\s+)?open\s+(?:my\s+|the\s+)?(downloads|documents|desktop|pictures|music|videos)(?:\s+folder)?$", c, re.IGNORECASE)
        if m and self.platform == "android":
            return {"action": "open_folder", "name": m.group(1).lower()}
        m = re.match(r"^(?:please\s+)?(?:open|launch|start|run)\s+(?:up\s+)?(?:the\s+|my\s+)?(.{1,40}?)(?:\s+app)?$", c, re.IGNORECASE)
        if m:
            return {"action": "open_app", "name": m.group(1).strip()}
        if self.platform == "windows":  # from the laptop: things only the phone can do
            m = _CALL_CORE.match(c)
            if m and m.group("who").lower() not in _NOT_WHO:
                wa = bool(m.group("wa") or m.group("wa2"))
                who = m.group("who").strip()
                if wa or m.group("video"):
                    return {"action": "whatsapp_call", "contact": who, "video": "yes" if m.group("video") else "no"}
                return {"action": "call_contact", "contact": who}
            m = _SM.match(c)
            if m and m.group("who").lower().split()[0] not in _NOT_WHO:
                act = {"action": "send_message", "to": " ".join(m.group("who").split()), "text": m.group("body").strip()[:500]}
                via = (m.group("via") or m.group("via2") or m.group("app") or "").lower()
                if via in ("whatsapp", "sms"):
                    act["app"] = via
                return act
        return None

    def _other_device(self, original: str) -> Optional[FastResult]:
        """'Open Chrome on my laptop' / 'call Mom on my phone': straight to the paired device, no AI in between."""
        if self.runner is None or self.platform not in ("android", "windows"):
            return None
        raw = " ".join((original or "").split())
        raw = re.sub(r"^(?:(?:hey|ok|okay)\s+)?luna[\s,.:;!?-]*", "", raw, flags=re.IGNORECASE)
        if not raw or len(raw) > 600:
            return None
        core = self._other_core(raw)
        if core is None:
            return None
        action = self._other_action(core)
        if action is None:
            return None
        action = {**action, "on": "other"}
        res = self.runner.execute(action)
        device = "laptop" if self.platform == "android" else "phone"
        status = res.get("status")
        if status == "confirm":
            what = str(res.get("label", "do that")).replace(" (other device)", "").lower()
            return FastResult(f"[calm] I'll {what} on your {device}.", [res], note="Needs your OK")
        if status == "failed":
            return FastResult("[caring] " + str(res.get("text") or f"I couldn't reach your {device}."), ok=False, note="Other device failed")
        what = str(res.get("text") or "Done")
        return FastResult(f"[calm] On your {device}: {what}.".replace("..", "."), [res], note=f"Sent to the {device}")

    # ------------------------------------------------------------------ sending a message

    def _known_person(self, name: str) -> bool:
        try:
            if self.phone.messages_enabled() and self.phone.recent_messages(3, name):
                return True
            return bool(self.phone.contacts_enabled() and self.phone.find_contact(name))
        except Exception:
            return False

    def _split_who_body(self, rest: str):
        """'rahul sharma ok see you' -> ('rahul sharma', 'ok see you'): the longest start (1 to 3 words) that is a known person."""
        words = rest.split()
        for k in (3, 2, 1):
            if len(words) > k and self._known_person(" ".join(words[:k])):
                return " ".join(words[:k]), " ".join(words[k:])
        return "", ""

    def _parse_reply(self, tail: str):
        """What follows the word 'reply': ('who', 'what to say'), where who '' means the latest message. None if it isn't a reply."""
        t = tail.strip()
        lead = _SEP_LEAD.match(t)
        if lead:                                   # "reply saying I'm coming"
            return "", lead.group("b")
        if not re.match(r"^to\s+", t, re.IGNORECASE):
            return "", t                           # "reply yes"
        rest = re.sub(r"^to\s+", "", t, flags=re.IGNORECASE).strip()
        words = rest.split()
        if not words:
            return None
        first = words[0].lower()
        if first in _PRONOUNS:                     # "reply to him yes"
            sep = _SEP.match(rest)
            return ("", sep.group("b")) if sep else ("", " ".join(words[1:]))
        if first in _LATEST_WORDS:                 # "reply to the last message saying ok"
            lm = _LATEST_MSG.match(rest)
            if not lm:
                return None                        # "reply to this email ..." is not a chat reply
            tail2 = lm.group("rest").strip()
            lead2 = _SEP_LEAD.match(tail2)
            return ("", lead2.group("b") if lead2 else tail2)
        sep = _SEP.match(rest)
        if sep:                                    # "reply to rahul saying I'm coming"
            return sep.group("a"), sep.group("b")
        who, body = self._split_who_body(rest)     # "reply to rahul sharma ok see you"
        return (who, body) if who else None

    def _send_message(self, original: str) -> Optional[FastResult]:
        raw = " ".join((original or "").split())
        if not raw or len(raw) > 600:
            return None
        raw = re.sub(r"^(?:(?:hey|ok|okay)\s+)?luna[\s,.:;!?-]*", "", raw, flags=re.IGNORECASE)
        who = body = via = ""
        m = _SM.match(raw)
        if m:
            who, body = m.group("who"), m.group("body")
            via = (m.group("via") or m.group("via2") or m.group("app") or "").lower()
            if via in ("message", "msg", "text", "dm"):
                via = ""
        else:
            m = _SM_HI.match(raw)
            if m:
                who, body = m.group("who"), m.group("body")
                via = (m.group("via") or "").lower()
                via = via if via in ("whatsapp", "sms") else ""
            else:
                m = _SM_TELL.match(raw)
                if m:
                    who, body = self._split_who_body(m.group("rest"))
                    if not who:
                        return None
                else:
                    m = _SM_REPLY.match(raw)
                    if not m:
                        return None
                    parsed = self._parse_reply(m.group("tail"))
                    if parsed is None:
                        return None
                    who, body = parsed
        who = " ".join(who.split()).strip(" ,.")
        body = body.strip().strip("\"“”").strip()
        if not body or (who and (who.lower() in _NOT_WHO or who.lower().split()[0] in _NOT_WHO)):
            return None
        body = body[:500]
        target, problem = self._message_target(who)
        if problem is not None:
            return problem
        if target is None:
            return None
        args: Dict[str, Any] = {"action": "send_message", "to": target, "text": body}
        if via in ("whatsapp", "sms"):
            args["app"] = via
        where = " on WhatsApp" if via == "whatsapp" else " by SMS" if via == "sms" else ""
        return FastResult(f"[calm] I'll send “{body}” to {target}{where}.",
                          [{"label": f"Message {target}: “{body[:80]}”", "status": "confirm", "text": "Needs your OK", "args": args}],
                          note="Drafted a message")

    def _message_target(self, who: str):
        """(name to send to, None), or (None, a FastResult saying why not), or (None, None) when it isn't about a person."""
        try:
            have_notifications = self.phone.messages_enabled()
        except Exception:
            have_notifications = False
        if not who:
            rows = self.phone.recent_messages(1, "") if have_notifications else []
            if not rows:
                return None, FastResult("[caring] I don't see a message to reply to. Say who it is, like “message Rahul saying I'm coming”.", ok=False)
            return str(rows[0].get("sender") or rows[0].get("conv") or ""), None
        rows = self.phone.recent_messages(6, who) if have_notifications else []
        if rows:
            names = []
            for r in rows:
                n = str(r.get("sender") or "")
                if n and n not in names:
                    names.append(n)
            exact = [n for n in names if n.lower() == who.lower()]
            if len(names) > 1 and len(exact) != 1 and not all(n.lower().startswith(who.lower()) and n.lower().split()[0] == names[0].lower().split()[0] for n in names):
                return None, FastResult(f"[curious] More than one person matches: {', '.join(names[:4])}. Say the full name of the one you mean.", ok=False)
            return (exact[0] if exact else names[0] if names else who), None
        return self._resolve(who)

    # ------------------------------------------------------------------ messages

    def _no_messages(self, who: str) -> FastResult:
        """Nothing to read. Say why in plain words, instead of a bare 'no messages' that may simply be wrong."""
        info: Dict[str, Any] = {}
        try:
            getter = getattr(self.phone, "message_status", None)
            info = getter() if getter else {}
        except Exception:
            info = {}
        if info and info.get("enabled") and not info.get("connected"):
            return FastResult("[caring] Android hasn't connected me to your notifications yet, so I can't see your messages. I've asked it to reconnect. "
                              "Please ask me again in a few seconds. If it keeps happening, switch “Luna messages” off and on again in Notification access.",
                              ok=False, note="Notifications not connected")
        text = f"I don't see any recent messages from {who}." if who else "I don't see any new messages."
        if info and info.get("connected") and int(info.get("seen") or 0) == 0:
            text += " I haven't seen any message notification since I connected, so if you did get one, check that notifications are switched on for that app."
        return FastResult("[calm] " + text, note="No messages")

    @staticmethod
    def _person(t: str) -> str:
        for rx in _FROM:
            m = rx.search(t)
            if m:
                who = m.group(1).strip()
                if who and who not in ("me", "my", "the", "a", "luna", "whatsapp", "messages", "my messages"):
                    return who
        return ""

    def _open_message(self, t: str) -> Optional[FastResult]:
        m = _OPEN_MSG.match(t)
        if not (m or _OPEN_MSG_HI.match(t)):
            return None
        who = (m.group(1) if m and m.group(1) else "") or self._person(t)
        app_word = re.search(r"\b(whatsapp|instagram|insta)\b", t)
        if app_word and (not who or who.strip() in ("whatsapp", "instagram", "insta")):
            who = "instagram" if app_word.group(1) == "insta" else app_word.group(1)
        if not self.phone.messages_enabled():
            return self._link_problem() or FastResult("[caring] " + self.NEED_ACCESS, ok=False)
        res = self.phone.open_message(who.strip())
        if not res.startswith("ok") and who.strip():
            app = self.phone.find_app(who.strip())
            if app:  # "open my message on WhatsApp" with no message notification: open the app itself
                return FastResult(f"[calm] I don't see a new message there, so I'm opening {app}.",
                                  [{"label": f"Open app: {app}", "status": "client", "text": "",
                                    "args": {"action": "a_open_app", "name": app}}], note=f"Opened {app}")
        if res.startswith("ok"):
            return FastResult("[calm] Opening " + (f"{who}'s" if who else "your latest") + " message.", note="Opened a message")
        return FastResult("[caring] " + (res.split(":", 1)[1].strip() if ":" in res else res).capitalize(), ok=False)

    def _link_problem(self) -> Optional[FastResult]:
        err = getattr(self.phone, "error", "")
        if err:
            return FastResult("[caring] I couldn't reach the phone's own functions, so I can't tell whether access is on. "
                              f"Please tell my maker this: {err}", ok=False)
        return None

    def _who_messaged(self, t: str) -> Optional[FastResult]:
        if not (_WHO.search(t) or _READ.search(t) or _READ_HI.search(t) or _WHAT_DID.search(t)):
            return None
        if "open" in t.split()[:2]:
            return None
        if not self.phone.messages_enabled():
            return self._link_problem() or FastResult("[caring] " + self.NEED_ACCESS, ok=False)
        who = self._person(t)
        asking_who = bool(_WHO.search(t))
        latest_only = bool(_LATEST.search(t)) and not who and not asking_who
        rows = self.phone.recent_messages(12, who)
        if not rows and getattr(self.phone, "error", ""):
            return self._link_problem()
        if not rows:
            return self._no_messages(who)
        now = self.now()
        # one entry per conversation (newest first), so a chatty friend doesn't hide everyone else
        convs: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            convs.setdefault(f"{r.get('app','')}|{r.get('conv') or r.get('sender','')}", []).append(r)
        out: List[str] = []
        if who:
            first = next(iter(convs.values()))
            sender = first[0].get("sender") or who
            lines = [f"{str(r.get('text',''))[:240]}" for r in reversed(first[:5])]
            out.append(f"[calm] Recent messages from {sender} on {first[0].get('app') or 'your phone'}:")
            out += [f"“{line}”" for line in lines]
        else:
            keys = list(convs)[: (1 if latest_only else 3)]
            total = len(convs)
            if latest_only or total == 1:
                out.append("[calm] Your latest message:" if latest_only else "[calm] You have a new message:")
            else:
                out.append(f"[calm] {total} people messaged you. The latest {len(keys)}:")
            for k in keys:
                grp = convs[k]
                r = grp[0]
                text = str(r.get("text", ""))[:240]
                more = f" (and {len(grp) - 1} more)" if len(grp) > 1 else ""
                when = _ago(now - float(r.get("when", now) or now))
                title = r.get("conv") or r.get("sender") or "Someone"
                sender = r.get("sender") or title
                head = f"{title}: {sender}" if r.get("conv") and sender != title else sender
                out.append(f"{head} on {r.get('app') or 'your phone'}, {when}{more}: “{text}”")
        return FastResult("\n".join(out), note=f"Read {len(convs)} conversation(s)")

    # ------------------------------------------------------------------ the screen

    def _read_screen(self, t: str) -> Optional[FastResult]:
        if not _SCREEN.search(t):
            return None
        raw = self.phone.read_screen()
        if not raw.startswith("ok"):
            msg = raw.split(":", 1)[1].strip() if ":" in raw else "I can't see the screen."
            if "turn on" in msg.lower():
                msg = "I can't read the screen yet. Open Luna's Settings, tap “Turn on phone control”, switch Luna on, then ask again."
            return FastResult("[caring] " + msg[:300], ok=False)
        content = raw.split(":", 1)[1].strip()
        if "nothing readable" in content:
            return FastResult("[calm] I can't find any readable text on the screen.")
        answer = ""
        if self.summarise is not None:
            try:
                answer = self.summarise(t, content).strip()
            except Exception:
                answer = ""
        if not answer:
            answer = "Here is what's on the screen: " + content[:500]
        return FastResult(answer if answer.startswith("[") else "[calm] " + answer, note="Read the screen")
