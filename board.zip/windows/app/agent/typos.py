"""Forgiving ears: fixes small spelling and hearing mistakes in the COMMAND part of what was said or typed
(\"mesage rahull on instagrm sayin hi\" -> \"message rahull on instagram saying hi\").

Only the words that give the command are touched: the first verb, app names, and words like \"saying\".
Names of people and the message itself are left exactly as written. Wrong names are handled later, by asking.
"""
from __future__ import annotations

import difflib
import re
from typing import Dict, List

_FILLER = {"please", "pls", "hey", "ok", "okay", "luna", "can", "could", "would", "you", "kindly", "just", "now", "and"}
_VERBS = ["open", "launch", "start", "call", "ring", "dial", "phone", "message", "send", "reply", "tell", "read", "check", "show", "text", "whatsapp", "watch"]
_APPS = ["whatsapp", "instagram", "snapchat", "telegram", "messenger", "signal", "facebook", "youtube", "gmail", "spotify", "chrome", "twitter", "sms"]
_NOUNS = ["message", "messages", "everyone", "everybody", "saying", "latest", "unread", "video"]
_SEPARATORS = {"saying", "say", "says", "sayin", "sying", "that", "with", "ki", "kehna"}
# short words are too risky for fuzzy matching, so the common slips are listed
_SHORT: Dict[str, str] = {
    "opne": "open", "oepn": "open", "opn": "open", "opem": "open", "lanch": "launch", "launh": "launch",
    "clal": "call", "calll": "call", "cll": "call", "dail": "dial",
    "mesg": "message", "mssg": "message", "mesage": "message", "messge": "message", "messgae": "message", "massage": "message", "msgs": "messages",
    "sned": "send", "snd": "send", "sedn": "send", "sen": "send",
    "rply": "reply", "repli": "reply", "raply": "reply", "relpy": "reply",
    "txt": "text", "tekst": "text", "tel": "tell", "tll": "tell",
    "wats": "whatsapp", "watsapp": "whatsapp", "whatsap": "whatsapp", "whatapp": "whatsapp", "whtsapp": "whatsapp",
    "insta": "instagram", "instgram": "instagram", "instagrm": "instagram", "instragram": "instagram", "intagram": "instagram",
    "snapchta": "snapchat", "snapchatt": "snapchat", "snapchet": "snapchat", "snpachat": "snapchat",
    "telgram": "telegram", "telegrm": "telegram", "telegam": "telegram",
    "evryone": "everyone", "everone": "everyone", "eveyone": "everyone", "everyon": "everyone", "evrybody": "everybody",
    "sayin": "saying", "saing": "saying", "sying": "saying", "sayng": "saying",
}
_ALL = {"verb": _VERBS, "app": _APPS, "noun": _NOUNS}
_WORD = re.compile(r"^([^A-Za-z]*)([A-Za-z]+)([^A-Za-z]*)$")


def _closest(word: str, group: List[str]) -> str:
    if word in group or len(word) < 5:
        return ""
    hit = difflib.get_close_matches(word, group, n=1, cutoff=0.8)
    return hit[0] if hit and hit[0][0] == word[0] else ""  # people rarely get the FIRST letter wrong


def fix_command(text: str) -> str:
    tokens = (text or "").split()
    if not tokens:
        return text or ""
    seen_verb = False
    for i, tok in enumerate(tokens):
        m = _WORD.match(tok)
        if not m:
            continue
        pre, word, post = m.group(1), m.group(2), m.group(3)
        low = word.lower()
        if low in _SEPARATORS or tok.endswith(":"):
            if low in _SHORT and _SHORT[low] == "saying":
                tokens[i] = pre + "saying" + post
            break  # the message itself starts here: never touch it
        fixed = ""
        if not seen_verb and low not in _FILLER:
            seen_verb = True
            fixed = _SHORT.get(low) or ("" if low in _VERBS else _closest(low, _VERBS))
        else:
            fixed = _SHORT.get(low, "")
            if not fixed:
                for group in ("app", "noun"):
                    fixed = _closest(low, _ALL[group])
                    if fixed:
                        break
        if fixed and fixed != low:
            tokens[i] = pre + (fixed.capitalize() if word[0].isupper() else fixed) + post
    return " ".join(tokens)
