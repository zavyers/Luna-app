"""Local server behind Luna's window.

The UI is a web page shown in a native window. It talks to this server over 127.0.0.1
only. Every API call needs a random per-launch token, and the Host/Origin headers are
checked, so other websites or programs cannot drive Luna through the browser.
"""
from __future__ import annotations

import hmac
import json
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.agent import Assistant
from app.ai import AIError, MultiProvider
from app.ai.imagegen import ImageService
from app.sync import PairError, SyncManager
from app.planner import Planner, PlannerError
from app.agent.actions import ActionError, ActionRunner, normalize_platform, _APPS, _SITES
from app.agent.fast import FastIntents
from app.tools.phone_bridge import get_phone
from app.agent.speech import script_lang, shape, speakable
from app.agent.voice import call_decision, yes_no
from app.agent.wake import WakeGate
from app.chat.store import ChatStore, StoreError
from app.config import Settings, load_settings, missing_key_message
from app.config import keystore
from app.config.settings import (
    DEFAULT_ANTHROPIC_MODEL, DEFAULT_GROQ_MODEL, DEFAULT_MODEL, DEFAULT_OPENAI_MODEL, DEFAULT_XAI_MODEL,
    PROVIDER_IDS,
)
import base64
import os
import sys
from datetime import datetime
import re
from app.tools.system_info import get_system_info

WEB_DIR = Path(__file__).resolve().parent / "web"
TOKEN_PLACEHOLDER = "__LUNA_TOKEN__"
MAX_BODY = 64 * 1024
MAX_MESSAGE_CHARS = 8000
VOICE_CONFIRM_SECONDS = 30.0  # how long a spoken "say yes to send it" stays open

CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
}


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


class LunaApp:
    """All API methods. Each takes a dict and returns a JSON-serialisable dict."""

    def __init__(self, settings: Settings, store: ChatStore, assistant: Assistant, phone: Any = None) -> None:
        self.settings = settings
        self.store = store
        self.assistant = assistant
        self.token = secrets.token_urlsafe(24)
        self._connection: Dict[str, Any] = {"state": "unknown", "detail": ""}
        data_dir = Path(settings.keystore_file).parent
        self.planner = Planner(data_dir / "planner.json")
        self.platform = normalize_platform(os.environ.get("LUNA_PLATFORM") or sys.platform)
        self.runner = ActionRunner(self.planner, self.platform, forward=self._forward_action)
        self.sync = SyncManager(store, data_dir, data_dir / "images", planner=self.planner, on_action=self._remote_action)
        self.wake = WakeGate(lambda: self.settings)
        self._pending_voice: Optional[Dict[str, Any]] = None  # something that needs a spoken yes before it happens
        self.data_dir = data_dir
        assistant.actions = self.runner
        assistant.planner = self.planner
        self.phone = phone if phone is not None else (get_phone() if self.platform == "android" else None)
        assistant.fast = FastIntents(self.platform, self.phone, self.runner, {**_APPS, **_SITES}, self._summarise_screen)

    def _summarise_screen(self, question: str, content: str) -> str:
        from app.ai import ChatMessage
        prompt = (f"The user asked: {question}\nThe text visible on their phone screen (it may be messy):\n{content[:1800]}\n"
                  "Answer what they asked in two to four short sentences, in the language they used. Plain text only.")
        return self.assistant.provider.generate([ChatMessage("user", prompt)], system_instruction="You are Luna, a friendly voice assistant.").text

    def _active_chat(self) -> Optional[str]:
        """The chat open on screen, so things said out of the app land in the conversation box."""
        try:
            chat_id = (self.data_dir / "active_chat.txt").read_text(encoding="utf-8").strip()
            self.store.get_chat(chat_id)
            return chat_id
        except Exception:
            return None

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _str(args: Dict[str, Any], name: str, required: bool = True, limit: int = 200) -> Optional[str]:
        value = args.get(name)
        if value is None:
            if required:
                raise ApiError(f"Missing '{name}'.")
            return None
        if not isinstance(value, str):
            raise ApiError(f"'{name}' must be text.")
        if len(value) > limit:
            raise ApiError(f"'{name}' is too long.")
        return value

    def _chat_payload(self, chat_id: str) -> Dict[str, Any]:
        chat = self.store.get_chat(chat_id)
        try:
            (self.data_dir / "active_chat.txt").write_text(chat_id, encoding="utf-8")
        except OSError:
            pass
        project = self.store.get_project(chat.project_id) if chat.project_id else None
        return {
            "id": chat.id,
            "title": chat.title,
            "project": {"id": project.id, "name": project.name} if project else None,
            "messages": self.store.messages(chat_id),
        }

    # -- API methods ---------------------------------------------------------

    def status(self, _: Dict[str, Any]) -> Dict[str, Any]:
        if not self.settings.has_api_key:
            gemini = "missing_key"
        else:
            gemini = self._connection["state"] if self._connection["state"] != "unknown" else "configured"
        return {
            "gemini": gemini,
            "gemini_detail": self._connection["detail"],
            "model": self.settings.gemini_model,
            "providers": self._provider_list(),
            "assistant": {"name": self.settings.assistant_name, "title": self.settings.user_title,
                          "web": self.settings.web_mode, "wake_word": self.settings.wake_word,
                          "wake": self.settings.wake_required, "platform": self.platform},
            "sync": {"paired": bool(self.sync.status()["paired"]), "revision": self.sync.revision},
            "env_file": str(self.settings.env_file),
            "setup_message": missing_key_message(self.settings.env_file) if gemini == "missing_key" else "",
        }

    LABELS = {"gemini": "Gemini", "groq": "Groq", "xai": "Grok (xAI)", "openai": "OpenAI", "anthropic": "Claude"}
    DEFAULT_MODELS = {"gemini": DEFAULT_MODEL, "groq": DEFAULT_GROQ_MODEL, "xai": DEFAULT_XAI_MODEL,
                      "openai": DEFAULT_OPENAI_MODEL, "anthropic": DEFAULT_ANTHROPIC_MODEL}

    def _provider_list(self) -> list:
        saved = keystore.load(self.settings.keystore_file)
        return [
            {
                "id": pid,
                "label": self.LABELS[pid],
                "configured": bool(self.settings.key_for(pid)),
                "saved_in_app": pid in saved["keys"],
                "model": self.settings.model_for(pid),
                "model_override": saved["models"].get(pid, ""),
                "default_model": self.DEFAULT_MODELS[pid],
            }
            for pid in PROVIDER_IDS
        ]

    def apply_settings(self, new: Settings) -> None:
        self.settings = new
        self.assistant.settings = new
        provider = self.assistant.provider
        if isinstance(provider, MultiProvider):
            provider.settings = new
        if self.assistant.image_service is not None:
            self.assistant.image_service.settings = new
            self.assistant.image_dir = Path(new.keystore_file).parent / "images"
        self._connection = {"state": "unknown", "detail": ""}

    def keys_status(self, _: Dict[str, Any]) -> Dict[str, Any]:
        """Which keys exist. The keys themselves are never sent to the page."""
        return {
            "providers": self._provider_list(),
            "preferred": self.settings.preferred_provider or "",
        }

    _MODEL_RE = re.compile(r"^[A-Za-z0-9._:/\-]{1,80}$")

    def save_keys(self, args: Dict[str, Any]) -> Dict[str, Any]:
        keys = args.get("keys") or {}
        models = args.get("models") or {}
        clear = args.get("clear") or []
        preferred = args.get("preferred") or ""
        if not (isinstance(keys, dict) and isinstance(models, dict) and isinstance(clear, list)
                and isinstance(preferred, str)):
            raise ApiError("Invalid request.")
        data = keystore.load(self.settings.keystore_file)
        for pid, value in keys.items():
            if pid not in PROVIDER_IDS or not isinstance(value, str):
                raise ApiError("Unknown provider.")
            value = value.strip()
            if not value:
                continue  # empty box = keep the saved key
            if len(value) > 300 or any(ch.isspace() for ch in value):
                raise ApiError("That key doesn't look right. Paste it again without spaces.")
            data["keys"][pid] = value
        for pid in clear:
            data["keys"].pop(str(pid), None)
        for pid, value in models.items():
            if pid not in PROVIDER_IDS or not isinstance(value, str):
                raise ApiError("Unknown provider.")
            value = value.strip()
            if not value:
                data["models"].pop(pid, None)
            elif self._MODEL_RE.match(value):
                data["models"][pid] = value
            else:
                raise ApiError("That model name has odd characters in it.")
        if preferred in ("", "auto"):
            data["preferred"] = None
        elif preferred in PROVIDER_IDS:
            data["preferred"] = preferred
        else:
            raise ApiError("Unknown provider.")
        try:
            keystore.save(self.settings.keystore_file, data)
        except OSError:
            raise ApiError("Luna couldn't save the settings on this device.", 500)
        self.apply_settings(load_settings(self.settings.env_file, self.settings.keystore_file))
        self.assistant.log("settings", "Settings saved")
        return self.keys_status({})

    _NAME_RE = re.compile(r"^[\w][\w '\-\.]{0,23}$", re.UNICODE)

    def profile_set(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """The assistant's name, what she calls the user, and how much she uses the internet."""
        data = keystore.load(self.settings.keystore_file)
        profile = data["profile"]
        if "name" in args:
            name = str(args.get("name") or "").strip()
            if not self._NAME_RE.match(name):
                raise ApiError("Pick a name of 1 to 24 letters or numbers.")
            profile["name"] = name
        if "title" in args:
            title = str(args.get("title") or "").strip()
            if not re.match(r"^[\w][\w '\-\.]{0,19}$", title, re.UNICODE):
                raise ApiError("Pick a short title like sir, boss or madam.")
            profile["title"] = title
        if "wake_word" in args:
            phrase = " ".join(str(args.get("wake_word") or "").lower().split())
            if phrase and not re.match(r"^[\w ]{2,40}$", phrase, re.UNICODE):
                raise ApiError("The wake word can have letters and spaces only.")
            profile["wake_word"] = phrase
        if "wake" in args:
            profile["wake"] = "on" if args.get("wake") else "off"
        if "web" in args:
            if args.get("web") not in ("smart", "always", "off"):
                raise ApiError("Unknown internet mode.")
            profile["web"] = args["web"]
        try:
            keystore.save(self.settings.keystore_file, data)
        except OSError:
            raise ApiError("Luna couldn't save the settings on this device.", 500)
        self.apply_settings(load_settings(self.settings.env_file, self.settings.keystore_file))
        return self.status({})

    # -- planner, reminders, actions ------------------------------------------

    def _plan(self, fn, *a, **k) -> Dict[str, Any]:
        try:
            return fn(*a, **k)
        except PlannerError as error:
            raise ApiError(str(error), 400) from None

    def planner_month(self, args: Dict[str, Any]) -> Dict[str, Any]:
        now = datetime.now()
        return {"month": self._plan(self.planner.month, int(args.get("year") or now.year), int(args.get("month") or now.month))}

    def planner_tasks(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return {"tasks": self.planner.tasks(include_done=True)[:200]}

    def planner_add(self, args: Dict[str, Any]) -> Dict[str, Any]:
        item = self._plan(self.planner.add, str(args.get("kind") or "task"), args.get("title"), args.get("when") or None,
                          str(args.get("repeat") or "none"), args.get("remind"))
        return {"item": item}

    def planner_done(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return {"item": self._plan(self.planner.complete, self._str(args, "id"), bool(args.get("done", True)))}

    def planner_delete(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self._plan(self.planner.delete, self._str(args, "id"))
        return {"ok": True}

    def reminders_due(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return {"due": self.planner.due()}

    def reminders_upcoming(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return {"upcoming": self.planner.upcoming_reminders()[:60]}

    def run_action(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Runs one action the person has just allowed on screen."""
        action = args.get("action")
        if not isinstance(action, dict):
            raise ApiError("Nothing to do.")
        return {"result": self.runner.execute(action, confirmed=bool(args.get("confirmed")))}

    def actions_pending(self, _: Dict[str, Any]) -> Dict[str, Any]:
        """Orders from the other device that the Android app still has to carry out."""
        queue, self.runner.client_queue = self.runner.client_queue, []
        return {"actions": queue}

    def _forward_action(self, action: Dict[str, Any], confirmed: bool) -> str:
        try:
            return self.sync.send_action(action, confirmed)
        except PairError as error:
            raise ActionError(str(error)) from None

    def _remote_action(self, action: Dict[str, Any], confirmed: bool) -> str:
        return self.runner.execute(action, confirmed=confirmed, remote=True)["text"]

    # -- background voice (the Android service talks to these) ----------------

    def _voice_chat(self) -> str:
        path = self.data_dir / "voice_chat.txt"
        try:
            chat_id = path.read_text(encoding="utf-8").strip()
            self.store.get_chat(chat_id)
            return chat_id
        except Exception:
            chat_id = self.store.new_chat().id
            try:
                path.write_text(chat_id, encoding="utf-8")
            except OSError:
                pass
            return chat_id

    def voice_turn(self, text: str) -> Dict[str, Any]:
        """One spoken question, answered start to finish with no screen. For the Android background service."""
        parts, final = [], None
        for kind, value in self.assistant.handle_stream(self._active_chat() or self._voice_chat(), text):
            if kind == "chunk":
                parts.append(value)
            elif kind == "reply":
                final = value
        if final is None or not final.ok:
            msg = final.text if final else "Something went wrong."
            return {"ok": False, "speak": msg.split("\n")[0][:200], "lang": "en-US", "pitch": 1.1, "rate": 1.05, "actions": [], "confirm": []}
        emotion, words = speakable(final.text)
        pitch, rate = shape(emotion)
        confirms = [r for r in final.actions if r["status"] == "confirm"]
        if confirms:
            # No screen to press ALLOW on: read the plan back and wait for a spoken yes or no.
            first = confirms[0]
            self._pending_voice = {"action": first["args"], "until": time.time() + VOICE_CONFIRM_SECONDS}
            words = f"{self._ask_for(first)} Say yes to go ahead, or no to cancel."
            emotion = "curious"
            pitch, rate = shape(emotion)
        return {"ok": True, "speak": words, "lang": script_lang(words, "en-US"), "pitch": pitch, "rate": rate, "emotion": emotion,
                "actions": [r["args"] for r in final.actions if r["status"] == "client"],
                "confirm": []}

    @staticmethod
    def _ask_for(entry: Dict[str, Any]) -> str:
        """What Luna reads back before doing something that needs an OK."""
        args = entry.get("args") or {}
        name = str(args.get("action", ""))
        if name in ("send_message", "reply_message"):
            people = [x for x in str(args.get("to") or "").split("|") if x]
            to = (people[0] if len(people) == 1 else ", ".join(people[:-1]) + " and " + people[-1]) if people else "your latest message"
            app = {"whatsapp": " on WhatsApp", "sms": " by SMS", "instagram": " on Instagram", "snapchat": " on Snapchat", "telegram": " on Telegram",
                   "messenger": " on Messenger", "signal": " on Signal"}.get(str(args.get("app", "")), "")
            return f"Send “{str(args.get('text', ''))[:200]}” to {to}{app}?"
        label = str(entry.get("label") or "Do that").replace(" (other device)", "")
        return f"{label} on your other device?" if args.get("on") == "other" else f"{label}?"

    def _say(self, words: str, actions: Optional[List[Dict[str, Any]]] = None, emotion: str = "calm") -> Dict[str, Any]:
        pitch, rate = shape(emotion)
        return {"ok": True, "speak": words, "lang": script_lang(words, "en-US"), "pitch": pitch, "rate": rate, "emotion": emotion,
                "actions": actions or [], "confirm": []}

    def _voice_confirm(self, text: str) -> Optional[Dict[str, Any]]:
        """The answer to the question Luna just asked ('Send ... to Rahul? Say yes'). None if nothing was pending."""
        pending = self._pending_voice
        if not pending:
            return None
        if time.time() > pending["until"]:
            self._pending_voice = None
            return None
        answer = yes_no(text)
        if not answer:
            return None  # not an answer: leave the question open until it times out
        self._pending_voice = None
        if answer == "no":
            return self._say("Okay, I won't do it.")
        result = self.runner.execute(pending["action"], confirmed=True)
        if result["status"] == "client":
            return self._say("Okay, doing it.", [result["args"]])
        if result["status"] == "failed":
            return self._say("Sorry, I couldn't do that. " + str(result.get("text") or ""), emotion="caring")
        return self._say(str(result.get("text") or "Done.")[:120])

    def call_reply(self, text: str) -> str:
        """While the phone is ringing: 'accept', 'decline' or '' for what was just said."""
        return call_decision(text)

    def keep_awake(self) -> float:
        """Luna has just finished speaking: the follow-up window (no need to say "Hey Luna" again) starts now.
        It is longer while she is talking about something on the screen, since the person is still looking at it."""
        looked = getattr(self.assistant, "_screen", None) is not None and self.assistant._screen_fresh()
        seconds = 25.0 if looked else 12.0
        self.wake.extend(seconds=seconds)
        return seconds

    def background_heard(self, text: str) -> Dict[str, Any]:
        answered = self._voice_confirm(text)
        if answered is not None:
            self.wake.extend()
            return {"state": "reply", **answered}
        state, command = self.wake.process(text)
        if state == "command":
            out = self.voice_turn(command)
            self.wake.extend()
            return {"state": "reply", **out}
        return {"state": state}

    # -- pairing two devices --------------------------------------------------

    def _pair(self, fn, *a) -> Dict[str, Any]:
        try:
            return {"pair": fn(*a)}
        except PairError as error:
            raise ApiError(str(error), 400) from None

    def pair_start(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return self._pair(self.sync.start_pairing)

    def pair_stop(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return self._pair(self.sync.stop_pairing)

    def pair_status(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return {"pair": self.sync.status()}

    def pair_join(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return self._pair(self.sync.join, str(args.get("code", ""))[:12], str(args.get("address", ""))[:60])

    def pair_unpair(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return self._pair(self.sync.unpair)

    def sync_now(self, _: Dict[str, Any]) -> Dict[str, Any]:
        try:
            self.sync.sync_once()
        except PairError as error:
            raise ApiError(str(error), 400) from None
        return {"pair": self.sync.status()}

    def speak(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Optional cloud voice (female OpenAI voice). The page falls back to the device voice."""
        text = self._str(args, "text", limit=600)
        provider = self.assistant.provider
        if not hasattr(provider, "speak"):
            raise ApiError("The cloud voice isn't available.", 400)
        try:
            audio = provider.speak(text)
        except AIError as error:
            raise ApiError(str(error), 400)
        return {"audio": base64.b64encode(audio).decode("ascii")}

    def test_connection(self, _: Dict[str, Any]) -> Dict[str, Any]:
        if not self.settings.has_api_key:
            self._connection = {"state": "missing_key", "detail": ""}
            return self.status({})
        provider = self.assistant.provider
        if hasattr(provider, "check_all"):
            results = provider.check_all()
            lines = [
                f"{'OK' if ok else 'FAILED'} - {self.LABELS.get(pid, pid)}: {msg}"
                for pid, (ok, msg) in results.items()
            ]
            detail = "\n".join(lines)
            state = "ready" if any(ok for ok, _ in results.values()) else "error"
            self._connection = {"state": state, "detail": detail}
            self.assistant.log("settings", "Connection test: " + ("passed" if state == "ready" else "failed"))
            return self.status({})
        try:
            provider.check_connection()
        except AIError as error:
            self._connection = {"state": "error", "detail": str(error)}
            self.assistant.log("error", str(error))
        else:
            self._connection = {"state": "ready", "detail": ""}
            self.assistant.log("gemini", "Connection test passed")
        return self.status({})

    def system(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return get_system_info()

    def activity(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return {"items": self.assistant.activity()}

    def overview(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return self.store.overview(
            self._str(args, "query", required=False) or "",
            self._str(args, "keep_id", required=False) or None,
        )

    def open_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return self._chat_payload(self._str(args, "chat_id"))

    def start(self, _: Dict[str, Any]) -> Dict[str, Any]:
        """Chat to show when Luna opens: a fresh one (an existing empty chat is reused).
        Earlier conversations stay one click away in the menu."""
        return self._chat_payload(self.store.new_chat().id)

    def new_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        project_id = self._str(args, "project_id", required=False)
        chat = self.store.new_chat(project_id or None)
        self.assistant.log("chat", "Started a new chat")
        return self._chat_payload(chat.id)

    def new_project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        chat = self.store.new_project(self._str(args, "name", required=False) or None)
        project = self.store.get_project(chat.project_id)
        self.assistant.log("project", f"Created project “{project.name}”")
        return self._chat_payload(chat.id)

    def rename_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self.store.rename_chat(self._str(args, "chat_id"), self._str(args, "title"))
        return {"ok": True}

    def rename_project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self.store.rename_project(self._str(args, "project_id"), self._str(args, "name"))
        return {"ok": True}

    def delete_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self.store.delete_chat(self._str(args, "chat_id"))
        self.assistant.log("chat", "Deleted a chat")
        return {"ok": True}

    def delete_project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        removed = self.store.delete_project(self._str(args, "project_id"))
        self.assistant.log("project", f"Deleted a project and {removed} chat(s)")
        return {"ok": True, "removed_chats": removed}

    def send(self, args: Dict[str, Any]) -> Dict[str, Any]:
        text = self._str(args, "text", limit=MAX_MESSAGE_CHARS)
        chat_id = self._str(args, "chat_id", required=False) or None
        reply = self.assistant.handle(chat_id, text)
        payload: Dict[str, Any] = {
            "ok": reply.ok,
            "text": reply.text,
            "action": reply.action,
            "error_kind": reply.error_kind,
            "restore_text": reply.restore_text,
            "actions": reply.actions,
        }
        if reply.chat_id:
            payload["chat"] = self._chat_payload(reply.chat_id)
        return payload

    def _reply_payload(self, reply: Any) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "ok": reply.ok,
            "text": reply.text,
            "action": reply.action,
            "error_kind": reply.error_kind,
            "restore_text": reply.restore_text,
            "actions": reply.actions,
        }
        if reply.chat_id:
            payload["chat"] = self._chat_payload(reply.chat_id)
        return payload

    @staticmethod
    def _images(args: Dict[str, Any]) -> list:
        """Photos attached to a message: up to 4 of {mime, data(base64)}, checked and decoded."""
        raw = args.get("images") or []
        if not isinstance(raw, list) or len(raw) > 4:
            raise ApiError("You can attach up to 4 photos.")
        out = []
        for item in raw:
            if not isinstance(item, dict) or item.get("mime") not in ("image/jpeg", "image/png", "image/webp"):
                raise ApiError("Only JPEG, PNG or WebP photos can be attached.")
            try:
                data = base64.b64decode(str(item.get("data", "")), validate=True)
            except ValueError:
                raise ApiError("That photo could not be read.") from None
            if not data or len(data) > 6 * 1024 * 1024:
                raise ApiError("That photo is too large.")
            out.append((item["mime"], data))
        return out

    def send_stream(self, args: Dict[str, Any]):
        """Validate now, then return a generator of JSON-able events for the UI."""
        text = self._str(args, "text", limit=MAX_MESSAGE_CHARS)
        chat_id = self._str(args, "chat_id", required=False) or None
        images = self._images(args)

        def events():
            for kind, value in self.assistant.handle_stream(chat_id, text, images):
                if kind == "chunk":
                    yield {"t": "chunk", "text": value}
                elif kind == "status":
                    yield {"t": "status", "text": value}
                else:
                    yield {"t": "done", "reply": self._reply_payload(value)}

        return events()

    METHODS = (
        "status", "test_connection", "system", "activity", "overview", "open_chat", "start",
        "new_chat", "new_project", "rename_chat", "rename_project", "delete_chat",
        "delete_project", "send", "keys_status", "save_keys", "speak", "profile_set",
        "pair_start", "pair_stop", "pair_join", "pair_status", "pair_unpair", "sync_now",
        "planner_month", "planner_tasks", "planner_add", "planner_done", "planner_delete", "reminders_due",
        "reminders_upcoming", "run_action", "actions_pending",
    )

    def call(self, method: str, args: Dict[str, Any]) -> Dict[str, Any]:
        if method not in self.METHODS:
            raise ApiError("Unknown request.", 404)
        try:
            return getattr(self, method)(args)
        except StoreError as error:
            raise ApiError(str(error), 404) from None


def build_app(settings: Settings, store: Optional[ChatStore] = None, provider: Any = None, phone: Any = None) -> LunaApp:
    store = store or ChatStore()
    provider = provider or MultiProvider(settings)
    assistant = Assistant(store, provider, settings)
    assistant.image_service = ImageService(settings)
    assistant.image_dir = Path(settings.keystore_file).parent / "images"
    return LunaApp(settings, store, assistant, phone=phone)


def _make_handler(app: LunaApp, allowed_hosts: Tuple[str, ...]) -> type:
    class Handler(BaseHTTPRequestHandler):
        server_version = "Luna"
        protocol_version = "HTTP/1.1"

        def log_message(self, *_: Any) -> None:  # keep the console quiet (and key-free)
            pass

        # ------------------------------------------------------------ plumbing

        def _host_ok(self) -> bool:
            return (self.headers.get("Host") or "") in allowed_hosts

        def _send(self, status: int, body: bytes, content_type: str) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                "connect-src 'self'; media-src 'self' blob:; frame-ancestors 'none'",
            )
            self.end_headers()
            self.wfile.write(body)

        def _json(self, status: int, payload: Dict[str, Any]) -> None:
            self._send(status, json.dumps(payload).encode("utf-8"), "application/json")

        # ----------------------------------------------------------------- GET

        def do_GET(self) -> None:
            if not self._host_ok():
                return self._json(403, {"error": "Forbidden."})
            path = self.path.split("?", 1)[0]
            if path.startswith("/img/"):
                name = path[5:]
                if not re.fullmatch(r"[0-9a-f]{24}\.(png|jpg|webp)", name):
                    return self._json(404, {"error": "Not found."})
                picture = Path(app.assistant.image_dir or ".") / name
                if not picture.is_file():
                    return self._json(404, {"error": "Not found."})
                kind = {"png": "image/png", "jpg": "image/jpeg", "webp": "image/webp"}[name.rsplit(".", 1)[1]]
                return self._send(200, picture.read_bytes(), kind)
            if path == "/":
                path = "/index.html"
            target = (WEB_DIR / path.lstrip("/")).resolve()
            if WEB_DIR not in target.parents or not target.is_file() or target.suffix not in CONTENT_TYPES:
                return self._json(404, {"error": "Not found."})
            data = target.read_bytes()
            if target.name == "index.html":
                data = data.replace(TOKEN_PLACEHOLDER.encode(), app.token.encode())
            self._send(200, data, CONTENT_TYPES[target.suffix])

        # ---------------------------------------------------------------- POST

        def do_POST(self) -> None:
            if not self._host_ok():
                return self._json(403, {"error": "Forbidden."})
            origin = self.headers.get("Origin")
            if origin is not None and origin.split("://", 1)[-1] not in allowed_hosts:
                return self._json(403, {"error": "Forbidden."})
            supplied = self.headers.get("X-Luna-Token") or ""
            if not hmac.compare_digest(supplied, app.token):
                return self._json(403, {"error": "Forbidden."})
            if not self.path.startswith("/api/"):
                return self._json(404, {"error": "Not found."})

            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = -1
            if length < 0 or length > MAX_BODY:
                return self._json(413, {"error": "Request too large."})
            try:
                raw = self.rfile.read(length) if length else b"{}"
                args = json.loads(raw.decode("utf-8"))
                if not isinstance(args, dict):
                    raise ValueError
            except (ValueError, UnicodeDecodeError):
                return self._json(400, {"error": "Invalid request."})

            if self.path == "/api/send_stream":
                try:
                    events = app.send_stream(args)
                except ApiError as error:
                    return self._json(error.status, {"error": str(error)})
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Accel-Buffering", "no")
                self.send_header("Connection", "close")
                self.end_headers()
                self.close_connection = True
                try:
                    for event in events:
                        self.wfile.write(json.dumps(event).encode("utf-8") + b"\n")
                        self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    pass
                except Exception:
                    try:
                        err = {"t": "done", "reply": {"ok": False, "text": "Something went wrong inside Luna.", "error_kind": "ai"}}
                        self.wfile.write(json.dumps(err).encode("utf-8") + b"\n")
                    except Exception:
                        pass
                return

            try:
                result = app.call(self.path[len("/api/"):], args)
            except ApiError as error:
                return self._json(error.status, {"error": str(error)})
            except Exception:  # never leak internals (or secrets) to the page
                return self._json(500, {"error": "Something went wrong inside Luna."})
            self._json(200, result)

    return Handler


class LunaServer:
    def __init__(self, app: LunaApp, port: int = 0) -> None:
        self.app = app
        self._httpd = ThreadingHTTPServer(("127.0.0.1", port), _make_handler(app, ()))
        self.port = self._httpd.server_address[1]
        hosts = (f"127.0.0.1:{self.port}", f"localhost:{self.port}")
        self._httpd.RequestHandlerClass = _make_handler(app, hosts)
        self._httpd.daemon_threads = True
        self._thread: Optional[threading.Thread] = None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/"

    def start(self) -> None:
        self._thread = threading.Thread(target=self._httpd.serve_forever, name="luna-ui", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()
