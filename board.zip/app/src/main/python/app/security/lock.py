"""The app lock: a PIN, a password or a pattern. Only a salted hash of the code is stored, never the code itself.
Wrong guesses slow down: after 5 mistakes Luna waits 30 seconds, doubling each time up to 10 minutes."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Callable, Dict, Tuple

METHODS = ("none", "pin", "password", "pattern")
_ITERATIONS = 120_000
_MAX_WAIT = 600


class LockError(ValueError):
    pass


def _hash(secret: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", secret.encode("utf-8"), salt, _ITERATIONS).hex()


def _clean(method: str, secret: str) -> str:
    """The secret in its final form, or a LockError saying what is wrong with it."""
    if method == "pin":
        secret = secret.strip()
        if not re.fullmatch(r"\d{4,8}", secret):
            raise LockError("A PIN is 4 to 8 digits.")
    elif method == "password":
        if len(secret) < 4:
            raise LockError("A password needs at least 4 characters.")
    elif method == "pattern":
        if len(secret.split("-")) < 4 or not re.fullmatch(r"[1-9](?:-[1-9])+", secret):
            raise LockError("A pattern joins at least 4 dots.")
    else:
        raise LockError("Choose PIN, password or pattern.")
    return secret


class LockStore:
    def __init__(self, path: Path, now: Callable[[], float] = time.time) -> None:
        self.path, self.now = Path(path), now

    def _load(self) -> Dict[str, Any]:
        try:
            return json.loads(self.path.read_text("utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self, data: Dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data), "utf-8")
        os.replace(tmp, self.path)

    def status(self) -> Dict[str, Any]:
        d = self._load()
        method = d.get("method", "none") if d.get("hash") else "none"
        return {"method": method, "length": int(d.get("length", 0)), "wait": max(0, int(d.get("until", 0) - self.now()))}

    def check(self, secret: str) -> Tuple[bool, int]:
        """(correct, seconds to wait before the next try)."""
        d = self._load()
        if not d.get("hash"):
            return True, 0
        wait = int(d.get("until", 0) - self.now())
        if wait > 0:
            return False, wait
        ok = hmac.compare_digest(_hash(secret or "", bytes.fromhex(d["salt"])), d["hash"])
        if ok:
            d["fails"], d["until"] = 0, 0
        else:
            d["fails"] = int(d.get("fails", 0)) + 1
            if d["fails"] >= 5:
                d["until"] = self.now() + min(_MAX_WAIT, 30 * 2 ** (d["fails"] - 5))
        self._save(d)
        return ok, max(0, int(d.get("until", 0) - self.now()))

    def set(self, method: str, secret: str, current: str = "") -> None:
        """Turns the lock on or changes it. If a lock is already on, `current` must be the right code."""
        if self.status()["method"] != "none" and not self.check(current)[0]:
            raise LockError("The current code is wrong.")
        secret = _clean(method, secret)
        salt = os.urandom(16)
        self._save({"method": method, "salt": salt.hex(), "hash": _hash(secret, salt),
                    "length": len(secret) if method == "pin" else 0, "fails": 0, "until": 0})

    def clear(self, current: str) -> None:
        if self.status()["method"] != "none" and not self.check(current)[0]:
            raise LockError("That code is wrong.")
        self._save({})
