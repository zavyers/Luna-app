"""Live weather from Open-Meteo (free, no key): finds the place, then reads the current weather and a 5-day forecast."""
from __future__ import annotations

import time
from datetime import datetime
from typing import Any, Dict, Tuple

import requests

GEO, API, IP = "https://geocoding-api.open-meteo.com/v1/search", "https://api.open-meteo.com/v1/forecast", "https://ipwho.is/"
WMO = {0: ("clear sky", "☀️"), 1: ("mostly clear", "🌤️"), 2: ("partly cloudy", "⛅"), 3: ("overcast", "☁️"), 45: ("fog", "🌫️"), 48: ("freezing fog", "🌫️"),
       51: ("light drizzle", "🌦️"), 53: ("drizzle", "🌦️"), 55: ("heavy drizzle", "🌧️"), 56: ("freezing drizzle", "🌧️"), 57: ("freezing drizzle", "🌧️"),
       61: ("light rain", "🌧️"), 63: ("rain", "🌧️"), 65: ("heavy rain", "🌧️"), 66: ("freezing rain", "🌧️"), 67: ("freezing rain", "🌧️"),
       71: ("light snow", "🌨️"), 73: ("snow", "🌨️"), 75: ("heavy snow", "❄️"), 77: ("snow grains", "🌨️"), 80: ("light showers", "🌦️"),
       81: ("showers", "🌧️"), 82: ("violent showers", "⛈️"), 85: ("snow showers", "🌨️"), 86: ("heavy snow showers", "❄️"),
       95: ("thunderstorm", "⛈️"), 96: ("thunderstorm with hail", "⛈️"), 99: ("thunderstorm with hail", "⛈️")}
_CACHE: Dict[Tuple[str, bool], Tuple[float, Dict[str, Any]]] = {}


class WeatherError(Exception):
    """Safe-to-show message."""


def _get(url: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
    try:
        r = requests.get(url, params=params, timeout=8)
        r.raise_for_status()
        return r.json()
    except (requests.RequestException, ValueError):
        raise WeatherError("I couldn't reach the weather service. Check the internet and try again.") from None


def locate(place: str) -> Dict[str, Any]:
    place = " ".join((place or "").split())
    if place:
        hits = _get(GEO, {"name": place, "count": 1, "language": "en", "format": "json"}).get("results") or []
        if not hits:
            raise WeatherError(f"I couldn't find a place called {place}.")
        h = hits[0]
        return {"name": ", ".join(x for x in (h["name"], h.get("admin1") or h.get("country")) if x), "lat": h["latitude"], "lon": h["longitude"]}
    d = _get(IP)  # no place said: use where this connection is
    if not d.get("success", True) or d.get("latitude") is None:
        raise WeatherError("I don't know where you are. Say the city, like “weather in Pune”.")
    return {"name": ", ".join(x for x in (d.get("city"), d.get("region")) if x) or "Here", "lat": d["latitude"], "lon": d["longitude"]}


def report(place: str = "", fahrenheit: bool = False, fresh: bool = False) -> Dict[str, Any]:
    key = ((place or "").strip().lower(), fahrenheit)
    hit = _CACHE.get(key)
    if hit and not fresh and time.time() - hit[0] < 600:
        return hit[1]
    loc = locate(place)
    p = {"latitude": loc["lat"], "longitude": loc["lon"], "timezone": "auto", "forecast_days": 5,
         "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
         "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"}
    if fahrenheit:
        p["temperature_unit"] = "fahrenheit"
    d = _get(API, p)
    try:
        c, dl = d["current"], d["daily"]
        desc, icon = WMO.get(c["weather_code"], ("unsettled", "🌡️"))
        days = []
        for i, day in enumerate(dl["time"]):
            dd, di = WMO.get(dl["weather_code"][i], ("unsettled", "🌡️"))
            days.append({"day": "Today" if i == 0 else datetime.strptime(day, "%Y-%m-%d").strftime("%a"), "desc": dd, "icon": di,
                         "hi": round(dl["temperature_2m_max"][i]), "lo": round(dl["temperature_2m_min"][i]), "rain": int(dl["precipitation_probability_max"][i] or 0)})
        out = {"place": loc["name"], "temp": round(c["temperature_2m"]), "feels": round(c["apparent_temperature"]), "humidity": round(c["relative_humidity_2m"]),
               "wind": round(c["wind_speed_10m"]), "desc": desc, "icon": icon, "unit": "F" if fahrenheit else "C", "days": days}
    except (KeyError, IndexError, TypeError):
        raise WeatherError("The weather service sent something I couldn't read.") from None
    _CACHE[key] = (time.time(), out)
    return out


def spoken(w: Dict[str, Any]) -> str:
    t, u = w["days"][0], w["unit"]
    text = (f"In {w['place']} it's {w['temp']} degrees {u} and {w['desc']}, feels like {w['feels']}. "
            f"Today's high is {t['hi']} and low {t['lo']}, with a {t['rain']} percent chance of rain.")
    if len(w["days"]) > 1:
        n = w["days"][1]
        text += f" Tomorrow: {n['desc']}, {n['hi']} over {n['lo']}, {n['rain']} percent rain."
    return text
