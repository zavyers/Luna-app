"""Instant answers for the requests that never need the AI: opening an app, "who messaged me",
"open my latest message" and "read my screen". Going straight to the phone/PC makes them feel
immediate, because the usual path waits for a full AI round trip first.

`match()` returns None when the text isn't one of these, and Luna carries on as usual.
"""
from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass, field
from .typos import fix_command
from .voice import yes_no
from ..tools import weather as wx
from typing import Any, Callable, Dict, List, Optional

_STRIP = re.compile(r"[^\w\s'+-]", re.UNICODE)
_FILLER = r"(?:\s+(?:app|application|please|pls|for me|now|ok|okay|sir|ma'?am))*"

_OPEN = re.compile(r"^(?:(?:hey|ok|okay)\s+)?(?:luna\s+)?(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:please\s+)?(?:open|launch|start|run|go to|switch to|take me to)\s+(?:up\s+)?(?:the\s+|my\s+)?(.{1,40}?)" + _FILLER + r"$")
_OPEN_HI = re.compile(r"^(?:please\s+)?(.{1,40}?)\s+(?:kholo|khol do|khol de|kholna|open karo|open kar do|chalu karo|chalao|chala do|start karo)" + _FILLER + r"$")
_NOT_APPS = {"calendar", "my calendar", "the calendar", "calendar view", "todo", "to do", "to do list", "todo list", "tasks", "task list",
             "my tasks", "list", "new chat", "a new chat", "new project", "a new project", "chat", "message", "messages", "my messages",
             "latest message", "last message", "my latest message", "my last message", "new message", "recent message", "notifications"}

_MSG_WORDS = r"(?:messages?|msgs?|texts?|whatsapp|chats?|notifications?|dms?|conversations?)"
_OPEN_WORDS = r"(?:(?:whatsapp|instagram|insta)\s+)?(?:messages?|msgs?|texts?|chats?|dms?|conversations?|notifications?)"
_OPEN_MSG = re.compile(r"^(?:please\s+)?(?:open|show|go to|take me to)\s+(?:me\s+)?(?:the\s+|my\s+)?(?:(?:latest|last|new|recent|newest|unread)\s+)?" + _OPEN_WORDS
                       + r"(?:\s+(?:from|of|by|with|on|in|at)\s+(.{1,30}))?" + _FILLER + r"$")
_OPEN_MSG_HI = re.compile(r"^(?:mera\s+|meri\s+)?(?:(?:latest|last|new|naya|aakhri)\s+)?(?:(?:whatsapp|instagram|insta)\s+)?(?:message|msg)\s+(?:kholo|khol do|dikhao|open karo)$")
_WHO = re.compile(r"\b(?:who|whom|kisne|kaun)\b.{0,30}\b(?:messag\w*|texted|text|msg\w*|called|whatsapp\w*|sent|sent me|dm|dmed|pinged|ne message|ne msg)\b|"
                  r"\bwho(?:'s| is| has| was)?\s+(?:just\s+)?(?:messag\w+|text\w*|call\w*)\b|\bkisne\s+(?:message|msg)\b")
_READ = re.compile(r"^(?:please\s+)?(?:read|tell me|show|what(?:'s| is| are)?|any|check)\b.{0,25}\b" + _MSG_WORDS + r"\b|"
                   r"^(?:do i have|have i got|any)\s+(?:any\s+)?(?:new\s+)?" + _MSG_WORDS + r"\b|"
                   r"^(?:mere|mera|meri)\s+(?:naye\s+|new\s+|latest\s+)?(?:message|msg)\w*\s+(?:padho|sunao|batao|dikhao)")
_WHAT_DID = re.compile(r"^(?:and\s+)?what\s+(?:did|has|was|is)\s+.{1,30}?\s+(?:say|said|saying|send|sent|write|wrote|text|texted|message|messaged)\b")
_FROM = [re.compile(r"\b(?:from|of|with|by)\s+([a-z][\w .'-]{0,28}?)(?:\s+(?:on|in|please|now|today)\b.*)?$"),
         re.compile(r"\bwhat\s+(?:did|has|was)\s+([a-z][\w .'-]{0,28}?)\s+(?:say|said|send|sent|write|wrote|text|texted|message|messaged)\b")]
_SCREEN = re.compile(r"\b(?:read|summari[sz]e|describe|explain|tell me what(?:'s| is)? (?:on|in)|what(?:'s| is)? (?:on|in)|what do you see on)\s+(?:out\s+)?(?:my\s+|the\s+|this\s+)?(?:phone\s+)?(?:screen|page|display)\b|"
                     r"\bscreen\s+(?:par|pe|mein|me)\s+kya\b|\bwhat(?:'s| is)? on screen\b")
# ---- calls and chats with a person
_WA = re.compile(r"\b(?:wh?ats ?a+pp?|whatapp)\b", re.IGNORECASE)  # whatsapp, whats app, watsapp, whatsaap, whatsap ...
_IG = re.compile(r"\b(?:instagram|insta)\b")
_CALL_VERB = re.compile(r"\b(?:call|calling|ring|dial|phone|lagao|laga)\b")
_CHAT_VERB = re.compile(r"\b(?:message|msg|chat|text|dm|open)\b")
_NAME_STOP = {"please", "pls", "make", "a", "an", "give", "start", "place", "whatsapp", "whats", "app", "watsapp", "whatsap", "call", "calling",
              "video", "voice", "to", "my", "on", "using", "via", "through", "over", "in", "ko", "ka", "ki", "pe", "par", "karo", "kar", "do",
              "lagao", "laga", "ring", "phone", "dial", "can", "you", "could", "would", "me", "hey", "message", "msg", "chat", "text", "dm",
              "open", "with", "the", "latest", "last", "new", "recent", "newest", "unread", "send", "normal", "normally", "regular", "mobile",
              "sim", "from", "using", "cellular", "audio", "of", "for", "and", "i", "want", "wanna", "need", "let", "s", "lets", "now", "chat's",
              "read", "check", "show", "see", "tell", "any", "who", "what", "messages", "msgs", "texts"}
_COMMAND_WORDS = {"read", "check", "show", "see", "tell", "what", "whats", "who", "any", "do", "reply", "send", "open", "messages", "message"}
_PLAIN_CALL = re.compile(r"^(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:make\s+a\s+)?(?:(?:normal|regular|phone|mobile|cellular|sim)\s+)?"
                         r"(?:call|ring|dial|phone)\s+(?:to\s+)?(?:my\s+)?(.+?)"
                         r"(?:\s+(?:normally|normal|on (?:my )?(?:phone|sim|mobile)|using (?:the |my )?(?:sim|phone)|from (?:my )?(?:sim|phone)|please))?$")
_PLAIN_CALL_HI = re.compile(r"^(.+?)\s+ko\s+(?:(?:normal|simple|phone)\s+)?call\s+(?:karo|kar do|lagao|laga do|kardo)$")
_NOT_PEOPLE = {"me", "it", "a", "an", "the", "this", "that", "back", "off", "out", "up", "when", "if", "someone", "somebody", "anyone", "us", "them"}
_LATEST = re.compile(r"\b(?:now|latest|last|just|recent|newest|aakhri|naya)\b")
# "open whatsapp and read kate's message": the first half only says where, the second half is the real request
_MSG_TYPO = re.compile(r"\b(?:messgae|messge|mesage|massage|mesage|messsage|messeage|mssage|meessage|messaeg)(s?)\b", re.IGNORECASE)
_LEAD_OPEN = re.compile(r"^(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:please\s+)?open\s+(?:up\s+)?(?:my\s+|the\s+)?"
                        r"(?P<app>whatsapp|instagram|insta|messages|sms)(?:\s+app)?\s*(?:,|and|then|and then)\s+(?P<rest>.+)$")
_LEAD_OK = re.compile(r"^(?:read|check|show|tell me|what|any|do i|have i|who|reply|message|msg|text|send|call|ring|dial|phone|video)\b")
# "read kate's message", "read kates messages", "check rahul sharma's last text"
_POSSESSIVE = re.compile(r"\b(?:read|check|show|see|get|tell me)\s+(?:me\s+)?(?:the\s+|my\s+)?(?:(?:latest|last|new|recent|unread)\s+)?"
                         r"([a-z][a-z .-]{0,28}?)(?:'s|s'| s)?\s+(?:(?:latest|last|new|recent|unread)\s+)?(?:messages?|msgs?|texts?|chats?)\b")
_NOT_A_NAME = {"my", "the", "a", "an", "me", "all", "any", "latest", "last", "new", "recent", "unread", "newest", "whatsapp", "instagram", "insta",
               "sms", "messages", "message", "this", "that", "it", "luna", "your", "our"}
# "call mom and tell her to make dinner"
_CALL_TELL = re.compile(
    r"^(?:please\s+)?(?:(?:can|could|would)\s+you\s+)?(?:(?:make\s+a\s+)?(?:(?:whatsapp|normal|phone)\s+)?call|phone|ring)\s+"
    r"(?P<who>[A-Za-z][\w .'-]{0,38}?)\s*,?\s+(?:and\s+|then\s+|and then\s+)?(?P<verb>tell|say|let)\s+(?:(?:her|him|them)\s+)?(?P<rest>.+)$", re.IGNORECASE)
_READ_HI = re.compile(r"^(?:mera\s+|meri\s+|mere\s+)?(?:last|latest|aakhri|naya|naye|new)\s+(?:message|msg)\w*(?:\s+(?:padho|sunao|batao|dikhao|kya hai|kaun sa hai))?$")

# ---- sending a message by voice ("message Rahul saying I'm coming")
_SM_VIA = r"(?:whatsapp|sms|instagram|insta|ig|snapchat|snap|telegram|messenger|signal|linkedin|discord|slack|skype|viber|wechat|teams|text)"
_APP_RX = r"(?:whatsapp|sms|instagram|insta|ig|snapchat|snap|telegram|messenger|signal|linkedin|discord|slack|skype|viber|wechat|teams)"
_SM = re.compile(
    r"^(?:please\s+)?(?:(?:can|could|would)\s+you\s+)?"
    r"(?:send\s+(?:a\s+|an\s+)?(?:(?P<via>" + _SM_VIA + r")\s+)?(?:message|msg|text)\s+to|(?P<via2>" + _APP_RX + r"|message|msg|text|dm)|tell)\s+"
    r"(?P<who>[A-Za-z][\w .,&'-]{0,90}?)(?:\s+(?:on|in|via|through|using)\s+(?P<app>" + _APP_RX + r"))?\s*[,:]?\s+"
    r"(?:saying|say|says|that|to say|with the message|with)\s+(?P<body>.+)$", re.IGNORECASE)
_SM_TELL = re.compile(
    r"^(?:please\s+)?tell\s+(?P<rest>[A-Za-z][\w .'-]{0,60}?\s+(?:i|i'm|im|i am|i'll|i will|we|we're|it's|its|that|to|good|happy|thank|thanks|sorry|call|come|wait|"
    r"please|ok|okay|yes|no|hello|hi|hey|see|let|don't|dont|can|will|meet|running|stuck|busy)\b.*)$", re.IGNORECASE)
_SM_REPLY = re.compile(r"^(?:please\s+)?reply\s+(?P<tail>.+)$", re.IGNORECASE)
_SEP = re.compile(r"^(?P<a>.+?)\s+(?:saying|with|that|:)\s+(?P<b>.+)$", re.IGNORECASE)
_SEP_LEAD = re.compile(r"^(?:saying|with|that|:)\s+(?P<b>.+)$", re.IGNORECASE)
_LATEST_WORDS = {"the", "this", "that", "my", "last", "latest", "new", "it"}
_LATEST_MSG = re.compile(r"^(?:the|this|that|my)?\s*(?:last|latest|new)?\s*(?:message|msg|text|chat)\b\s*(?P<rest>.*)$", re.IGNORECASE)
_SM_HI = re.compile(
    r"^(?P<who>[A-Za-z][\w .'-]{0,38}?)\s+ko\s+(?:(?P<via>" + _APP_RX + r"|message|msg|text)\s+)?(?:karo|kar do|kardo|bhejo|bhej do|bol do|bolo|bata do|batao)?\s*"
    r"ki\s+(?P<body>.+)$", re.IGNORECASE)
# ---- the OTHER device: "open Chrome on my laptop" (from the phone), "call Mom on my phone" (from the laptop)
_PC_NOUN = r"(?:laptop|pc|computer|windows(?:\s+pc)?|desktop)"
_PHONE_NOUN = r"(?:phone|mobile|android(?:\s+phone)?)"
_DIRECT = re.compile(r"^(?:please\s+)?(?P<verb>lock|shut\s?down|power off|restart|reboot|sleep|mute|unmute)\s+(?:down\s+)?(?:my\s+|the\s+)?(?P<noun>" + _PC_NOUN + "|" + _PHONE_NOUN + r")$", re.IGNORECASE)
_VOL = re.compile(r"^(?:please\s+)?(?:turn\s+)?(?:the\s+)?(?:volume\s+)?(?P<d>up|down|louder|quieter|lower|raise|increase|decrease|mute)(?:\s+(?:the\s+)?volume)?$", re.IGNORECASE)
_MEDIA = re.compile(r"^(?:please\s+)?(?P<c>play|pause|resume|stop|next|skip|previous|go back)(?:\s+(?:the\s+)?(?:music|song|songs|video|track|playback|it))?$", re.IGNORECASE)
_CALL_CORE = re.compile(r"^(?:please\s+)?(?:make\s+a\s+)?(?:(?P<video>video)\s+)?(?:(?P<wa>whatsapp)\s+)?(?:call|ring|dial|phone)\s+(?:to\s+)?(?:(?:a\s+)?(?:video\s+)?)?(?P<who>[A-Za-z][\w .'-]{0,38}?)(?:\s+on\s+(?P<wa2>whatsapp))?$", re.IGNORECASE)
_NOT_WHO = {"me", "my", "from", "of", "the", "a", "an", "latest", "last", "new", "recent", "this", "that", "it", "back", "us", "someone", "somebody",
            "anyone", "luna", "you"}
_PRONOUNS = {"him", "her", "them", "he", "she", "they"}


@dataclass
class FastResult:
    text: str
    actions: List[Dict[str, Any]] = field(default_factory=list)  # shown like any other action: {label,status,text,args}
    ok: bool = True
    note: str = ""


_APP_ALIAS = {"whatsapp": "whatsapp", "sms": "sms", "instagram": "instagram", "insta": "instagram", "ig": "instagram", "snapchat": "snapchat",
              "snap": "snapchat", "telegram": "telegram", "messenger": "messenger", "signal": "signal", "linkedin": "linkedin",
              "discord": "discord", "slack": "slack", "skype": "skype", "viber": "viber", "wechat": "wechat", "teams": "teams"}
_APP_SHOWN = {"whatsapp": "WhatsApp", "sms": "SMS", "instagram": "Instagram", "snapchat": "Snapchat", "telegram": "Telegram",
              "messenger": "Messenger", "signal": "Signal", "linkedin": "LinkedIn", "discord": "Discord", "slack": "Slack",
              "skype": "Skype", "viber": "Viber", "wechat": "WeChat", "teams": "Teams"}
_OWN_CONTACTS = {"instagram", "snapchat", "telegram", "messenger", "signal", "linkedin", "discord", "slack", "skype", "viber", "wechat", "teams"}  # people there are found by their name in that app, not the phone's contacts
_EVERYONE = re.compile(r"^(?:everyone|everybody|all|all of them|everyone i know|everyone who messaged me|sabko|sab ko|sabhi|all of you)$", re.IGNORECASE)
_ORDINAL = {"first": 0, "1": 0, "one": 0, "1st": 0, "pehla": 0, "pehle": 0, "second": 1, "2": 1, "two": 1, "2nd": 1, "dusra": 1, "dusre": 1,
            "third": 2, "3": 2, "three": 2, "3rd": 2, "teesra": 2, "fourth": 3, "4": 3, "four": 3}
MAX_PEOPLE = 10
PENDING_SECONDS = 60


def _split_names(who: str) -> List[str]:
    parts = re.split(r"\s*,\s*|\s+(?:and|aur|plus)\s+", " ".join((who or "").replace("&", " and ").split()), flags=re.IGNORECASE)
    out: List[str] = []
    for part in parts:
        part = part.strip(" ,.")
        if part and part.lower() not in [o.lower() for o in out]:
            out.append(part)
    return out


def _clean(text: str) -> str:
    return " ".join(_STRIP.sub(" ", (text or "").lower()).split())


def _ago(seconds: float) -> str:
    s = max(0, int(seconds))
    if s < 60:
        return "just now"
    if s < 3600:
        m = s // 60
        return f"{m} minute{'s' if m != 1 else ''} ago"
    if s < 86400:
        h = s // 3600
        return f"{h} hour{'s' if h != 1 else ''} ago"
    d = s // 86400
    return f"{d} day{'s' if d != 1 else ''} ago"


class FastIntents:
    NEED_ACCESS = ("I can't see your messages yet. Open Luna's Settings and tap “Allow notification access”, switch Luna on, "
                   "and then ask me again. I only read message notifications, and only when you ask.")

    def __init__(self, platform: str, phone: Any = None, runner: Any = None, windows_apps: Optional[Dict[str, Any]] = None,
                 summarise: Optional[Callable[[str, str], str]] = None, now: Optional[Callable[[], float]] = None,
                 websites: Optional[Callable[[str], List[Dict[str, str]]]] = None) -> None:
        self.websites = websites
        self.platform = platform
        self.phone = phone
        self.runner = runner
        self.windows_apps = windows_apps or {}
        self.summarise = summarise
        import time
        self.now = now or time.time
        self._pending: Optional[Dict[str, Any]] = None  # a question Luna asked about who the person meant

    # ------------------------------------------------------------------ routing

    def _lead_in(self, text: str) -> str:
        """Fix WhatsApp typos and drop a leading "open whatsapp and" when a real request follows it."""
        text = fix_command(text or "")
        text = _WA.sub("whatsapp", text)
        text = _MSG_TYPO.sub(lambda m: "message" + (m.group(1) or ""), text)
        m = _LEAD_OPEN.match(" ".join(_STRIP.sub(" ", text.lower()).split()))
        if m and _LEAD_OK.match(m.group("rest")):
            rest, app = m.group("rest"), m.group("app")
            if app in ("whatsapp", "instagram", "insta") and re.match(r"^(?:call|ring|dial|phone)\b", rest) and not _WA.search(rest) and not _IG.search(rest):
                rest += " on whatsapp" if app == "whatsapp" else ""
            return rest
        return text

    def match(self, text: str) -> Optional[FastResult]:
        site = self._site(text)
        if site is not None:
            return site
        answered = self._pending_answer(text)
        if answered is not None:
            return answered
        text = self._lead_in(text)
        other = self._other_device(text)
        if other is not None:
            return other
        for fn in (self._weather, self._device):
            out = fn(text)
            if out is not None:
                return out
        if self.platform == "android" and self.phone is not None:
            sent = self._send_message(text)
            if sent is not None:
                return sent
        t = _clean(text)
        if not t or len(t) > 120:
            return None
        if self.platform == "android" and self.phone is not None:
            for fn in (self._call_person, self._chat_person, self._open_message, self._who_messaged, self._read_screen):
                out = fn(t)
                if out is not None:
                    return out
        return self._open_app(t)

    # ------------------------------------------------------------------ opening apps

    def _app_name(self, t: str) -> Optional[str]:
        for rx in (_OPEN, _OPEN_HI):
            m = rx.match(t)
            if m:
                name = m.group(1).strip()
                if not name or name in _NOT_APPS or len(name.split()) > 4 or re.search(r"\b(and|then|http|www|\.com)\b", name):
                    return None
                return name
        return None

    def _open_app(self, t: str) -> Optional[FastResult]:
        name = self._app_name(t)
        if not name:
            return None
        if self.platform == "android" and self.phone is not None:
            label = self.phone.find_app(name)
            if not label:
                return None  # maybe not an app at all ("open the door"): let the AI decide
            return FastResult(f"[calm] Opening {label}.", [{"label": f"Open app: {label}", "status": "client", "text": "",
                                                           "args": {"action": "a_open_app", "name": label}}], note=f"Opened {label}")
        if self.platform == "windows" and self.runner is not None and name in self.windows_apps:
            res = self.runner.execute({"action": "open_app", "name": name})
            if res.get("status") == "done":
                return FastResult(f"[calm] Opening {name.title() if name.islower() else name}.", note=f"Opened {name}")
            return FastResult("[caring] " + str(res.get("text") or "I couldn't open that."), ok=False)
        return None

    # ------------------------------------------------------------------ calls and chats with a person

    @staticmethod
    def _who_words(t: str) -> str:
        words = [w for w in t.split() if w not in _NAME_STOP]
        return " ".join(words) if 1 <= len(words) <= 3 else ""

    def _resolve(self, name: str, then: Optional[Callable[[str], Optional[FastResult]]] = None):
        """Returns (contact name, None) or (None, FastResult explaining why not or asking which one). None, None means \"not about a contact\"."""
        if not self.phone.contacts_enabled():
            return None, self._link_problem() or FastResult("[caring] I need permission to read your contacts first. Open Luna's Settings, tap “Allow contacts and calling”, "
                                    "allow it, and ask me again.", ok=False)
        res = self._resolve_one(name, "", use_chats=False)  # a phone call needs a real contact, not a chat's display name
        kind, value = res[0], res[1]
        if kind == "ok":
            return str(value), None
        if kind == "fail":
            return None, value
        if kind == "skip":
            return None, None
        options, guess = value, bool(res[2:] and res[2])
        if then is None:
            return None, FastResult(f"[curious] I found more than one: {', '.join(options)}. Say the full name of the one you mean.", ok=False)
        if guess:
            return None, self._ask(f"I couldn't find “{name}” exactly. Did you mean {self._spoken(options)[0]}?", options, then, yesno=True)
        return None, self._ask(f"I found more than one {name}: {self._join(self._spoken(options), 'or')}. Which one?", options, then, yesno=False)

    def _contact_action(self, name: str, action: str, text: str, label: str, **extra: Any) -> FastResult:
        return FastResult(f"[calm] {text}", [{"label": label, "status": "client", "text": "",
                                              "args": {"action": action, "contact": name, **extra}}], note=label)

    def _call_person(self, t: str) -> Optional[FastResult]:
        if not _CALL_VERB.search(t) and "video call" not in t:
            return None
        wa, ig = bool(_WA.search(t)), bool(_IG.search(t))
        video = bool(re.search(r"\bvideo\b", t))
        # Instagram has no way to start a call for another app, so say so instead of pretending
        if ig and not wa:
            return FastResult("[caring] I can't start Instagram calls, because Instagram doesn't allow other apps to. "
                              "I can open your Instagram messages (say “open my latest message on Instagram”), or call them on WhatsApp "
                              "or by phone if you say which.", ok=False)
        if wa:
            name = self._who_words(t)
            if not name:
                return None
            kind = "video call" if video else "call"

            def wa_call(person: str) -> FastResult:
                return self._contact_action(person, "whatsapp_call", f"Starting a WhatsApp {kind} with {person}.", f"WhatsApp {kind}: {person}", video="yes" if video else "no")

            who, problem = self._resolve(name, wa_call)
            if problem is not None:
                return problem
            if who is None:
                return None
            return wa_call(who)
        if video:
            return FastResult("[curious] Which app should I use for the video call? Say “video call … on WhatsApp”.", ok=False)
        m = _PLAIN_CALL.match(t) or _PLAIN_CALL_HI.match(t)
        if not m:
            return None
        name = m.group(1).strip()
        if not name or len(name.split()) > 3 or re.search(r"\b(and|then|http|www)\b", name):
            return None
        digits = re.sub(r"[\s-]", "", name)
        if re.fullmatch(r"\+?\d{3,15}", digits):  # a spoken number: open the dialer and let the person press call
            return FastResult(f"[calm] Opening the dialer with {digits}.", [{"label": f"Call: {digits}", "status": "client", "text": "",
                                                                          "args": {"action": "call", "number": digits}}])
        def ring(person: str) -> FastResult:
            return self._contact_action(person, "call_contact", f"Calling {person}.", f"Call: {person}")

        who, problem = self._resolve(name, ring)
        if problem is not None:
            return problem
        if who is None:
            return None
        return ring(who)

    def _chat_person(self, t: str) -> Optional[FastResult]:
        if not _WA.search(t) or _CALL_VERB.search(t) or not _CHAT_VERB.search(t):
            return None
        if _READ.search(t) or _WHO.search(t) or _WHAT_DID.search(t) or _POSSESSIVE.search(t):
            return None  # "read kate's message on whatsapp" is a request to read, handled by _who_messaged
        name = self._who_words(t)
        if not name:
            return None  # "open my latest message on whatsapp" is handled as an open-message request
        def chat(person: str) -> FastResult:
            return self._contact_action(person, "whatsapp_chat", f"Opening your WhatsApp chat with {person}.", f"WhatsApp chat: {person}")

        who, problem = self._resolve(name, chat)
        if problem is not None:
            return problem
        if who is None:
            return None
        return chat(who)

    # ------------------------------------------------------------------ the other device

    def _other_noun(self) -> str:
        return _PC_NOUN if self.platform == "android" else _PHONE_NOUN if self.platform == "windows" else ""

    def _other_core(self, raw: str):
        """The command with 'on my laptop' taken off, or None when it wasn't about the other device."""
        noun = self._other_noun()
        if not noun:
            return None
        m = re.search(r"\s*,?\s*\b(?:on|in|from|at|for|to)\s+(?:my\s+|the\s+|your\s+)?" + noun + r"\b(?:\s+(?:please|now|for me))?[\s.!?]*$", raw, re.IGNORECASE)
        if m:
            return raw[:m.start()].strip()
        m = re.match(r"^(?:on|in)\s+(?:my\s+|the\s+)?" + noun + r"\s*,?\s+(.+)$", raw, re.IGNORECASE)
        if m:
            return m.group(1).strip()
        m = _DIRECT.match(raw)
        if m and re.fullmatch(noun, m.group("noun"), re.IGNORECASE):
            return m.group("verb").lower().replace(" ", "")
        if re.match(r"^(?:please\s+)?put\s+(?:my\s+|the\s+)?" + noun + r"\s+(?:to\s+sleep|in(?:to)?\s+sleep(?:\s+mode)?)[\s.!?]*$", raw, re.IGNORECASE):
            return "sleep"
        return None

    def _other_action(self, core: str, target: str = "") -> Optional[Dict[str, Any]]:
        target = target or ("windows" if self.platform == "android" else "android")
        c = " ".join(core.split()).strip(" .!?,")
        low = c.lower()
        if not low:
            return None
        if low in ("lock", "lock screen", "lock the screen", "lock it"):
            return {"action": "lock_screen"}
        if low in ("shutdown", "shut down", "power off", "turn off", "switch off", "shut it down"):
            return {"action": "shutdown"}
        if low in ("restart", "reboot"):
            return {"action": "restart"}
        if low in ("sleep", "go to sleep", "put it to sleep", "put to sleep"):
            return {"action": "sleep_pc"}
        if low == "unmute":
            return {"action": "volume", "direction": "mute"}
        v = _VOL.match(low)
        if v:
            d = v.group("d")
            return {"action": "volume", "direction": "mute" if d == "mute" else "down" if d in ("down", "quieter", "lower", "decrease") else "up"}
        md = _MEDIA.match(low)
        if md:
            k = md.group("c")
            return {"action": "media", "control": {"play": "play_pause", "pause": "play_pause", "resume": "play_pause", "stop": "stop",
                                                    "next": "next", "skip": "next", "previous": "previous", "go back": "previous"}[k]}
        m = re.match(r"^(?:please\s+)?(?:search|google|look up)\s+(?:for\s+)?(.{1,200})$", c, re.IGNORECASE)
        if m:
            return {"action": "search_web", "query": m.group(1).strip()}
        m = re.match(r"^(?:please\s+)?close\s+(?:the\s+)?(.{1,40})$", c, re.IGNORECASE)
        if m and target == "windows":
            return {"action": "close_app", "name": m.group(1).strip()}
        m = re.match(r"^(?:please\s+)?open\s+(?:my\s+|the\s+)?(downloads|documents|desktop|pictures|music|videos)(?:\s+folder)?$", c, re.IGNORECASE)
        if m and target == "windows":
            return {"action": "open_folder", "name": m.group(1).lower()}
        m = re.match(r"^(?:please\s+)?(?:open|launch|start|run)\s+(?:up\s+)?(?:the\s+|my\s+)?(.{1,40}?)(?:\s+app)?$", c, re.IGNORECASE)
        if m:
            return {"action": "open_app", "name": m.group(1).strip()}
        if target == "android":  # from the laptop: things only the phone can do
            m = _CALL_CORE.match(c)
            if m and m.group("who").lower() not in _NOT_WHO:
                wa = bool(m.group("wa") or m.group("wa2"))
                who = m.group("who").strip()
                if wa or m.group("video"):
                    return {"action": "whatsapp_call", "contact": who, "video": "yes" if m.group("video") else "no"}
                return {"action": "call_contact", "contact": who}
            m = _SM.match(c)
            if m and m.group("who").lower().split()[0] not in _NOT_WHO:
                act = {"action": "send_message", "to": " ".join(m.group("who").split()), "text": m.group("body").strip()[:500]}
                via = (m.group("via") or m.group("via2") or m.group("app") or "").lower()
                if via in ("whatsapp", "sms"):
                    act["app"] = via
                return act
        return None

    def _other_device(self, original: str) -> Optional[FastResult]:
        """'Open Chrome on my laptop' / 'call Mom on my phone': straight to the paired device, no AI in between."""
        if self.runner is None or self.platform not in ("android", "windows"):
            return None
        raw = " ".join((original or "").split())
        raw = re.sub(r"^(?:(?:hey|ok|okay)\s+)?luna[\s,.:;!?-]*", "", raw, flags=re.IGNORECASE)
        if not raw or len(raw) > 600:
            return None
        core = self._other_core(raw)
        if core is None:
            return None
        action = self._other_action(core)
        if action is None:
            return None
        action = {**action, "on": "other"}
        res = self.runner.execute(action)
        device = "laptop" if self.platform == "android" else "phone"
        status = res.get("status")
        if status == "confirm":
            what = str(res.get("label", "do that")).replace(" (other device)", "").lower()
            return FastResult(f"[calm] I'll {what} on your {device}.", [res], note="Needs your OK")
        if status == "failed":
            return FastResult("[caring] " + str(res.get("text") or f"I couldn't reach your {device}."), ok=False, note="Other device failed")
        what = str(res.get("text") or "Done")
        return FastResult(f"[calm] On your {device}: {what}.".replace("..", "."), [res], note=f"Sent to the {device}")

    # ------------------------------------------------------------------ website links

    _SITE_WORD = r"(?:website|web ?site|site|link|url|web ?page|home ?page)s?"

    def _site(self, text: str) -> Optional[FastResult]:
        """"Give me the website of Amazon", "show the Google link for Taj Mahal": tappable links, plus a real Google search button."""
        t = _clean(re.sub(r"^\s*(?:hey\s+)?luna\b[\s,.:;!?-]*", "", text or "", flags=re.IGNORECASE))
        if not re.search(r"\b" + self._SITE_WORD + r"\b", t) or len(t.split()) > 10:
            return None
        m = (re.search(r"^(?:please\s+)?(?:give|show|send|get|find|tell|i want|i need)?\s*(?:me\s+)?(?:the\s+|a\s+)?(?:official\s+|google\s+)?"
                       + self._SITE_WORD + r"\s+(?:of|for|to|about)\s+(?:the\s+)?(?P<q>.+)$", t)
             or re.search(r"^(?:please\s+)?(?:(?:give|show|send|get|find|tell)\s+(?:me\s+)?)?(?:the\s+|a\s+)?(?P<q>.+?)\s+(?:official\s+)?" + self._SITE_WORD + r"$", t))
        if not m:
            return None
        topic = re.sub(r"\s+(?:from|on|in|using|via)\s+google$|\s+please$|^google\s+", "", m.group("q").strip()).strip()
        if not topic or topic in ("me", "it", "this", "that", "my", "the"):
            return None
        found: List[Dict[str, str]] = []
        if self.websites is not None:
            try:
                found = [r for r in (self.websites(topic + " official website") or []) if str(r.get("url", "")).startswith("http")][:3]
            except Exception:
                found = []
        links = [{"label": f"{str(r.get('title', ''))[:48]} · {re.sub(r'^https?://(www[.])?', '', str(r['url'])).split('/')[0]}", "status": "link", "text": "",
                  "args": {"action": "a_open_url", "url": str(r["url"])}} for r in found]
        links.append({"label": f"Search “{topic}” on Google", "status": "link", "text": "",
                      "args": {"action": "a_open_url", "url": "https://www.google.com/search?q=" + urllib.parse.quote_plus(topic)}})
        if found:
            say = f"[happy] Here are the best websites I found for {topic}. Tap one to open it, or the Google button for Google's own results."
        else:
            say = f"[caring] I couldn't fetch websites for {topic} just now, but you can tap the Google button for Google's own results."
        return FastResult(say, links, note="Website links")

    # ------------------------------------------------------------------ weather, alarms, installs, screenshots, laptop control

    def _weather(self, text: str) -> Optional[FastResult]:
        t = _clean(re.sub(r"^\s*(?:hey\s+)?luna\b[\s,.:;!?-]*", "", text or "", flags=re.IGNORECASE))
        ask = re.search(r"\b(?:weather|forecast|temperature|mausam)\b", t) or "मौसम" in t or (
            re.search(r"\b(?:rain|raining|umbrella|snow)\b", t) and re.match(r"^(?:will|is|does|do i|should i|going)", t))
        if not ask or len(t.split()) > 12:
            return None
        m = re.search(r"\b(?:in|at|for|of|near)\s+([a-z][a-z .'-]{1,30}?)(?:\s+(?:today|tonight|tomorrow|now|right now|please|like))*$", t) \
            or re.match(r"^([a-z][a-z .'-]{1,30}?)\s+(?:ka|ki|me|mein)\s+(?:mausam|weather)", t)
        place = m.group(1).strip() if m else ""
        if place in ("the", "my area", "here", "my city", "today", "tomorrow", "me"):
            place = ""
        try:
            w = wx.report(place)
        except wx.WeatherError as error:
            return FastResult("[caring] " + str(error), ok=False, note="Weather failed")
        return FastResult(f"[calm] {wx.spoken(w)}\n[[weather:{place}]]", note="Weather")

    def _device(self, text: str) -> Optional[FastResult]:
        raw = re.sub(r"^(?:(?:hey|ok|okay)\s+)?luna[\s,.:;!?-]*", "", " ".join((text or "").split()), flags=re.IGNORECASE).strip(" .!?")
        low = raw.lower()
        if self.runner is None or not low:
            return None
        act: Optional[Dict[str, Any]] = None
        if self.platform == "android":
            m = re.match(r"^(?:please\s+)?(?:install|download|get)\s+(?:the\s+)?(?P<n>[\w .&'+-]{2,40}?)(?:\s+app)?(?:\s+(?:from|on|in|via)\s+(?:the\s+)?(?:google\s+)?play\s?store)?$", low)
            if m and m.group("n") not in _NOT_APPS | {"it", "this", "that", "file", "files", "video", "music", "song"}:
                return FastResult(f"[calm] I'll find {m.group('n').title()} on the Play Store and press Install.",
                                  [self.runner.execute({"action": "install_app", "name": m.group("n").title()})], note="Install app")
            if re.match(r"^(?:please\s+)?(?:update (?:yourself|luna|the app|your app)|upgrade (?:yourself|luna)|self[ -]?update|check for (?:an? )?(?:new )?updates?|(?:is there|any) (?:a )?(?:new )?update)$", low):
                act = {"action": "self_update"}
            if re.match(r"^(?:please\s+)?(?:take|capture|grab|click|make)?\s*(?:a\s+|the\s+|my\s+)?(?:screen\s?shot|screen\s?capture|screen\s?grab|capture (?:the )?screen)(?:\s+(?:please|now|of (?:the |my )?(?:screen|phone)))?$", low):
                act = {"action": "screenshot"}
            m = re.match(r"^(?:please\s+)?(?:set\s+(?:an?\s+)?alarm|wake me(?:\s+up)?)\s*(?:for|at)?\s*(\d{1,2})(?:[: .](\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?(?:\s+(?:in the\s+)?(?:morning|evening|night))?$", low)
            if m:
                h, mi, ap = int(m.group(1)), int(m.group(2) or 0), (m.group(3) or "").replace(".", "")
                h = h % 12 + (12 if ap == "pm" else 0) if ap else h
                if h > 23 or mi > 59:
                    return FastResult("[curious] That time doesn't look right. Say it like “set an alarm for 6:30 am”.", ok=False)
                act = {"action": "alarm", "hour": h, "minute": mi, "label": "Luna"}
            m = re.match(r"^(?:please\s+)?(?:set\s+(?:a\s+)?)?timer\s*(?:for)?\s*(\d+)\s*(second|sec|minute|min|hour)s?$", low)
            if m:
                act = {"action": "timer", "seconds": int(m.group(1)) * {"s": 1, "m": 60, "h": 3600}[m.group(2)[0]], "label": "Luna"}
        elif self.platform == "windows":
            core = re.sub(r"\s*,?\s*\b(?:on|in|from|for)?\s*(?:the\s+|my\s+)?(?:laptop|pc|computer)\b(?:\s+please)?$", "", low).strip()
            act = self._other_action(core, "windows")
            if act and act["action"] in ("open_app", "call_contact", "whatsapp_call", "send_message"):
                act = None  # opening is handled by _open_app; calls and messages need the phone
        if not act:
            return None
        res = self.runner.execute(act)
        if res.get("status") == "failed":
            return FastResult("[caring] " + str(res.get("text") or "I couldn't do that."), ok=False, note="Failed")
        if res.get("status") == "confirm":
            return FastResult(f"[calm] I'll {str(res.get('label', 'do that')).lower()}.", [res], note="Needs your OK")
        say = {"alarm": f"Setting an alarm for {act.get('hour', 0):02d}:{act.get('minute', 0):02d}", "timer": "Starting the timer", "screenshot": "Taking a screenshot"}
        return FastResult(f"[calm] {say.get(act['action']) or str(res.get('text') or res.get('label') or 'Done')}.", [res], note=str(res.get("label") or "Done"))

    # ------------------------------------------------------------------ sending a message

    def _known_person(self, name: str) -> bool:
        try:
            if self.phone.messages_enabled() and self.phone.recent_messages(3, name):
                return True
            return bool(self.phone.contacts_enabled() and self.phone.find_contact(name))
        except Exception:
            return False

    def _split_who_body(self, rest: str):
        """'rahul sharma ok see you' -> ('rahul sharma', 'ok see you'): the longest start (1 to 3 words) that is a known person."""
        words = rest.split()
        for k in (3, 2, 1):
            if len(words) > k and self._known_person(" ".join(words[:k])):
                return " ".join(words[:k]), " ".join(words[k:])
        return "", ""

    def _parse_reply(self, tail: str):
        """What follows the word 'reply': ('who', 'what to say'), where who '' means the latest message. None if it isn't a reply."""
        t = tail.strip()
        lead = _SEP_LEAD.match(t)
        if lead:                                   # "reply saying I'm coming"
            return "", lead.group("b")
        if not re.match(r"^to\s+", t, re.IGNORECASE):
            return "", t                           # "reply yes"
        rest = re.sub(r"^to\s+", "", t, flags=re.IGNORECASE).strip()
        words = rest.split()
        if not words:
            return None
        first = words[0].lower()
        if first in _PRONOUNS:                     # "reply to him yes"
            sep = _SEP.match(rest)
            return ("", sep.group("b")) if sep else ("", " ".join(words[1:]))
        if first in _LATEST_WORDS:                 # "reply to the last message saying ok"
            lm = _LATEST_MSG.match(rest)
            if not lm:
                return None                        # "reply to this email ..." is not a chat reply
            tail2 = lm.group("rest").strip()
            lead2 = _SEP_LEAD.match(tail2)
            return ("", lead2.group("b") if lead2 else tail2)
        sep = _SEP.match(rest)
        if sep:                                    # "reply to rahul saying I'm coming"
            return sep.group("a"), sep.group("b")
        who, body = self._split_who_body(rest)     # "reply to rahul sharma ok see you"
        return (who, body) if who else None

    def _call_and_tell(self, raw: str) -> Optional[FastResult]:
        """"call mom and tell her to make dinner": Android never lets an app talk into a call, so Luna sends the words as a message."""
        m = _CALL_TELL.match(raw)
        if not m:
            return None
        who = " ".join(m.group("who").split()).strip(" ,.")
        rest = m.group("rest").strip().strip("\"“”").strip()
        rest = re.sub(r"^know\s+(?:that\s+)?", "", rest, flags=re.IGNORECASE)
        rest = re.sub(r"^that\s+", "", rest, flags=re.IGNORECASE)
        asked = bool(re.match(r"^to\s+", rest, re.IGNORECASE))
        rest = re.sub(r"^to\s+", "", rest, flags=re.IGNORECASE)
        if not who or not rest or who.lower() in _NOT_WHO or who.lower().split()[0] in _NOT_WHO:
            return None
        body = ("Please " + rest[0].lower() + rest[1:]) if asked else rest[0].upper() + rest[1:]
        if not self.phone.contacts_enabled() and not self.phone.messages_enabled():
            return self._link_problem() or FastResult("[caring] I need permission to read your contacts first. Open Luna's Settings, tap “Allow contacts and calling”, "
                                                       "allow it, and ask me again.", ok=False)
        target, problem = self._message_target(who)
        if problem is not None:
            return problem
        if target is None:
            return None
        args: Dict[str, Any] = {"action": "send_message", "to": target, "text": body[:500]}
        return FastResult(f"[calm] Android doesn't let me speak during a phone call, so I'll message {target} instead: “{body[:200]}”. "
                          f"If you'd also like to talk, say “call {target}” afterwards.",
                          [{"label": f"Message {target}: “{body[:80]}”", "status": "confirm", "text": "Needs your OK", "args": args}],
                          note="Drafted a message")

    def _send_message(self, original: str) -> Optional[FastResult]:
        raw = " ".join((original or "").split())
        if not raw or len(raw) > 600:
            return None
        raw = re.sub(r"^(?:(?:hey|ok|okay)\s+)?luna[\s,.:;!?-]*", "", raw, flags=re.IGNORECASE)
        said = self._call_and_tell(raw)
        if said is not None:
            return said
        who = body = via = ""
        is_reply = False
        m = _SM.match(raw)
        if m:
            who, body = m.group("who"), m.group("body")
            said_apps = [(m.group(g) or "").lower() for g in ("app", "via", "via2")]
            via = next((x for x in said_apps if x in _APP_ALIAS), "")
        else:
            m = _SM_HI.match(raw)
            if m:
                who, body = m.group("who"), m.group("body")
                via = (m.group("via") or "").lower()
                via = via if via in ("whatsapp", "sms") else ""
            else:
                m = _SM_TELL.match(raw)
                if m:
                    who, body = self._split_who_body(m.group("rest"))
                    if not who:
                        return None
                else:
                    m = _SM_REPLY.match(raw)
                    if not m:
                        return None
                    parsed = self._parse_reply(m.group("tail"))
                    if parsed is None:
                        return None
                    who, body = parsed
                    is_reply = True
        who = " ".join(who.split()).strip(" ,.")
        body = body.strip().strip("\"“”").strip()
        if not body or (who and (who.lower() in _NOT_WHO or who.lower().split()[0] in _NOT_WHO)):
            return None
        body = body[:500]
        via = _APP_ALIAS.get(via, "")
        if not who:  # "reply ok": the latest message
            target, problem = self._message_target("")
            if problem is not None:
                return problem
            return self._draft([target], body, via) if target else None
        if _EVERYONE.match(who):
            names = self._recent_senders(MAX_PEOPLE)
            if not names:
                return FastResult("[curious] I can only message “everyone” from the chats that wrote to you recently, and I don't see any. "
                                  "Tell me the names, like “message Rahul, Mom and Dad saying …”.", ok=False)
            return self._resolve_all(names, body, via, exact=True)
        names = _split_names(who)
        if not names or any(n.lower() in _NOT_WHO for n in names):
            return None
        return self._resolve_all(names, body, via, reply=is_reply)

    # ---- several people, short names, and asking when unsure

    def _recent_senders(self, limit: int) -> List[str]:
        try:
            if not self.phone.messages_enabled():
                return []
            out: List[str] = []
            for r in self.phone.recent_messages(30, ""):
                n = str(r.get("sender") or r.get("conv") or "").strip()
                if n and n.lower() not in [o.lower() for o in out]:
                    out.append(n)
            return out[:limit]
        except Exception:
            return []

    def _ask(self, question: str, options: List[str], then: Callable[[str], Optional[FastResult]], yesno: bool) -> FastResult:
        self._pending = {"options": options, "then": then, "yesno": yesno, "until": self.now() + PENDING_SECONDS}
        return FastResult("[curious] " + question)

    def _pick(self, t: str, options: List[str]) -> str:
        words = t.split()
        if len(words) <= 4:
            for w in words:
                if w in _ORDINAL and _ORDINAL[w] < len(options):
                    return options[_ORDINAL[w]]
        tokens = set(words) - {"the", "one", "of", "is", "it", "its", "that", "please", "ok", "okay"}
        if not tokens:
            return ""
        hits = [o for o in options if tokens <= set(_clean(o).split())]
        return hits[0] if len(hits) == 1 else ""

    def _pending_answer(self, text: str) -> Optional[FastResult]:
        """The answer to 'Did you mean Rahul Sharma?' or 'Which Rahul?'. Anything else is a new request, so the question is dropped."""
        p = self._pending
        if not p:
            return None
        if self.now() > p["until"]:
            self._pending = None
            return None
        t = _clean(re.sub(r"^\s*(?:hey\s+)?luna\b[\s,.:;!?-]*", "", text or "", flags=re.IGNORECASE))
        if not t:
            return None
        t = re.sub(r"\b(\d) (?=\d\b)", r"\1", re.sub(r"\b(\d) (?=\d\b)", r"\1", t))  # "5 6 7 8" -> "5678"
        options, answer = p["options"], yes_no(t)
        if p["yesno"]:
            self._pending = None
            if answer == "yes":
                return p["then"](options[0])
            if answer == "no":
                return FastResult("[calm] Okay, I won't. Tell me again with the name as it is in your contacts.")
            return None
        choice = self._pick(t, options)
        if choice:
            self._pending = None
            return p["then"](choice)
        if answer == "no":
            self._pending = None
            return FastResult("[calm] Okay, I won't.")
        if answer == "yes":
            return FastResult("[curious] Which one? " + self._join(self._spoken(options), "or") + ".")
        self._pending = None
        return None

    @staticmethod
    def _join(names: List[str], word: str = "and") -> str:
        return names[0] if len(names) == 1 else ", ".join(names[:-1]) + f" {word} " + names[-1]

    def _contact_options(self, who: str) -> List[Dict[str, Any]]:
        """People in the contacts who could be meant: [{label, fuzzy}]. Two contacts with the very same name are told apart by
        the end of their number (\"Rahul ending 5678\"), so Luna can ask which one instead of silently picking one."""
        rows = [r for r in (self.phone.find_contact(who) or []) if str(r.get("name") or "").strip()]
        if not rows:
            return []
        key = _clean(who)
        if not any(r.get("fuzzy") for r in rows):  # first names win: "ra" means Rahul, not Kiran
            starts = [r for r in rows if any(t.startswith(key) for t in _clean(str(r["name"])).split()) or _clean(str(r["name"])).startswith(key)]
            rows = starts or rows
        unique: List[Dict[str, Any]] = []
        seen_numbers = set()
        for r in rows:
            digits = re.sub(r"\D", "", str(r.get("number") or ""))
            if digits and (str(r["name"]).strip().lower(), digits[-10:]) in seen_numbers:
                continue  # the same person saved twice
            seen_numbers.add((str(r["name"]).strip().lower(), digits[-10:]))
            unique.append(r)
        counts: Dict[str, int] = {}
        for r in unique:
            counts[str(r["name"]).strip().lower()] = counts.get(str(r["name"]).strip().lower(), 0) + 1
        out: List[Dict[str, Any]] = []
        for r in unique:
            name = str(r["name"]).strip()
            digits = re.sub(r"\D", "", str(r.get("number") or ""))
            label = f"{name} ending {digits[-4:]}" if counts[name.lower()] > 1 and len(digits) >= 4 else name
            out.append({"label": label, "fuzzy": bool(r.get("fuzzy"))})
        return out

    def _resolve_one(self, who: str, via: str, use_chats: bool = True, chats_first: bool = False):
        """('ok', name) | ('ask', [options], was_a_guess) | ('fail', FastResult) | ('skip', None)."""
        try:
            have_notifications = self.phone.messages_enabled()
        except Exception:
            have_notifications = False
        names: List[str] = []
        guessed = False
        phone_contacts = via not in _OWN_CONTACTS
        if chats_first and have_notifications and use_chats:  # a reply goes to the chat that wrote: no need to ask which Rahul
            senders: List[str] = []
            for r in self.phone.recent_messages(6, who):
                n = str(r.get("sender") or "").strip()
                if n and n.lower() not in [x.lower() for x in senders]:
                    senders.append(n)
            if len(senders) == 1:
                return "ok", senders[0]
        if phone_contacts:
            if not self.phone.contacts_enabled():
                return "fail", self._link_problem() or FastResult("[caring] I need permission to read your contacts first. Open Luna's Settings, tap “Allow contacts and calling”, "
                                                                  "allow it, and ask me again.", ok=False)
            opts = self._contact_options(who)  # the contacts decide first, so two Rahuls are always asked about
            names = [o["label"] for o in opts]
            guessed = bool(opts) and all(o["fuzzy"] for o in opts)
        if not names and have_notifications and use_chats:  # chats from people who are not in the contacts, or names inside Instagram etc.
            for r in self.phone.recent_messages(6, who):
                n = str(r.get("sender") or "").strip()
                if n and n.lower() not in [x.lower() for x in names]:
                    names.append(n)
        exact = [n for n in names if n.lower() == who.lower()]
        if len(exact) == 1:
            return "ok", exact[0]
        if not names:
            if via in _OWN_CONTACTS:  # their name in that app: just search for it there
                return "ok", who.title() if who.islower() else who
            if set(who.lower().split()) & (_NOT_PEOPLE | _COMMAND_WORDS):
                return "skip", None
            return "fail", FastResult(f"[caring] I can't find anyone like “{who}” in your contacts. Say the name again, or spell it for me.", ok=False)
        if len(names) == 1:
            return ("ask", names, True) if guessed else ("ok", names[0])
        return "ask", names[:4], False

    @staticmethod
    def _spoken(options: List[str]) -> List[str]:
        """'Rahul ending 5678' is read out digit by digit."""
        return [re.sub(r"ending (\d+)", lambda m: "ending " + " ".join(m.group(1)), o) for o in options]

    def _resolve_all(self, names: List[str], body: str, via: str, done: Optional[List[str]] = None, start: int = 0,
                     exact: bool = False, reply: bool = False) -> Optional[FastResult]:
        done = list(done or [])
        for i in range(start, len(names)):
            if exact:  # names that came from the chats themselves need no matching
                done.append(names[i])
                continue
            res = self._resolve_one(names[i], via, chats_first=reply)
            kind, value, rest = res[0], res[1], res[2:]
            if kind == "ok":
                if value.lower() not in [d.lower() for d in done]:
                    done.append(value)
                continue
            if kind == "fail":
                return value
            if kind == "skip":
                return None if not done and len(names) == 1 else FastResult(f"[curious] I didn't understand “{names[i]}” as a person.", ok=False)
            options, guess = value, bool(rest and rest[0])
            then = (lambda chosen, i=i, done=list(done): self._resolve_all(names, body, via, done + [chosen], i + 1, reply=reply))
            if guess:
                return self._ask(f"I couldn't find “{names[i]}” exactly. Did you mean {self._spoken(options)[0]}?", options, then, yesno=True)
            return self._ask(f"I found more than one {names[i]}: {self._join(self._spoken(options), 'or')}. Which one?", options, then, yesno=False)
        return self._draft(done, body, via)

    def _draft(self, names: List[str], body: str, via: str) -> FastResult:
        names = [n for n in names if n]
        if not names:
            return FastResult("[curious] Who should I send it to?", ok=False)
        if len(names) > MAX_PEOPLE:
            return FastResult(f"[curious] That's {len(names)} people, and I only send to {MAX_PEOPLE} at a time. Pick fewer names.", ok=False)
        args: Dict[str, Any] = {"action": "send_message", "to": "|".join(names), "text": body}
        if via:
            args["app"] = via
        where = f" on {_APP_SHOWN[via]}" if via in _APP_SHOWN and via != "sms" else " by SMS" if via == "sms" else ""
        who = self._join(names)
        extra = f" That is {len(names)} people." if len(names) > 1 else ""
        return FastResult(f"[calm] I'll send “{body}” to {who}{where}.{extra}",
                          [{"label": f"Message {who}: “{body[:80]}”", "status": "confirm", "text": "Needs your OK", "args": args}],
                          note="Drafted a message")

    def _message_target(self, who: str):
        """(name to send to, None), or (None, a FastResult saying why not), or (None, None) when it isn't about a person."""
        try:
            have_notifications = self.phone.messages_enabled()
        except Exception:
            have_notifications = False
        if not who:
            rows = self.phone.recent_messages(1, "") if have_notifications else []
            if not rows:
                return None, FastResult("[caring] I don't see a message to reply to. Say who it is, like “message Rahul saying I'm coming”.", ok=False)
            return str(rows[0].get("sender") or rows[0].get("conv") or ""), None
        rows = self.phone.recent_messages(6, who) if have_notifications else []
        if rows:
            names = []
            for r in rows:
                n = str(r.get("sender") or "")
                if n and n not in names:
                    names.append(n)
            exact = [n for n in names if n.lower() == who.lower()]
            if len(names) > 1 and len(exact) != 1 and not all(n.lower().startswith(who.lower()) and n.lower().split()[0] == names[0].lower().split()[0] for n in names):
                return None, FastResult(f"[curious] More than one person matches: {', '.join(names[:4])}. Say the full name of the one you mean.", ok=False)
            return (exact[0] if exact else names[0] if names else who), None
        return self._resolve(who)

    # ------------------------------------------------------------------ messages

    def _no_messages(self, who: str) -> FastResult:
        """Nothing to read. Say why in plain words, instead of a bare 'no messages' that may simply be wrong."""
        info: Dict[str, Any] = {}
        try:
            getter = getattr(self.phone, "message_status", None)
            info = getter() if getter else {}
        except Exception:
            info = {}
        if info and info.get("enabled") and not info.get("connected"):
            return FastResult("[caring] Android hasn't connected me to your notifications yet, so I can't see your messages. I've asked it to reconnect. "
                              "Please ask me again in a few seconds. If it keeps happening, switch “Luna messages” off and on again in Notification access.",
                              ok=False, note="Notifications not connected")
        text = f"I don't see any recent messages from {who}." if who else "I don't see any new messages."
        if info and info.get("connected") and int(info.get("seen") or 0) == 0:
            text += " I haven't seen any message notification since I connected, so if you did get one, check that notifications are switched on for that app."
        return FastResult("[calm] " + text, note="No messages")

    @staticmethod
    def _person(t: str) -> str:
        for rx in _FROM:
            m = rx.search(t)
            if m:
                who = m.group(1).strip()
                if who and who not in ("me", "my", "the", "a", "luna", "whatsapp", "messages", "my messages"):
                    return who
        m = _POSSESSIVE.search(t)
        if m:
            who = m.group(1).strip()
            if who and not set(who.split()) <= _NOT_A_NAME:
                return " ".join(w for w in who.split() if w not in ("my", "the"))
        return ""

    def _open_message(self, t: str) -> Optional[FastResult]:
        m = _OPEN_MSG.match(t)
        if not (m or _OPEN_MSG_HI.match(t)):
            return None
        who = (m.group(1) if m and m.group(1) else "") or self._person(t)
        app_word = re.search(r"\b(whatsapp|instagram|insta)\b", t)
        if app_word and (not who or who.strip() in ("whatsapp", "instagram", "insta")):
            who = "instagram" if app_word.group(1) == "insta" else app_word.group(1)
        if not self.phone.messages_enabled():
            return self._link_problem() or FastResult("[caring] " + self.NEED_ACCESS, ok=False)
        res = self.phone.open_message(who.strip())
        if not res.startswith("ok") and who.strip():
            app = self.phone.find_app(who.strip())
            if app:  # "open my message on WhatsApp" with no message notification: open the app itself
                return FastResult(f"[calm] I don't see a new message there, so I'm opening {app}.",
                                  [{"label": f"Open app: {app}", "status": "client", "text": "",
                                    "args": {"action": "a_open_app", "name": app}}], note=f"Opened {app}")
        if res.startswith("ok"):
            return FastResult("[calm] Opening " + (f"{who}'s" if who else "your latest") + " message.", note="Opened a message")
        return FastResult("[caring] " + (res.split(":", 1)[1].strip() if ":" in res else res).capitalize(), ok=False)

    def _link_problem(self) -> Optional[FastResult]:
        err = getattr(self.phone, "error", "")
        if err:
            return FastResult("[caring] I couldn't reach the phone's own functions, so I can't tell whether access is on. "
                              f"Please tell my maker this: {err}", ok=False)
        return None

    def _who_messaged(self, t: str) -> Optional[FastResult]:
        if not (_WHO.search(t) or _READ.search(t) or _READ_HI.search(t) or _WHAT_DID.search(t)):
            return None
        if "open" in t.split()[:2]:
            return None
        if not self.phone.messages_enabled():
            return self._link_problem() or FastResult("[caring] " + self.NEED_ACCESS, ok=False)
        who = self._person(t)
        asking_who = bool(_WHO.search(t))
        latest_only = bool(_LATEST.search(t)) and not who and not asking_who
        rows = self.phone.recent_messages(12, who)
        if not rows and who.endswith("s") and len(who) > 3 and " " not in who:  # "kates message" really means Kate's
            who_s = who[:-1]
            rows = self.phone.recent_messages(12, who_s)
            if rows:
                who = who_s
        if not rows and getattr(self.phone, "error", ""):
            return self._link_problem()
        if not rows:
            return self._no_messages(who)
        now = self.now()
        # one entry per conversation (newest first), so a chatty friend doesn't hide everyone else
        convs: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            convs.setdefault(f"{r.get('app','')}|{r.get('conv') or r.get('sender','')}", []).append(r)
        out: List[str] = []
        if who:
            first = next(iter(convs.values()))
            sender = first[0].get("sender") or who
            lines = [f"{str(r.get('text',''))[:240]}" for r in reversed(first[:5])]
            out.append(f"[calm] Recent messages from {sender} on {first[0].get('app') or 'your phone'}:")
            out += [f"“{line}”" for line in lines]
        else:
            keys = list(convs)[: (1 if latest_only else 3)]
            total = len(convs)
            if latest_only or total == 1:
                out.append("[calm] Your latest message:" if latest_only else "[calm] You have a new message:")
            else:
                out.append(f"[calm] {total} people messaged you. The latest {len(keys)}:")
            for k in keys:
                grp = convs[k]
                r = grp[0]
                text = str(r.get("text", ""))[:240]
                more = f" (and {len(grp) - 1} more)" if len(grp) > 1 else ""
                when = _ago(now - float(r.get("when", now) or now))
                title = r.get("conv") or r.get("sender") or "Someone"
                sender = r.get("sender") or title
                head = f"{title}: {sender}" if r.get("conv") and sender != title else sender
                out.append(f"{head} on {r.get('app') or 'your phone'}, {when}{more}: “{text}”")
        return FastResult("\n".join(out), note=f"Read {len(convs)} conversation(s)")

    # ------------------------------------------------------------------ the screen

    def _read_screen(self, t: str) -> Optional[FastResult]:
        if not _SCREEN.search(t):
            return None
        raw = self.phone.read_screen()
        if not raw.startswith("ok"):
            msg = raw.split(":", 1)[1].strip() if ":" in raw else "I can't see the screen."
            if "turn on" in msg.lower():
                msg = "I can't read the screen yet. Open Luna's Settings, tap “Turn on phone control”, switch Luna on, then ask again."
            return FastResult("[caring] " + msg[:300], ok=False)
        content = raw.split(":", 1)[1].strip()
        if "nothing readable" in content:
            return FastResult("[calm] I can't find any readable text on the screen.")
        answer = ""
        if self.summarise is not None:
            try:
                answer = self.summarise(t, content).strip()
            except Exception:
                answer = ""
        if not answer:
            answer = "Here is what's on the screen: " + content[:500]
        return FastResult(answer if answer.startswith("[") else "[calm] " + answer, note="Read the screen")
