"""Forgiving ears: fixes small spelling and hearing mistakes in the COMMAND part of what was said or typed
(\"mesage rahull on instagrm sayin hi\" -> \"message rahull on instagram saying hi\").

Only the words that give the command are touched: the first verb, app names, and words like \"saying\".
Names of people and the message itself are left exactly as written. Wrong names are handled later, by asking.
"""
from __future__ import annotations

import difflib
import re
from typing import Dict, List

_FILLER = {"please", "pls", "hey", "ok", "okay", "luna", "can", "could", "would", "you", "kindly", "just", "now", "and"}
_VERBS = ["install", "download", "close", "lock", "mute", "unmute", "search", "google", "set", "take", "open", "launch", "start", "call", "ring", "dial", "phone", "message", "send", "reply", "tell", "read", "check", "show", "text", "whatsapp", "watch"]
_APPS = ["whatsapp", "instagram", "snapchat", "telegram", "messenger", "signal", "facebook", "youtube", "gmail", "spotify", "chrome", "twitter", "sms", "playstore", "notepad", "calculator", "settings", "camera", "weather", "forecast", "temperature", "alarm", "screenshot", "volume", "laptop", "computer"]
_NOUNS = ["message", "messages", "everyone", "everybody", "saying", "latest", "unread", "video"]
_SEPARATORS = {"saying", "say", "says", "sayin", "sying", "that", "with", "ki", "kehna"}
# short words are too risky for fuzzy matching, so the common slips are listed
_SHORT: Dict[str, str] = {
    "opne": "open", "oepn": "open", "opn": "open", "opem": "open", "lanch": "launch", "launh": "launch",
    "clal": "call", "calll": "call", "cll": "call", "dail": "dial",
    "mesg": "message", "mssg": "message", "mesage": "message", "messge": "message", "messgae": "message", "massage": "message", "msgs": "messages",
    "sned": "send", "snd": "send", "sedn": "send", "sen": "send",
    "rply": "reply", "repli": "reply", "raply": "reply", "relpy": "reply",
    "txt": "text", "tekst": "text", "tel": "tell", "tll": "tell",
    "wats": "whatsapp", "watsapp": "whatsapp", "whatsap": "whatsapp", "whatapp": "whatsapp", "whtsapp": "whatsapp",
    "insta": "instagram", "instgram": "instagram", "instagrm": "instagram", "instragram": "instagram", "intagram": "instagram",
    "snapchta": "snapchat", "snapchatt": "snapchat", "snapchet": "snapchat", "snpachat": "snapchat",
    "telgram": "telegram", "telegrm": "telegram", "telegam": "telegram",
    "evryone": "everyone", "everone": "everyone", "eveyone": "everyone", "everyon": "everyone", "evrybody": "everybody",
    "sayin": "saying", "wether": "weather", "weahter": "weather", "wheather": "weather", "weathr": "weather", "forcast": "forecast", "temprature": "temperature", "alarem": "alarm", "alram": "alarm", "screnshot": "screenshot", "screenshoot": "screenshot", "instal": "install", "isntall": "install", "downlaod": "download", "dowload": "download", "playstor": "playstore", "pasword": "password", "saing": "saying", "sying": "saying", "sayng": "saying",
}
_ALL = {"verb": _VERBS, "app": _APPS, "noun": _NOUNS}
_WORD = re.compile(r"^([^A-Za-z]*)([A-Za-z]+)([^A-Za-z]*)$")


def _dist(a: str, b: str) -> int:
    """Edit distance where swapping two neighbouring letters (opne -> open) counts as ONE slip."""
    d = [[i if j == 0 else j if i == 0 else 0 for j in range(len(b) + 1)] for i in range(len(a) + 1)]
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] != b[j - 1]))
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[-1][-1]


def _closest(word: str, group: List[str]) -> str:
    if word in group or len(word) < 4:
        return ""
    word = re.sub(r"(.)\1{2,}", r"\1\1", word)  # "calllll" -> "calll"
    limit = 1 if len(word) < 7 else 2
    best, score = "", limit + 1
    for g in group:
        d = _dist(word, g)
        if d < score and (g[0] == word[0] or sorted(g) == sorted(word)) and abs(len(g) - len(word)) <= limit:
            best, score = g, d
    return best


def fix_command(text: str) -> str:
    tokens = (text or "").split()
    if not tokens:
        return text or ""
    seen_verb = False
    for i, tok in enumerate(tokens):
        m = _WORD.match(tok)
        if not m:
            continue
        pre, word, post = m.group(1), m.group(2), m.group(3)
        low = word.lower()
        if low in _SEPARATORS or tok.endswith(":"):
            if low in _SHORT and _SHORT[low] == "saying":
                tokens[i] = pre + "saying" + post
            break  # the message itself starts here: never touch it
        fixed = ""
        if not seen_verb and low not in _FILLER:
            seen_verb = True
            fixed = _SHORT.get(low) or ("" if low in _VERBS else _closest(low, _VERBS))
        else:
            fixed = _SHORT.get(low, "")
            if not fixed:
                for group in ("app", "noun"):
                    fixed = _closest(low, _ALL[group])
                    if fixed:
                        break
        if fixed and fixed != low:
            tokens[i] = pre + (fixed.capitalize() if word[0].isupper() else fixed) + post
    return " ".join(tokens)
