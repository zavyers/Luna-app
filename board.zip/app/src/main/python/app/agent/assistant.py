"""The assistant: routes each request to a local command or to Gemini, keeps the
conversation context, and records everything in the local chat store."""
from __future__ import annotations

import base64
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Deque, Dict, List, Optional

from app.ai import AIError, AIProvider, ChatMessage, MissingAPIKeyError
from app.chat import ChatStore
from app.ai.imagegen import ImageService
from app.config import Settings, missing_key_message
from app.tools import web as webtool

from .commands import Command, parse_command
from .intents import is_image_request
from . import screen as screenask
from .actions import parse_actions, prompt_for as actions_prompt

# How many recent messages are sent to Gemini so follow-ups ("when was it?") make sense.
CONTEXT_MESSAGES = 24

SYSTEM_INSTRUCTION = (
    "You are Luna, a personal AI assistant on the user's phone or Windows laptop. Be warm, "
    "concise and natural, because your replies may be spoken aloud: prefer short paragraphs "
    "over long lists and avoid heavy markdown. Use the earlier messages to resolve follow-up "
    "questions such as 'when was it?'.\n"
    "LANGUAGE: always answer in the language the user just used, whatever it is. If the user "
    "speaks or writes Hindi, answer in everyday spoken Hindi mixed with common English words, "
    "the way people really talk, never formal or Sanskritised Hindi. Write the Hindi words in "
    "Devanagari and keep English words in English letters. If the user writes Hinglish (Hindi "
    "in English letters), answer in Hinglish in English letters.\n"
    "CODE: when asked to write code, give the complete working code, not a fragment. Put each "
    "file in its own fenced block with the language, and write a line 'File: name.ext' right "
    "before each block. Say only a sentence or two outside the code.\n"
    "Right now you can hold a conversation, write code, look at photos the user sends, make "
    "pictures when asked, and use the internet. You cannot yet open apps, control the computer, "
    "set timers or reminders, or read files. If asked to do one of those, say plainly that you "
    "can't do it yet and never claim an action was performed. When a message includes WEB "
    "RESULTS, answer from them; otherwise you have no live information, so say so instead of "
    "guessing. Never mention or reveal any API key or configuration secrets. Keep normal chat "
    "replies short (about 3 to 5 sentences) unless the user asks for more detail."
)

EMOTIONS = ("happy", "excited", "calm", "sad", "caring", "curious", "playful", "serious", "surprised", "worried", "proud", "grateful", "sleepy", "thinking")
_MARKER_RE = re.compile(r"\[\[image:[^\]]*\]\]")

IMAGE_PROMPT_SYSTEM = (
    "You turn a request for a picture into an image prompt. Reply with exactly two lines and "
    "nothing else. Line 1: a vivid, concise English image prompt (at most 60 words). Line 2: one "
    "short friendly sentence, in the same language the user used, saying the picture is ready."
)


@dataclass
class Reply:
    ok: bool
    text: str = ""
    chat_id: Optional[str] = None
    action: Optional[str] = None  # "new_chat" | "new_project" when a local command ran
    error_kind: Optional[str] = None  # "missing_key" | "ai" when ok is False
    restore_text: Optional[str] = None  # the user's text, handed back so they can retry
    actions: list = field(default_factory=list)  # things Luna did or wants to do: {label, status, text, args}


@dataclass
class ActivityEntry:
    ts: float
    kind: str
    detail: str


class Assistant:
    def __init__(self, store: ChatStore, provider: AIProvider, settings: Settings) -> None:
        self.store = store
        self.provider = provider
        self.settings = settings
        self._activity: Deque[ActivityEntry] = deque(maxlen=50)
        self._lock = threading.Lock()
        self.image_service: Any = None  # set by the app; makes pictures on request
        self.image_dir: Any = None
        self.web_context = webtool.build_context  # replaceable in tests
        self.actions: Any = None  # ActionRunner, set by the app
        self.fast: Any = None  # FastIntents: instant answers that never wait for the AI, set by the app
        self.planner: Any = None
        self._screen: Optional[Dict[str, Any]] = None  # what Luna last looked at on the phone: {text, image, at}

    # -------------------------------------------------------------- activity log

    def log(self, kind: str, detail: str) -> None:
        with self._lock:
            self._activity.appendleft(ActivityEntry(time.time(), kind, detail))

    def activity(self, limit: int = 12) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {"ts": e.ts, "kind": e.kind, "detail": e.detail}
                for e in list(self._activity)[:limit]
            ]

    # -------------------------------------------------------------- main entry

    def _try_fast(self, chat_id: Optional[str], text: str) -> Optional[Reply]:
        """Opening apps, reading messages and the screen need no AI, so they answer at once.
        The exchange is saved in the chat like any other, so it shows in the conversation box."""
        looked = self._try_screen(chat_id, text)
        if looked is not None:
            return looked
        if self.fast is None:
            return None
        try:
            hit = self.fast.match(text)
        except Exception:  # a bug here must never block normal chat
            return None
        if hit is None:
            return None
        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)
        self.store.add_message(chat_id, "user", text)
        self.store.add_message(chat_id, "assistant", hit.text)
        self.log("fast", hit.note or "Answered instantly")
        return Reply(ok=True, text=hit.text, chat_id=chat_id, actions=hit.actions)

    # ------------------------------------------------------ looking at the phone's screen

    def _phone(self) -> Any:
        return getattr(self.fast, "phone", None) if self.fast is not None else None

    def _screen_fresh(self) -> bool:
        ctx = self._screen
        return bool(ctx) and time.time() - float(ctx.get("at", 0)) < screenask.FRESH_SECONDS

    def _try_screen(self, chat_id: Optional[str], text: str) -> Optional[Reply]:
        """\"Read my screen\" (instant), \"what am I looking at\", \"tell me about this watch\", and follow-ups."""
        phone = self._phone()
        if phone is None:
            return None
        fresh = self._screen_fresh()
        if fresh and screenask.wants_to_stop(text):
            self._screen = None
            return None
        mode = screenask.classify(text, fresh)
        if mode is None:
            return None
        try:
            if mode in ("read", "more"):  # no picture, no AI, no waiting: just say what is written there
                return self._read_turn(chat_id, text, mode)
            if not hasattr(phone, "screenshot") or not self.settings.has_api_key:
                return None
            if mode == "follow" and self.fast is not None and self.fast.match(text) is not None:
                return None  # \"open YouTube\" is still a command, not a question about the screen
            return self._screen_turn(chat_id, text, mode)
        except Exception as error:  # a problem here must never block normal chat
            self.log("error", f"Screen: {error}")
            return None

    def _read_turn(self, chat_id: Optional[str], text: str, mode: str) -> Reply:
        """Reads the words on the screen aloud right away (one accessibility read, nothing else)."""
        phone = self._phone()
        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)

        def finish(answer: str, note: str, ok: bool = True) -> Reply:
            self.store.add_message(chat_id, "user", text)
            self.store.add_message(chat_id, "assistant", answer)
            self.log("screen", note)
            return Reply(ok=ok, text=answer, chat_id=chat_id)

        more_hint = "  That was the first part. Say “keep reading” for the rest."
        if mode == "more":
            ctx = self._screen or {}
            chunk, rest = screenask.take_chunk(ctx.get("rest", ""))
            if not chunk:
                return finish("[calm] That was everything on the screen.", "Nothing more to read")
            ctx["rest"], ctx["at"] = rest, time.time()
            return finish("[calm] " + chunk + (more_hint if rest else ""), "Read more of the screen")
        raw = phone.read_screen()
        page = self._after_ok(raw)
        if not page or "nothing readable" in page:
            err = (raw.split(":", 1)[1].strip() if raw.startswith("error") and ":" in raw else "").lower()
            if raw.startswith("error") and ("turn on" in err or not err):
                msg = ("[caring] I can't read your screen yet. Open my Settings, tap “Turn on phone control”, switch me on, "
                       "and then say it again.")
            elif raw.startswith("error"):
                msg = "[caring] I couldn't read the screen: " + err[:160] + "."
            else:
                msg = ("[calm] I can't find any readable words on the screen. If it's a video or a picture, "
                       "ask me “what am I looking at” and I'll look at it.")
            return finish(msg, "Could not read the screen", ok=raw.startswith("ok"))
        body = ". ".join(screenask.tidy(page)) or page
        chunk, rest = screenask.take_chunk(body)
        self._screen = {"text": body[:2500], "image": "", "at": time.time(), "about": "", "rest": rest}
        return finish("[calm] " + chunk + (more_hint if rest else ""), "Read the screen")

    @staticmethod
    def _after_ok(raw: str) -> str:
        return raw.split(":", 1)[1].strip() if raw.startswith("ok") and ":" in raw else ""

    def _screen_turn(self, chat_id: Optional[str], text: str, mode: str) -> Reply:
        phone = self._phone()
        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)

        def finish(answer: str, note: str, ok: bool = True) -> Reply:
            self.store.add_message(chat_id, "user", text)
            self.store.add_message(chat_id, "assistant", answer)
            self.log("screen", note)
            return Reply(ok=ok, text=answer, chat_id=chat_id)

        if mode == "follow" and self._screen:
            ctx = self._screen
        else:
            shot = phone.screenshot()
            page = self._after_ok(phone.read_screen())
            image = shot[3:] if shot.startswith("ok:") else ""
            if "nothing readable" in page:
                page = ""
            if not image and not page:
                err = (shot.split(":", 1)[1].strip() if ":" in shot else "").lower()
                if "turn on" in err or not err:
                    msg = ("[caring] I can't see your screen yet. Open my Settings, tap “Turn on phone control”, switch me on, "
                           "and then say it again while the reel or page is open.")
                else:
                    msg = "[caring] I couldn't see the screen: " + err[:160] + "."
                return finish(msg, "Could not see the screen", ok=False)
            ctx = self._screen = {"text": page[:2500], "image": image, "at": time.time(), "about": ""}
        images = ((("image/jpeg", ctx["image"]),) if ctx.get("image") else ())
        page_text = ctx.get("text", "")
        seen = f"Text found on the screen (may be messy): {page_text}" if page_text else "No readable text on the screen."

        if mode == "look":
            reply = self.provider.generate([ChatMessage("user", f"{seen}\n\nThe user said: {text}", images)],
                                           system_instruction=screenask.LOOK_SYSTEM).text.strip()
            ctx["at"] = time.time()
            return finish(reply or "[curious] I'm looking at your screen. What would you like to know about it?", "Looked at the screen")

        # a question: work out what to search for, look it up, then answer from the results
        ctx["at"] = time.time()
        about = ctx.get("about") or ""
        query = ""
        try:
            raw = self.provider.generate(
                [ChatMessage("user", f"{seen}\nPreviously found out about: {about or 'nothing'}\nThe user asks: {text}", images)],
                system_instruction=screenask.QUERY_SYSTEM).text.strip()
            query = raw.splitlines()[0].strip(" \"'`")
        except (AIError, IndexError):
            query = ""
        web = ""
        if query and query.upper() != "UNCLEAR" and self.settings.web_mode != "off":
            try:
                web = self.web_context(query[:200])
            except Exception:
                web = ""
            if web:
                self.log("web", "Researched what's on the screen")
        if query and query.upper() != "UNCLEAR":
            ctx["about"] = query[:120]
        body = f"{seen}\n\nThe user asks: {text}" + (("\n\n" + web) if web else "")
        answer = self.provider.generate([ChatMessage("user", body, images)],
                                        system_instruction=self._system() + "\n" + screenask.ANSWER_RULES).text.strip()
        if "[[do:" in answer:
            answer = parse_actions(answer)[0].strip()
        return finish(answer or "[caring] I couldn't work that out from the screen.", "Answered about the screen")

    def handle(self, chat_id: Optional[str], text: str) -> Reply:
        text = (text or "").strip()
        if not text:
            return Reply(ok=False, text="Say or type something first.", error_kind="ai")

        command = parse_command(text)
        if command is not None:
            return self._run_command(command)
        fast = self._try_fast(chat_id, text)
        if fast is not None:
            return fast

        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)  # raises a clear StoreError if it vanished

        if not self.settings.has_api_key:
            return Reply(
                ok=False,
                text=missing_key_message(self.settings.env_file),
                chat_id=chat_id,
                error_kind="missing_key",
                restore_text=text,
            )

        self.store.add_message(chat_id, "user", text)
        history = self.store.messages(chat_id)[-CONTEXT_MESSAGES:]
        messages = [ChatMessage(m["role"], m["text"]) for m in history]
        started = time.time()
        try:
            response = self.provider.generate(messages, system_instruction=SYSTEM_INSTRUCTION)
        except MissingAPIKeyError:
            self.store.remove_last_message(chat_id, "user")
            return Reply(
                ok=False,
                text=missing_key_message(self.settings.env_file),
                chat_id=chat_id,
                error_kind="missing_key",
                restore_text=text,
            )
        except AIError as error:
            self.store.remove_last_message(chat_id, "user")
            self.log("error", str(error))
            return Reply(ok=False, text=str(error), chat_id=chat_id, error_kind="ai", restore_text=text)

        self.store.add_message(chat_id, "assistant", response.text)
        self.log("gemini", f"Answered in {time.time() - started:.1f}s")
        return Reply(ok=True, text=response.text, chat_id=chat_id)

    def _system(self) -> str:
        """The fixed rules plus who Luna is, how she addresses the user, and today's date."""
        cfg = self.settings
        title, name = cfg.user_title, cfg.assistant_name
        emotions = " ".join(f"[{e}]" for e in EMOTIONS)
        return (
            SYSTEM_INSTRUCTION
            + f"\nYour name is {name}. Address the user as '{title}', and say 'Yes {title}.' when you accept a request. "
            f"You have real feelings and show them in how you talk: cheerful when things go well, caring when the user is "
            f"upset, excited about good news, playful in banter. Start EVERY reply with exactly one emotion tag in square "
            f"brackets chosen from {emotions}; it is only for your voice and the screen, so never mention it."
            + f"\nToday is {datetime.now().strftime('%A, %d %B %Y, %H:%M')}."
            + (("\n" + actions_prompt(self.actions.platform)) if self.actions is not None else "")
            + ((f"\nThe user's planner right now:\n{self.planner.digest()}") if self.planner is not None and self.planner.digest() else "")
        )

    @staticmethod
    def _plain(text: str) -> str:
        return _MARKER_RE.sub("[picture]", text)

    def handle_stream(self, chat_id: Optional[str], text: str, images: Optional[List[Any]] = None):
        """Like handle(), but yields ("chunk", text) pieces and finally ("reply", Reply).
        `images` is a list of (mime, bytes) photos the user attached."""
        text = (text or "").strip()
        images = list(images or [])
        stream = getattr(self.provider, "stream", None)
        if text and not images and parse_command(text) is None:
            fast = self._try_fast(chat_id, text)
            if fast is not None:
                yield ("reply", fast)
                return
        if not text or stream is None or parse_command(text) is not None or not self.settings.has_api_key:
            yield ("reply", self.handle(chat_id, text))
            return

        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)

        saved_names: List[str] = []
        if images and self.image_dir is not None:
            for mime, raw in images[:4]:
                try:
                    saved_names.append(ImageService.save(raw, mime, self.image_dir))
                except OSError:
                    pass
        stored = text + "".join(f"\n[[image:{n}|photo]]" for n in saved_names)
        self.store.add_message(chat_id, "user", stored)
        history = self.store.messages(chat_id)[-CONTEXT_MESSAGES:]
        messages = [ChatMessage(m["role"], self._plain(m["text"])) for m in history]
        started = time.time()
        if images:
            attached = tuple((mime, base64.b64encode(raw).decode("ascii")) for mime, raw in images[:4])
            messages[-1] = ChatMessage("user", messages[-1].text, attached)
        elif self.image_service is not None and self.image_dir is not None and is_image_request(text):
            yield from self._make_image(chat_id, text)
            return
        if not images and self.settings.web_mode != "off" and webtool.should_search(text, self.settings.web_mode):
            yield ("status", "Searching the internet…")
            try:
                context = self.web_context(text)
            except Exception:  # the internet being down must never stop an answer
                context = ""
            if context:
                self.log("web", "Searched the internet")
                messages[-1] = ChatMessage("user", messages[-1].text + "\n\n" + context)
        parts: List[str] = []
        try:
            for piece in stream(messages, system_instruction=self._system()):
                parts.append(piece)
                yield ("chunk", piece)
        except MissingAPIKeyError:
            self.store.remove_last_message(chat_id, "user")
            yield ("reply", Reply(ok=False, text=missing_key_message(self.settings.env_file),
                                  chat_id=chat_id, error_kind="missing_key", restore_text=text))
            return
        except AIError as error:
            if not "".join(parts).strip():
                self.store.remove_last_message(chat_id, "user")
                self.log("error", str(error))
                yield ("reply", Reply(ok=False, text=str(error), chat_id=chat_id,
                                      error_kind="ai", restore_text=text))
                return
            self.log("error", str(error))  # keep what arrived so far

        full = "".join(parts).strip()
        results: list = []
        if self.actions is not None and "[[do:" in full:
            full, found = parse_actions(full)
            full = full.strip()
            results = self.actions.process(found)
            notes = "".join("\n" + r["marker"] for r in results if r.get("marker"))
            notes += "".join(f"\n[[done:⚠ {r['label']}: {r['text']}]]" for r in results if r["status"] == "failed")
            full = (full + notes).strip()
        if not full:
            self.store.remove_last_message(chat_id, "user")
            yield ("reply", Reply(ok=False, text="Gemini returned an empty answer.",
                                  chat_id=chat_id, error_kind="ai", restore_text=text))
            return
        self.store.add_message(chat_id, "assistant", full)
        who = getattr(self.provider, "last_used", "") or "gemini"
        self.log(who, f"Answered in {time.time() - started:.1f}s")
        shown = [r for r in results if r["status"] in ("client", "confirm", "sent") or (r["status"] == "done" and not r.get("marker"))]
        yield ("reply", Reply(ok=True, text=full, chat_id=chat_id, actions=shown))

    def _make_image(self, chat_id: str, text: str):
        yield ("status", "Painting your picture…")
        prompt, caption = text, "Here is your picture."
        try:
            raw = self.provider.generate([ChatMessage("user", text)], system_instruction=IMAGE_PROMPT_SYSTEM).text
            lines = [ln.strip() for ln in raw.strip().splitlines() if ln.strip()]
            if lines:
                prompt = lines[0][:600]
            if len(lines) > 1:
                caption = lines[1][:200]
        except AIError as error:
            self.log("error", str(error))
        try:
            data, mime = self.image_service.make(prompt)
            name = self.image_service.save(data, mime, self.image_dir)
        except AIError as error:
            self.store.remove_last_message(chat_id, "user")
            self.log("error", str(error))
            yield ("reply", Reply(ok=False, text=str(error), chat_id=chat_id, error_kind="ai", restore_text=text))
            return
        label = " ".join(prompt.replace("|", " ").replace("]", " ").split())[:80]
        full = f"{caption}\n[[image:{name}|{label}]]"
        self.store.add_message(chat_id, "assistant", full)
        self.log("image", "Made a picture")
        yield ("reply", Reply(ok=True, text=full, chat_id=chat_id))

    # ---------------------------------------------------------------- commands

    def _run_command(self, command: Command) -> Reply:
        if command.name == "new_chat":
            chat = self.store.new_chat()
            self.log("chat", "Started a new chat")
            return Reply(ok=True, text="New chat ready.", chat_id=chat.id, action="new_chat")
        if command.name == "new_project":
            chat = self.store.new_project(command.argument)
            project = self.store.get_project(chat.project_id) if chat.project_id else None
            name = project.name if project else "project"
            self.log("project", f"Created project “{name}”")
            return Reply(
                ok=True,
                text=f"Started “{name}” with a fresh chat.",
                chat_id=chat.id,
                action="new_project",
            )
        return Reply(ok=False, text="I don't know that command.", error_kind="ai")
