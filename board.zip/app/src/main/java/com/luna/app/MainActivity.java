package com.luna.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 7;
    private static final int FILE_REQUEST = 8;
    private static final int BG_REQUEST = 9;
    static volatile boolean visible = false;
    private static volatile MainActivity current;

    private WebView web;
    private SpeechRecognizer recognizer;
    private String listenLang = "en-US";
    private boolean pendingListen = false;
    private boolean started = false;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Locale ttsLocale = null;
    private final ArrayList<String[]> ttsBacklog = new ArrayList<>();
    private int utteranceCount = 0;
    private ValueCallback<Uri[]> fileCallback;
    private final Ear ear = new Ear();
    private Duck duck;
    private boolean usingEar = false;
    private boolean heardSpeech = false;

    private boolean micMuted() {
        return getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        duck = new Duck(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050b14"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            // Lets the paperclip button open the phone's photo picker.
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Choose photos"), FILE_REQUEST);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "LunaNative");
        setContentView(web);
        startSpeech();
        startLuna();
        PhoneActions.warmUp(this);
        Reminders.channel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, BG_REQUEST);
        }
        if (getSharedPreferences("luna", MODE_PRIVATE).getBoolean("background", false)) startBackground();
    }

    /** What the Luna screen can ask the phone to do. */
    public class Bridge {
        @JavascriptInterface
        public void startListening(final String lang) {
            runOnUiThread(() -> beginListening(lang));
        }

        @JavascriptInterface
        public String phoneAction(final String json) {
            try {
                return PhoneActions.run(MainActivity.this, new JSONObject(json));
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void scheduleReminders(final String json) {
            Reminders.schedule(MainActivity.this, json);
        }

        @JavascriptInterface
        public void setBackground(final boolean on) {
            runOnUiThread(() -> {
                getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("background", on).apply();
                if (on) startBackground(); else stopService(new Intent(MainActivity.this, ListenService.class));
            });
        }

        @JavascriptInterface
        public void setMuted(final boolean muted) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("muted", muted).apply();
            if (muted) runOnUiThread(() -> { // really off, right now
                if (recognizer != null) recognizer.cancel();
                ear.stop();
            });
            ListenService.refresh();
        }

        @JavascriptInterface
        public boolean isMuted() {
            return getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false);
        }

        @JavascriptInterface
        public void setVoiceKind(final String kind) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putString("voice_kind", "male".equals(kind) ? "male" : "female").apply();
            runOnUiThread(() -> ttsLocale = null); // pick the voice again on the next sentence
        }

        @JavascriptInterface
        public void setListenDuringMedia(final boolean on) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("listen_during_media", on).apply();
        }

        @JavascriptInterface
        public void requestCallPermissions() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26) {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS,
                            Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 77);
                } else {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 77);
                }
            });
        }

        @JavascriptInterface
        public void openNotificationAccess() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        }

        @JavascriptInterface
        public void setName(final String name) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putString("name", name).apply();
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("background", getSharedPreferences("luna", MODE_PRIVATE).getBoolean("background", false));
                o.put("accessibility", LunaAccessibilityService.instance != null);
                o.put("overlay", Settings.canDrawOverlays(MainActivity.this));
                o.put("notificationAccess", NotificationStore.enabled(MainActivity.this));
                o.put("answering", Build.VERSION.SDK_INT >= 26 && checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED);
                o.put("contacts", Calls.canRead(MainActivity.this));
                o.put("calling", Calls.canCall(MainActivity.this));
                o.put("listenDuringMedia", getSharedPreferences("luna", MODE_PRIVATE).getBoolean("listen_during_media", false));
                o.put("muted", getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false));
                o.put("quietListening", Ear.supported());
                o.put("screenPicture", Build.VERSION.SDK_INT >= 30);
                o.put("notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void openAccessibility() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }

        @JavascriptInterface
        public void openOverlay() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.stopListening();
                ear.stop();
            });
        }

        @JavascriptInterface
        public void cancelListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.cancel();
                ear.stop();
            });
        }

        @JavascriptInterface
        public void speak(final String text, final String lang, final float pitch, final float rate) {
            runOnUiThread(() -> speakNow(text, lang, pitch, rate));
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> {
                ttsBacklog.clear();
                if (tts != null) tts.stop();
                duck.up();
            });
        }

        @JavascriptInterface
        public void saveFile(final String name, final String mime, final String base64) {
            runOnUiThread(() -> saveToDownloads(name, mime, base64));
        }

        @JavascriptInterface
        public void pinShortcut(final String name) {
            runOnUiThread(() -> pinHomeShortcut(name));
        }
    }

    private void js(String call) {
        runOnUiThread(() -> web.evaluateJavascript(call, null));
    }

    // ------------------------------------------------------------------ listening

    private void heard(String text, boolean done) {
        js("window.__lunaHeard && window.__lunaHeard(" + JSONObject.quote(text) + "," + done + ")");
    }

    private void voiceEnd() {
        js("window.__lunaVoiceEnd && window.__lunaVoiceEnd()");
    }

    private void voiceError(String message, boolean fatal) {
        js("window.__lunaVoiceError && window.__lunaVoiceError(" + JSONObject.quote(message) + "," + fatal + ")");
    }

    /** A call is ringing and the background service is listening for "accept" or "decline": Luna's own screen steps aside. */
    static void pauseWebListening() {
        final MainActivity a = current;
        if (a == null) return;
        a.runOnUiThread(() -> {
            if (a.recognizer != null) a.recognizer.cancel();
            a.ear.stop();
            a.voiceEnd();
        });
    }

    private void beginListening(String lang) {
        if (ListenService.callWindow() && ListenService.instance != null) {
            // a call is waiting for a spoken answer: don't fight the background microphone, look again in a moment
            js("setTimeout(function(){window.__lunaVoiceEnd && window.__lunaVoiceEnd()},1500)");
            return;
        }
        if (micMuted()) { // the mute button at the top means the microphone is really off
            js("window.__lunaForceMute && window.__lunaForceMute()");
            return;
        }
        if (lang != null && !lang.isEmpty()) {
            listenLang = lang;
            getSharedPreferences("luna", MODE_PRIVATE).edit().putString("lang", lang).apply();
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceError("This phone has no speech recognition. Install or enable the Google app.", true);
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { heardSpeech = true; if (usingEar) Ear.worked(); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    if (micMuted()) return;
                    ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), false);
                }

                @Override
                public void onResults(Bundle results) {
                    ear.stop();
                    if (micMuted()) { voiceEnd(); return; } // muted while I was listening: throw it away
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), true);
                    voiceEnd(); // the page starts the next listening round by itself
                }

                @Override
                public void onError(int error) {
                    ear.stop();
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_TOO_MANY_REQUESTS) {
                        final SpeechRecognizer stuck = recognizer; // a wedged recogniser never recovers by itself: the next round makes a new one
                        recognizer = null;
                        if (stuck != null) web.post(stuck::destroy);
                    }
                    if (usingEar && !heardSpeech && (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_AUDIO
                            || error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
                        Ear.refused();
                    }
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        voiceError("Allow the microphone for this app in the phone's settings.", true);
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        voiceError("Voice needs the internet. Check your connection.", false);
                    } else if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            || error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        voiceEnd(); // silence is normal while waiting for the wake word
                    } else {
                        voiceError("Voice input stopped (code " + error + ").", false);
                    }
                }
            });
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, listenLang);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, listenLang);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        usingEar = ear.attach(this, intent);
        heardSpeech = false;
        recognizer.startListening(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BG_REQUEST) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    && getSharedPreferences("luna", MODE_PRIVATE).getBoolean("background", false)) {
                startBackground();
            }
            return;
        }
        if (requestCode != MIC_REQUEST) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (ok && pendingListen) {
            pendingListen = false;
            beginListening(listenLang);
        } else {
            pendingListen = false;
            voiceError("Luna needs the microphone permission to hear you. Tap the mic at the top and allow it.", true);
        }
    }

    // --------------------------------------------------------------------- voice

    /** The phone's own text-to-speech, with a female voice chosen when one exists. */
    private void startSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setAudioAttributes(Duck.voiceAttributes()); // quiet other apps while I talk, don't stop them
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { duck.up(); js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
                @Override public void onError(String utteranceId) {
                    duck.up();
                    js("window.__lunaSpeechDone && window.__lunaSpeechDone()");
                    runOnUiThread(() -> { ttsLocale = null; Voices.useDefault(tts); }); // next sentence tries the default voice
                }
            });
            ttsReady = true;
            for (String[] item : ttsBacklog) {
                speakNow(item[0], item[1], Float.parseFloat(item[2]), Float.parseFloat(item[3]));
            }
            ttsBacklog.clear();
        });
    }

    private void useLanguage(String tag) {
        Locale want = (tag == null || tag.isEmpty()) ? Locale.getDefault() : Locale.forLanguageTag(tag);
        if (want.equals(ttsLocale)) return;
        int r = tts.setLanguage(want);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (ttsLocale == null) tts.setLanguage(Locale.US);
            return;
        }
        ttsLocale = want;
        Voices.choose(tts, want, Voices.male(this));
    }

    private void speakNow(String text, String lang, float pitch, float rate) {
        if (!ttsReady || tts == null) {
            ttsBacklog.add(new String[]{text, lang, String.valueOf(pitch), String.valueOf(rate)});
            return;
        }
        duck.down();
        useLanguage(lang);
        tts.setPitch(Voices.pitch(this, pitch));
        tts.setSpeechRate(rate);
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "luna" + (utteranceCount++));
    }

    // ------------------------------------------------------- files and the home screen

    private void saveToDownloads(String name, String mime, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("no uri");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(data);
                }
                Toast.makeText(this, "Saved " + safe + " in your Downloads folder", Toast.LENGTH_LONG).show();
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(data);
                }
                Toast.makeText(this, "Saved to " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not save the file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Android can't rename an installed app, so this adds a home-screen shortcut with the chosen name. */
    private void pinHomeShortcut(String name) {
        try {
            if (Build.VERSION.SDK_INT < 26) {
                Toast.makeText(this, "This Android version can't add shortcuts from inside the app.", Toast.LENGTH_LONG).show();
                return;
            }
            ShortcutManager sm = getSystemService(ShortcutManager.class);
            if (sm == null || !sm.isRequestPinShortcutSupported()) {
                Toast.makeText(this, "Your launcher can't add shortcuts from inside the app.", Toast.LENGTH_LONG).show();
                return;
            }
            Intent open = new Intent(Intent.ACTION_MAIN).setClass(this, MainActivity.class);
            ShortcutInfo info = new ShortcutInfo.Builder(this, "luna-" + System.currentTimeMillis())
                    .setShortLabel(name)
                    .setLongLabel(name)
                    .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                    .setIntent(open)
                    .build();
            sm.requestPinShortcut(info, null);
        } catch (Exception e) {
            Toast.makeText(this, "Could not add the shortcut: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_REQUEST || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                result = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ------------------------------------------------------- listening in the background

    private void startBackground() {
        ArrayList<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), BG_REQUEST);
            return;
        }
        Intent service = new Intent(this, ListenService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
    }

    @Override
    protected void onResume() {
        super.onResume();
        current = this;
        visible = true;
        ListenService.activityVisible = true;
        ListenService.refresh();
        // the page can't always tell it came back to the front: tell it, so what was said outside shows at once
        js("window.__lunaResume && window.__lunaResume(" + micMuted() + ")");
    }

    @Override
    protected void onPause() {
        visible = false;
        ListenService.activityVisible = false;
        ListenService.refresh();
        super.onPause();
    }

    // ------------------------------------------------------------------ the engine

    private void startLuna() {
        if (started) return;
        started = true;
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                PyObject mod = Python.getInstance().getModule("luna_android");
                final String url = mod.callAttr("start", getFilesDir().getAbsolutePath() + "/luna").toString();
                runOnUiThread(() -> web.loadUrl(url));
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Luna failed to start: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        ear.stop();
        duck.up();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
