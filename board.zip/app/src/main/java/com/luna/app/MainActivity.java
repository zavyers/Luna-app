package com.luna.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.SharedPreferences;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.InputType;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int MIC_REQUEST = 7;
    private static final int FILE_REQUEST = 8;
    private static final int BG_REQUEST = 9;
    static volatile boolean visible = false;
    private static volatile MainActivity current;

    private WebView web;
    private SpeechRecognizer recognizer;
    private String listenLang = "en-US";
    private boolean pendingListen = false;
    private boolean started = false;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Locale ttsLocale = null;
    private final ArrayList<String[]> ttsBacklog = new ArrayList<>();
    private int utteranceCount = 0;
    private ValueCallback<Uri[]> fileCallback;
    private final Ear ear = new Ear();
    private Duck duck;
    private boolean usingEar = false;
    private boolean heardSpeech = false;

    // the lock on Luna's screen
    private static final long RELOCK_AFTER_MS = 30000; // away from Luna longer than this: ask again
    private FrameLayout rootView;
    private LinearLayout lockView;
    private EditText lockInput;
    private TextView lockTitle, lockHint, lockError;
    private Button lockBio;
    private boolean locked = false;
    private boolean coverOnly = false; // just hiding the screen while Luna is in the background (nothing was asked yet)
    private boolean biometricBusy = false;
    private boolean pendingWelcome = false;
    private long leftAt = 0;
    private android.os.CancellationSignal bioCancel;

    private boolean micMuted() {
        return getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        duck = new Duck(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050b14"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            // Lets the paperclip button open the phone's photo picker.
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Choose photos"), FILE_REQUEST);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "LunaNative");
        rootView = new FrameLayout(this);
        rootView.setBackgroundColor(Color.parseColor("#050b14"));
        rootView.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        buildLockView();
        rootView.addView(lockView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(rootView);
        if (AppLock.enabled(this)) showLock(false); // locked from the very first moment
        startSpeech();
        startLuna();
        PhoneActions.warmUp(this);
        Reminders.channel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, BG_REQUEST);
        }
        if (getSharedPreferences("luna", MODE_PRIVATE).getBoolean("background", false)) startBackground();
    }

    /** What the Luna screen can ask the phone to do. */
    public class Bridge {
        @JavascriptInterface
        public void startListening(final String lang) {
            runOnUiThread(() -> beginListening(lang));
        }

        @JavascriptInterface
        public String phoneAction(final String json) {
            try {
                return PhoneActions.run(MainActivity.this, new JSONObject(json));
            } catch (Exception e) {
                return "error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void scheduleReminders(final String json) {
            Reminders.schedule(MainActivity.this, json);
        }

        @JavascriptInterface
        public void setBackground(final boolean on) {
            runOnUiThread(() -> {
                getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("background", on).apply();
                if (on) startBackground(); else stopService(new Intent(MainActivity.this, ListenService.class));
            });
        }

        @JavascriptInterface
        public void setMuted(final boolean muted) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("muted", muted).apply();
            if (muted) runOnUiThread(() -> { // really off, right now
                if (recognizer != null) recognizer.cancel();
                ear.stop();
            });
            ListenService.refresh();
        }

        @JavascriptInterface
        public boolean isMuted() {
            return getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false);
        }

        @JavascriptInterface
        public void setVoiceKind(final String kind) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putString("voice_kind", "male".equals(kind) || "female2".equals(kind) ? kind : "female").apply();
            runOnUiThread(() -> ttsLocale = null); // pick the voice again on the next sentence
        }

        @JavascriptInterface
        public void setListenDuringMedia(final boolean on) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("listen_during_media", on).apply();
        }

        @JavascriptInterface
        public void requestCallPermissions() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26) {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS,
                            Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 77);
                } else {
                    requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, 77);
                }
            });
        }

        @JavascriptInterface
        public void openNotificationAccess() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        }

        @JavascriptInterface
        public void setName(final String name) {
            final String clean = name == null ? "" : name.trim();
            if (clean.isEmpty()) return;
            SharedPreferences sp = getSharedPreferences("luna", MODE_PRIVATE);
            String old = sp.getString("name", "");
            sp.edit().putString("name", clean).apply();
            // a real rename (not the first time the name is learned): the home-screen icon gets the new name too
            if (!old.isEmpty() && !old.equals(clean)) runOnUiThread(() -> homeShortcut(clean, true));
        }

        @JavascriptInterface
        public void setTitle(final String title) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putString("title", title == null ? "" : title.trim()).apply();
        }

        /** The screen asks once it has started: true when a welcome was waiting for it. */
        @JavascriptInterface
        public boolean takeWelcome() {
            boolean was = pendingWelcome;
            pendingWelcome = false;
            return was;
        }

        @JavascriptInterface
        public String lockStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("enabled", AppLock.enabled(MainActivity.this));
                o.put("kind", AppLock.kind(MainActivity.this));
                o.put("biometric", AppLock.biometricWanted(MainActivity.this));
                o.put("biometricAvailable", biometricAvailable());
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        private String wrongCurrent() {
            long wait = AppLock.waitMs(MainActivity.this);
            if (wait > 0) return "error: too many wrong tries, wait " + ((wait + 999) / 1000) + " seconds";
            return "error: your current " + AppLock.kind(MainActivity.this) + " is not right";
        }

        /** Turns the lock on, or changes it. When a lock already exists, the current PIN or password must be right. */
        @JavascriptInterface
        public String setLock(String current, String kind, String secret, boolean biometric) {
            if (AppLock.enabled(MainActivity.this) && !AppLock.check(MainActivity.this, current)) return wrongCurrent();
            String why = AppLock.set(MainActivity.this, kind, secret, biometric && biometricAvailable());
            return why.isEmpty() ? "ok" : "error: " + why;
        }

        @JavascriptInterface
        public String disableLock(String current) {
            if (AppLock.enabled(MainActivity.this) && !AppLock.check(MainActivity.this, current)) return wrongCurrent();
            AppLock.disable(MainActivity.this);
            return "ok";
        }

        @JavascriptInterface
        public String setLockBiometric(boolean on) {
            if (!AppLock.enabled(MainActivity.this)) return "error: turn the lock on first";
            if (on && !biometricAvailable()) return "error: this phone has no fingerprint or face unlock set up";
            AppLock.setBiometric(MainActivity.this, on);
            return "ok";
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("background", getSharedPreferences("luna", MODE_PRIVATE).getBoolean("background", false));
                o.put("accessibility", LunaAccessibilityService.instance != null);
                o.put("overlay", Settings.canDrawOverlays(MainActivity.this));
                o.put("notificationAccess", NotificationStore.enabled(MainActivity.this));
                o.put("answering", Build.VERSION.SDK_INT >= 26 && checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED);
                o.put("contacts", Calls.canRead(MainActivity.this));
                o.put("calling", Calls.canCall(MainActivity.this));
                o.put("listenDuringMedia", getSharedPreferences("luna", MODE_PRIVATE).getBoolean("listen_during_media", false));
                o.put("muted", getSharedPreferences("luna", MODE_PRIVATE).getBoolean("muted", false));
                o.put("quietListening", Ear.supported());
                o.put("screenPicture", Build.VERSION.SDK_INT >= 30);
                o.put("notifications", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void openAccessibility() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }

        @JavascriptInterface
        public void openOverlay() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.stopListening();
                ear.stop();
            });
        }

        @JavascriptInterface
        public void cancelListening() {
            runOnUiThread(() -> {
                if (recognizer != null) recognizer.cancel();
                ear.stop();
            });
        }

        @JavascriptInterface
        public void speak(final String text, final String lang, final float pitch, final float rate) {
            runOnUiThread(() -> speakNow(text, lang, pitch, rate));
        }

        @JavascriptInterface
        public void stopSpeaking() {
            runOnUiThread(() -> {
                ttsBacklog.clear();
                if (tts != null) tts.stop();
                duck.up();
            });
        }

        @JavascriptInterface
        public void saveFile(final String name, final String mime, final String base64) {
            runOnUiThread(() -> saveToDownloads(name, mime, base64));
        }

        @JavascriptInterface
        public void pinShortcut(final String name) {
            runOnUiThread(() -> homeShortcut(name == null || name.trim().isEmpty() ? assistantName() : name.trim(), true));
        }
    }

    private void js(String call) {
        runOnUiThread(() -> web.evaluateJavascript(call, null));
    }

    // ------------------------------------------------------------------ listening

    private void heard(String text, boolean done) {
        js("window.__lunaHeard && window.__lunaHeard(" + JSONObject.quote(text) + "," + done + ")");
    }

    private void voiceEnd() {
        js("window.__lunaVoiceEnd && window.__lunaVoiceEnd()");
    }

    private void voiceError(String message, boolean fatal) {
        js("window.__lunaVoiceError && window.__lunaVoiceError(" + JSONObject.quote(message) + "," + fatal + ")");
    }

    /** A call is ringing and the background service is listening for "accept" or "decline": Luna's own screen steps aside. */
    static void pauseWebListening() {
        final MainActivity a = current;
        if (a == null) return;
        a.runOnUiThread(() -> {
            if (a.recognizer != null) a.recognizer.cancel();
            a.ear.stop();
            a.voiceEnd();
        });
    }

    private void beginListening(String lang) {
        if (locked) { // the lock screen is showing: the microphone stays shut
            js("window.__lunaVoiceEnd && window.__lunaVoiceEnd()");
            return;
        }
        if (ListenService.callWindow() && ListenService.instance != null) {
            // a call is waiting for a spoken answer: don't fight the background microphone, look again in a moment
            js("setTimeout(function(){window.__lunaVoiceEnd && window.__lunaVoiceEnd()},1500)");
            return;
        }
        if (micMuted()) { // the mute button at the top means the microphone is really off
            js("window.__lunaForceMute && window.__lunaForceMute()");
            return;
        }
        if (lang != null && !lang.isEmpty()) {
            listenLang = lang;
            getSharedPreferences("luna", MODE_PRIVATE).edit().putString("lang", lang).apply();
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListen = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            voiceError("This phone has no speech recognition. Install or enable the Google app.", true);
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { heardSpeech = true; if (usingEar) Ear.worked(); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onPartialResults(Bundle partialResults) {
                    if (micMuted()) return;
                    ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), false);
                }

                @Override
                public void onResults(Bundle results) {
                    ear.stop();
                    if (micMuted()) { voiceEnd(); return; } // muted while I was listening: throw it away
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) heard(list.get(0), true);
                    voiceEnd(); // the page starts the next listening round by itself
                }

                @Override
                public void onError(int error) {
                    ear.stop();
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_TOO_MANY_REQUESTS) {
                        final SpeechRecognizer stuck = recognizer; // a wedged recogniser never recovers by itself: the next round makes a new one
                        recognizer = null;
                        if (stuck != null) web.post(stuck::destroy);
                    }
                    if (usingEar && !heardSpeech && (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_AUDIO
                            || error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
                        Ear.refused();
                    }
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        voiceError("Allow the microphone for this app in the phone's settings.", true);
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        voiceError("Voice needs the internet. Check your connection.", false);
                    } else if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                            || error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        voiceEnd(); // silence is normal while waiting for the wake word
                    } else {
                        voiceError("Voice input stopped (code " + error + ").", false);
                    }
                }
            });
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, listenLang);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, listenLang);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        usingEar = ear.attach(this, intent);
        heardSpeech = false;
        recognizer.startListening(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BG_REQUEST) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    && getSharedPreferences("luna", MODE_PRIVATE).getBoolean("background", false)) {
                startBackground();
            }
            return;
        }
        if (requestCode != MIC_REQUEST) return;
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (ok && pendingListen) {
            pendingListen = false;
            beginListening(listenLang);
        } else {
            pendingListen = false;
            voiceError("Luna needs the microphone permission to hear you. Tap the mic at the top and allow it.", true);
        }
    }

    // --------------------------------------------------------------------- voice

    /** The phone's own text-to-speech, with a female voice chosen when one exists. */
    private void startSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setAudioAttributes(Duck.voiceAttributes()); // quiet other apps while I talk, don't stop them
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { duck.up(); js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
                @Override public void onError(String utteranceId) { duck.up(); js("window.__lunaSpeechDone && window.__lunaSpeechDone()"); }
            });
            ttsReady = true;
            for (String[] item : ttsBacklog) {
                speakNow(item[0], item[1], Float.parseFloat(item[2]), Float.parseFloat(item[3]));
            }
            ttsBacklog.clear();
        });
    }

    private void useLanguage(String tag) {
        Locale want = (tag == null || tag.isEmpty()) ? Locale.getDefault() : Locale.forLanguageTag(tag);
        if (want.equals(ttsLocale)) return;
        int r = tts.setLanguage(want);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (ttsLocale == null) tts.setLanguage(Locale.US);
            return;
        }
        ttsLocale = want;
        Voices.choose(tts, want, Voices.kind(this));
    }

    private void speakNow(String text, String lang, float pitch, float rate) {
        if (!ttsReady || tts == null) {
            ttsBacklog.add(new String[]{text, lang, String.valueOf(pitch), String.valueOf(rate)});
            return;
        }
        duck.down();
        useLanguage(lang);
        tts.setPitch(Voices.pitch(this, pitch));
        tts.setSpeechRate(rate);
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "luna" + (utteranceCount++));
    }

    // ------------------------------------------------------- files and the home screen

    private void saveToDownloads(String name, String mime, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("no uri");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    out.write(data);
                }
                Toast.makeText(this, "Saved " + safe + " in your Downloads folder", Toast.LENGTH_LONG).show();
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(dir, safe);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(data);
                }
                Toast.makeText(this, "Saved to " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Could not save the file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Android can't rename an installed app, so the home-screen icon is a shortcut with its own name.
     * If that shortcut is already on the home screen its name is changed silently; otherwise (when ask is true)
     * the phone is asked to add it, which needs one tap on "Add".
     */
    private void homeShortcut(String name, boolean ask) {
        try {
            if (Build.VERSION.SDK_INT < 26) {
                if (ask) Toast.makeText(this, "This Android version can't add shortcuts from inside the app.", Toast.LENGTH_LONG).show();
                return;
            }
            ShortcutManager sm = getSystemService(ShortcutManager.class);
            if (sm == null) return;
            Intent open = new Intent(Intent.ACTION_MAIN).setClass(this, MainActivity.class);
            ShortcutInfo info = new ShortcutInfo.Builder(this, "luna-home")
                    .setShortLabel(name)
                    .setLongLabel(name)
                    .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                    .setIntent(open)
                    .build();
            boolean onScreen = false;
            for (ShortcutInfo have : sm.getPinnedShortcuts()) {
                if ("luna-home".equals(have.getId())) onScreen = true;
            }
            if (onScreen) {
                ArrayList<ShortcutInfo> list = new ArrayList<>();
                list.add(info);
                sm.updateShortcuts(list);
                Toast.makeText(this, "Home screen icon renamed to " + name, Toast.LENGTH_SHORT).show();
            } else if (ask) {
                if (!sm.isRequestPinShortcutSupported()) {
                    Toast.makeText(this, "Your launcher can't add shortcuts from inside the app.", Toast.LENGTH_LONG).show();
                    return;
                }
                sm.requestPinShortcut(info, null);
                Toast.makeText(this, "Tap Add to put \"" + name + "\" on your home screen. You can then remove the old icon.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            if (ask) Toast.makeText(this, "Could not change the home screen icon: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------------ the lock screen

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String assistantName() {
        String n = getSharedPreferences("luna", MODE_PRIVATE).getString("name", "Luna");
        return n == null || n.isEmpty() ? "Luna" : n;
    }

    private void buildLockView() {
        lockView = new LinearLayout(this);
        lockView.setOrientation(LinearLayout.VERTICAL);
        lockView.setGravity(Gravity.CENTER);
        lockView.setBackgroundColor(Color.parseColor("#050b14"));
        lockView.setPadding(dp(28), dp(28), dp(28), dp(28));
        lockView.setClickable(true); // swallows every touch, so nothing underneath can be tapped
        lockView.setFocusable(true);
        lockView.setVisibility(View.GONE);

        lockTitle = new TextView(this);
        lockTitle.setTextColor(Color.parseColor("#7fe9ff"));
        lockTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        lockTitle.setGravity(Gravity.CENTER);
        lockView.addView(lockTitle, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        lockHint = new TextView(this);
        lockHint.setTextColor(Color.parseColor("#9db4c8"));
        lockHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        lockHint.setGravity(Gravity.CENTER);
        lockHint.setPadding(0, dp(8), 0, dp(20));
        lockView.addView(lockHint, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        lockInput = new EditText(this);
        lockInput.setTextColor(Color.WHITE);
        lockInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        lockInput.setGravity(Gravity.CENTER);
        lockInput.setSingleLine(true);
        lockInput.setBackgroundColor(Color.parseColor("#0b1a2b"));
        lockInput.setPadding(dp(16), dp(14), dp(16), dp(14));
        lockInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        lockInput.setOnEditorActionListener((v, actionId, event) -> {
            tryUnlock();
            return true;
        });
        lockView.addView(lockInput, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        lockError = new TextView(this);
        lockError.setTextColor(Color.parseColor("#ff7a7a"));
        lockError.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        lockError.setGravity(Gravity.CENTER);
        lockError.setPadding(0, dp(10), 0, dp(10));
        lockView.addView(lockError, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button unlock = new Button(this);
        unlock.setText("UNLOCK");
        unlock.setOnClickListener(v -> tryUnlock());
        lockView.addView(unlock, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        lockBio = new Button(this);
        lockBio.setText("USE FINGERPRINT OR FACE");
        lockBio.setOnClickListener(v -> promptBiometric());
        lockView.addView(lockBio, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
    }

    private void showLock(boolean cover) {
        locked = true;
        coverOnly = cover;
        boolean pin = !"password".equals(AppLock.kind(this));
        lockTitle.setText(assistantName() + " is locked");
        lockHint.setText(pin ? "Enter your PIN" : "Enter your password");
        if (pin) {
            lockInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        } else { // no suggestions and no auto-capital, so the keyboard doesn't change what is typed
            lockInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        }
        lockInput.setText("");
        lockError.setText("");
        lockBio.setVisibility(AppLock.biometricWanted(this) && biometricAvailable() ? View.VISIBLE : View.GONE);
        lockView.setVisibility(View.VISIBLE);
        web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
    }

    private void tryUnlock() {
        if (!locked) return;
        boolean pin = !"password".equals(AppLock.kind(this));
        String what = pin ? "PIN" : "password";
        long wait = AppLock.waitMs(this);
        if (wait > 0) {
            lockError.setText("Too many wrong tries. Wait " + ((wait + 999) / 1000) + " seconds.");
            return;
        }
        String typed = lockInput.getText().toString();
        if (typed.trim().isEmpty()) return;
        if (AppLock.check(this, typed)) {
            unlock(true);
            return;
        }
        lockInput.setText("");
        long again = AppLock.waitMs(this);
        if (again > 0) {
            lockError.setText("Wrong " + what + ". Wait " + ((again + 999) / 1000) + " seconds before trying again.");
        } else {
            lockError.setText("Wrong " + what + ". Try again (" + AppLock.triesLeft(this) + " tries before a short wait).");
        }
    }

    private void unlock(boolean welcome) {
        locked = false;
        coverOnly = false;
        if (biometricBusy && bioCancel != null) {
            try { bioCancel.cancel(); } catch (Exception ignored) { /* already closed */ }
        }
        bioCancel = null;
        biometricBusy = false;
        lockView.setVisibility(View.GONE);
        lockInput.setText("");
        web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_AUTO);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(lockInput.getWindowToken(), 0);
        web.requestFocus();
        if (welcome) welcome();
    }

    /** Said every time the right PIN, password, fingerprint or face is given. */
    private void welcome() {
        String title = getSharedPreferences("luna", MODE_PRIVATE).getString("title", "");
        final String words = title == null || title.isEmpty() ? "Welcome back." : "Welcome back, " + title + ".";
        Toast.makeText(this, words, Toast.LENGTH_SHORT).show();
        web.evaluateJavascript("(window.__lunaWelcome ? (window.__lunaWelcome(" + JSONObject.quote(words) + "), '1') : '0')", value -> {
            if (!"\"1\"".equals(value)) pendingWelcome = true; // the screen is still starting: it asks for the welcome when it is ready
        });
    }

    private boolean biometricAvailable() {
        if (Build.VERSION.SDK_INT < 28) return false;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                android.hardware.biometrics.BiometricManager bm = getSystemService(android.hardware.biometrics.BiometricManager.class);
                if (bm == null) return false;
                int r = Build.VERSION.SDK_INT >= 30
                        ? bm.canAuthenticate(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK)
                        : bm.canAuthenticate();
                return r == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS;
            }
            return getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT); // Android 9: fingerprint only
        } catch (Throwable t) {
            return false;
        }
    }

    /** The phone's own fingerprint / face sheet. The PIN or password box stays available underneath. */
    private void promptBiometric() {
        if (!locked || biometricBusy || !AppLock.biometricWanted(this) || !biometricAvailable()) return;
        try {
            biometricBusy = true;
            final android.os.CancellationSignal cancel = new android.os.CancellationSignal();
            bioCancel = cancel;
            final boolean pin = !"password".equals(AppLock.kind(this));
            android.hardware.biometrics.BiometricPrompt.Builder b = new android.hardware.biometrics.BiometricPrompt.Builder(this)
                    .setTitle("Unlock " + assistantName())
                    .setSubtitle("Use your fingerprint or face")
                    .setNegativeButton("Use " + (pin ? "PIN" : "password"), getMainExecutor(), (d, which) -> biometricBusy = false);
            if (Build.VERSION.SDK_INT >= 30) {
                b.setAllowedAuthenticators(android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_WEAK);
            }
            b.build().authenticate(cancel, getMainExecutor(), new android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(android.hardware.biometrics.BiometricPrompt.AuthenticationResult result) {
                    biometricBusy = false;
                    if (locked) unlock(true);
                }

                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    biometricBusy = false;
                    bioCancel = null;
                }
            });
        } catch (Throwable t) {
            biometricBusy = false;
            bioCancel = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_REQUEST || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clip = data.getClipData();
            if (clip != null) {
                result = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    // ------------------------------------------------------- listening in the background

    private void startBackground() {
        ArrayList<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), BG_REQUEST);
            return;
        }
        Intent service = new Intent(this, ListenService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (locked) {
            if (coverOnly) { // only hidden while away: back soon enough means no questions, otherwise the lock asks
                if (SystemClock.elapsedRealtime() - leftAt < RELOCK_AFTER_MS) {
                    unlock(false);
                } else {
                    showLock(false);
                    promptBiometric();
                }
            } else {
                promptBiometric();
            }
        }
        current = this;
        visible = true;
        ListenService.activityVisible = true;
        ListenService.refresh();
        // the page can't always tell it came back to the front: tell it, so what was said outside shows at once
        js("window.__lunaResume && window.__lunaResume(" + micMuted() + ")");
    }

    @Override
    protected void onPause() {
        if (AppLock.enabled(this) && !locked) { // hide the screen now, so the Recent apps picture shows the lock and not the chats
            leftAt = SystemClock.elapsedRealtime();
            showLock(true);
        }
        visible = false;
        ListenService.activityVisible = false;
        ListenService.refresh();
        super.onPause();
    }

    // ------------------------------------------------------------------ the engine

    private void startLuna() {
        if (started) return;
        started = true;
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                PyObject mod = Python.getInstance().getModule("luna_android");
                final String url = mod.callAttr("start", getFilesDir().getAbsolutePath() + "/luna").toString();
                runOnUiThread(() -> web.loadUrl(url));
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Luna failed to start: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        ear.stop();
        duck.up();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
