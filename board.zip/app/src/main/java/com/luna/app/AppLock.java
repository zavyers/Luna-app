package com.luna.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * The lock on Luna's screen: a PIN or a password, and optionally fingerprint or face.
 * Only a salted hash is stored (never the PIN or password itself). The match is exact on purpose:
 * a lock that forgave typos would be easier to guess. A few wrong tries in a row make Luna wait before the next one.
 */
final class AppLock {
    private AppLock() { }

    private static final String FILE = "luna_lock";
    private static final int ROUNDS = 100000;
    static final int FREE_TRIES = 5;

    private static SharedPreferences p(Context ctx) {
        return ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context ctx) {
        SharedPreferences sp = p(ctx);
        return sp.getBoolean("enabled", false) && sp.getString("hash", null) != null;
    }

    /** "pin" (digits only) or "password". */
    static String kind(Context ctx) {
        return "password".equals(p(ctx).getString("kind", "pin")) ? "password" : "pin";
    }

    static boolean biometricWanted(Context ctx) {
        return enabled(ctx) && p(ctx).getBoolean("bio", false);
    }

    static void setBiometric(Context ctx, boolean on) {
        p(ctx).edit().putBoolean("bio", on).apply();
    }

    private static String clean(String secret) {
        return secret == null ? "" : secret.trim(); // a stray space from the keyboard is forgiven, nothing else is
    }

    /** "" when the secret is acceptable, otherwise what is wrong with it. */
    static String problem(String kind, String secret) {
        String s = clean(secret);
        if ("pin".equals(kind)) {
            if (!s.matches("[0-9]{4,8}")) return "A PIN is 4 to 8 digits.";
        } else if (s.length() < 4 || s.length() > 40) {
            return "A password is 4 to 40 characters.";
        }
        return "";
    }

    private static byte[] hash(String algorithm, String secret, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(secret.toCharArray(), salt, ROUNDS, 256);
        try {
            return SecretKeyFactory.getInstance(algorithm).generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
    }

    /** Saves a new PIN or password (replacing the old one). Returns "" when done, otherwise the problem. */
    static String set(Context ctx, String kind, String secret, boolean biometric) {
        String why = problem(kind, secret);
        if (!why.isEmpty()) return why;
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            String alg = "PBKDF2WithHmacSHA256";
            byte[] h;
            try {
                h = hash(alg, clean(secret), salt);
            } catch (Exception old) { // Android 7 has no SHA-256 version
                alg = "PBKDF2WithHmacSHA1";
                h = hash(alg, clean(secret), salt);
            }
            p(ctx).edit()
                    .putBoolean("enabled", true)
                    .putString("kind", "password".equals(kind) ? "password" : "pin")
                    .putString("alg", alg)
                    .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("hash", Base64.encodeToString(h, Base64.NO_WRAP))
                    .putBoolean("bio", biometric)
                    .putInt("fails", 0)
                    .putLong("until", 0)
                    .apply();
            return "";
        } catch (Exception e) {
            return "Could not save the lock: " + e.getMessage();
        }
    }

    static void disable(Context ctx) {
        p(ctx).edit().clear().apply();
    }

    /** Milliseconds Luna still refuses tries after too many wrong ones (0 = go ahead). */
    static long waitMs(Context ctx) {
        long left = p(ctx).getLong("until", 0) - System.currentTimeMillis();
        return left > 0 ? left : 0;
    }

    /** True when the secret is right. Wrong tries are counted; after a few, Luna makes the person wait (30 s, then longer, up to 15 min). */
    static boolean check(Context ctx, String secret) {
        if (!enabled(ctx) || waitMs(ctx) > 0) return false;
        SharedPreferences sp = p(ctx);
        boolean ok = false;
        try {
            byte[] salt = Base64.decode(sp.getString("salt", ""), Base64.NO_WRAP);
            byte[] want = Base64.decode(sp.getString("hash", ""), Base64.NO_WRAP);
            byte[] got = hash(sp.getString("alg", "PBKDF2WithHmacSHA256"), clean(secret), salt);
            ok = MessageDigest.isEqual(want, got);
        } catch (Exception ignored) {
            ok = false;
        }
        SharedPreferences.Editor e = sp.edit();
        if (ok) {
            e.putInt("fails", 0).putLong("until", 0);
        } else {
            int fails = sp.getInt("fails", 0) + 1;
            e.putInt("fails", fails);
            if (fails >= FREE_TRIES) {
                long wait = Math.min(15L * 60_000L, 30_000L << Math.min(fails - FREE_TRIES, 5));
                e.putLong("until", System.currentTimeMillis() + wait);
            }
        }
        e.apply();
        return ok;
    }

    static int triesLeft(Context ctx) {
        return Math.max(0, FREE_TRIES - p(ctx).getInt("fails", 0));
    }
}
