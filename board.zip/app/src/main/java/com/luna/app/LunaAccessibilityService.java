package com.luna.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.util.Base64;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/** Lets Luna press Home/Back, read the screen and tap buttons in other apps. Off until the person switches it on in Settings. */
public class LunaAccessibilityService extends AccessibilityService {
    static volatile LunaAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    static String global(String what) {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control in Settings, then Accessibility first";
        int action;
        switch (what) {
            case "go_home": action = GLOBAL_ACTION_HOME; break;
            case "go_back": action = GLOBAL_ACTION_BACK; break;
            case "recents": action = GLOBAL_ACTION_RECENTS; break;
            case "notifications": action = GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quick_settings": action = GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "a_lock_screen": action = GLOBAL_ACTION_LOCK_SCREEN; break;
            case "screenshot": action = GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            default: return "error: unknown action";
        }
        return s.performGlobalAction(action) ? "ok" : "error: the phone refused";
    }

    public static String readScreen() {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control first";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "error: I can't see the screen right now";
        StringBuilder out = new StringBuilder();
        collect(root, out, 0);
        String text = out.toString().trim();
        return text.isEmpty() ? "ok: nothing readable is on the screen" : "ok: " + text;
    }

    private static void collect(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || out.length() > 3000 || depth > 40) return;
        if (!node.isVisibleToUser()) return; // off-screen reels, hidden tabs
        CharSequence t = node.getText();
        if (t == null || t.length() == 0) t = node.getContentDescription();
        if (t != null && t.length() > 0) out.append(t).append(". ");
        for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out, depth + 1);
    }

    /**
     * A picture of what is on the screen right now (a reel, a product, a page), as a small JPEG in base64:
     * "ok:" + data, or "error: ...". Needs Android 11+ and Luna phone control. Text alone can't tell a
     * watch in a video from the caption under it, so this is what lets Luna see what you are looking at.
     */
    public static String screenshotBase64() {
        final LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control first";
        if (Build.VERSION.SDK_INT < 30) return "error: this Android version can't let me see the screen picture";
        final CountDownLatch done = new CountDownLatch(1);
        final AtomicReference<String> result = new AtomicReference<>("error: I couldn't take a picture of the screen");
        final ExecutorService pool = Executors.newSingleThreadExecutor();
        try {
            s.takeScreenshot(Display.DEFAULT_DISPLAY, pool, new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult shot) {
                    try {
                        HardwareBuffer hb = shot.getHardwareBuffer();
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, shot.getColorSpace());
                        Bitmap soft = hw == null ? null : hw.copy(Bitmap.Config.ARGB_8888, false);
                        hb.close();
                        if (soft != null) {
                            int max = 900;
                            float k = Math.min(1f, (float) max / Math.max(soft.getWidth(), soft.getHeight()));
                            Bitmap small = k < 1f ? Bitmap.createScaledBitmap(soft, Math.round(soft.getWidth() * k), Math.round(soft.getHeight() * k), true) : soft;
                            ByteArrayOutputStream bos = new ByteArrayOutputStream();
                            small.compress(Bitmap.CompressFormat.JPEG, 72, bos);
                            result.set("ok:" + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP));
                        }
                    } catch (Throwable e) {
                        result.set("error: the screen picture failed");
                    } finally {
                        done.countDown();
                    }
                }

                @Override
                public void onFailure(int errorCode) {
                    result.set(errorCode == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT ? "error: too quick, ask me again in a second"
                            : "error: the phone wouldn't let me see the screen (the app may block pictures of itself)");
                    done.countDown();
                }
            });
            done.await(4, TimeUnit.SECONDS);
        } catch (Throwable e) {
            return "error: " + e.getClass().getSimpleName();
        } finally {
            pool.shutdown();
        }
        return result.get();
    }

    /** Taps a button by its spoken label (content description or text), e.g. WhatsApp's "Voice call". */
    static String tapLabel(String... labels) {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control first";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "error: I can't see the screen right now";
        for (String label : labels) {
            List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(label);
            if (found == null) continue;
            for (AccessibilityNodeInfo n : found) {
                AccessibilityNodeInfo cur = n;
                while (cur != null) {
                    if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok: tapped " + label;
                    cur = cur.getParent();
                }
            }
        }
        return "error: I can't see that button";
    }

    static String tapText(String text) {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control first";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "error: I can't see the screen right now";
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(text);
        if (found == null || found.isEmpty()) return "error: I can't see “" + text + "” on the screen";
        for (AccessibilityNodeInfo n : found) {
            AccessibilityNodeInfo cur = n;
            while (cur != null) {
                if (cur.isClickable()) {
                    return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK) ? "ok: tapped " + text : "error: the tap did not work";
                }
                cur = cur.getParent();
            }
        }
        return "error: “" + text + "” is on the screen but can't be tapped";
    }
}
