package com.luna.app;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

/** "Install Spotify": opens the Play Store search, opens the first result, presses Install. Needs Luna phone control. */
final class PlayInstall {
    private PlayInstall() { }

    static String run(final Context ctx, final String app) {
        String have = PhoneActions.packageFor(ctx, app);
        if (have != null) return PhoneActions.launchPackage(ctx, have, app + " is already installed, so I opened it");
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(app) + "&c=apps")).setPackage("com.android.vending");
        try {
            PhoneActions.open(ctx, i, "");
        } catch (Exception e) {
            return "error: the Play Store isn't available on this phone";
        }
        if (LunaAccessibilityService.instance == null) return "ok: the Play Store is open, tap Install. Turn on Luna phone control and I'll press it for you";
        final Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(new Runnable() {
            int tick = 0;
            boolean opened = false;

            @Override public void run() {
                tick++;
                String r = opened ? LunaAccessibilityService.tapLabel("Install", "Get") : LunaAccessibilityService.tapPerson(app);
                if (r.startsWith("ok")) {
                    if (opened) { Calls.tell(ctx, "Installing " + app + " now."); return; }
                    opened = true;
                    tick = 0;
                    h.postDelayed(this, 2500);
                } else if (tick < 8) {
                    h.postDelayed(this, 1200);
                } else {
                    Calls.tell(ctx, "I opened the Play Store for " + app + " but couldn't press Install. Please tap it yourself.");
                }
            }
        }, 3000);
        return "ok: looking for " + app + " on the Play Store";
    }
}
