package com.luna.app;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import java.util.function.Consumer;

/**
 * Luna updating herself. The update source (Settings) is either a GitHub "owner/repo" whose latest release has an .apk file,
 * or a direct link to an .apk. A newer file is downloaded and the phone's installer opens; because every build is signed with
 * the same key, it installs over the old Luna and keeps everything.
 */
final class Updater {
    private Updater() { }

    static void start(final Context ctx, final Consumer<String> say) {
        final String source = ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).getString("update_source", "");
        if (source.isEmpty()) {
            tell(ctx, say, "I don't know where to find updates. Open my settings, enter your update source under Update Luna, and ask again.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 26 && !ctx.getPackageManager().canRequestPackageInstalls()) {
            tell(ctx, say, "Please allow me to install updates, then ask again.");
            ctx.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }
        tell(ctx, say, "Checking for a newer version.");
        new Thread(() -> {
            try {
                String apk = source;
                if (!source.startsWith("http")) {
                    JSONObject release = new JSONObject(get("https://api.github.com/repos/" + source + "/releases/latest"));
                    apk = null;
                    JSONArray assets = release.getJSONArray("assets");
                    for (int i = 0; i < assets.length() && apk == null; i++) {
                        JSONObject a = assets.getJSONObject(i);
                        if (a.getString("name").endsWith(".apk")) {
                            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                            f.setTimeZone(TimeZone.getTimeZone("UTC"));
                            long published = f.parse(a.getString("updated_at")).getTime();
                            long installed = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).lastUpdateTime;
                            if (published <= installed + 60000) {
                                tell(ctx, say, "You already have the newest version.");
                                return;
                            }
                            apk = a.getString("browser_download_url");
                        }
                    }
                    if (apk == null) {
                        tell(ctx, say, "I found the release, but it has no app file in it.");
                        return;
                    }
                }
                download(ctx, apk, say);
            } catch (Exception e) {
                tell(ctx, say, "I couldn't check for updates. Make sure the source is right, public, and that you are online.");
            }
        }).start();
    }

    private static void tell(Context ctx, Consumer<String> say, String message) {
        say.accept(message);
        Calls.tell(ctx, message);
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestProperty("User-Agent", "Luna");
        c.setRequestProperty("Accept", "application/vnd.github+json");
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder sb = new StringBuilder();
            for (String line; (line = r.readLine()) != null; ) sb.append(line);
            return sb.toString();
        }
    }

    private static void download(final Context ctx, String apk, final Consumer<String> say) {
        final DownloadManager dm = (DownloadManager) ctx.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apk))
                .setTitle("Luna update")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(ctx, null, "luna-update.apk");
        final long id = dm.enqueue(req);
        tell(ctx, say, "A newer version is downloading. I'll open the installer when it is ready.");
        BroadcastReceiver done = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent intent) {
                if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return;
                try { ctx.getApplicationContext().unregisterReceiver(this); } catch (Exception ignored) { /* already gone */ }
                Uri file = dm.getUriForDownloadedFile(id);
                if (file == null) {
                    tell(ctx, say, "The download didn't finish. Please try again.");
                    return;
                }
                ctx.startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(file, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        };
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) ctx.getApplicationContext().registerReceiver(done, filter, Context.RECEIVER_EXPORTED);
        else ctx.getApplicationContext().registerReceiver(done, filter);
    }
}
