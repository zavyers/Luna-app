package com.luna.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.view.KeyEvent;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

/** Everything Luna can do on the phone. Each call returns "ok..." or "error: ...". */
public final class PhoneActions {
    private PhoneActions() { }

    static String run(Context ctx, JSONObject a) {
        String name = a.optString("action");
        try {
            switch (name) {
                case "a_open_app": return openApp(ctx, a.optString("name"));
                case "a_open_url": return open(ctx, new Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))), "opened the page");
                case "a_search_web":
                    return open(ctx, new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))), "searched the web");
                case "call":
                    return open(ctx, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.getString("number")))), "the dialer is open, press call");
                case "sms": {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.getString("number"))));
                    i.putExtra("sms_body", a.optString("text"));
                    return open(ctx, i, "the message is ready, press send");
                }
                case "alarm": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                    i.putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"));
                    i.putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute"));
                    i.putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Luna"));
                    i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    return open(ctx, i, String.format(Locale.US, "alarm set for %02d:%02d", a.getInt("hour"), a.getInt("minute")));
                }
                case "timer": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
                    i.putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"));
                    i.putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Luna"));
                    i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    return open(ctx, i, "timer started");
                }
                case "open_settings": return open(ctx, new Intent(settingsAction(a.optString("page"))), "opened settings");
                case "flashlight": return torch(ctx, "on".equals(a.optString("state")));
                case "a_volume": return volume(ctx, a.optString("direction"));
                case "a_media": return media(ctx, a.optString("control"));
                case "navigate": {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(a.getString("place"))));
                    i.setPackage("com.google.android.apps.maps");
                    try {
                        return open(ctx, i, "started directions");
                    } catch (Exception e) {
                        return open(ctx, new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.getString("place")))), "opened the map");
                    }
                }
                case "go_home":
                case "go_back":
                case "recents":
                case "notifications":
                case "quick_settings":
                case "a_lock_screen":
                case "screenshot":
                    return LunaAccessibilityService.global(name);
                case "call_contact": return Calls.callContact(ctx, a.getString("contact"));
                case "whatsapp_call": return Calls.whatsapp(ctx, a.getString("contact"), "yes".equals(a.optString("video")), false);
                case "whatsapp_chat": return Calls.whatsapp(ctx, a.getString("contact"), false, true);
                case "reply_message": return NotificationStore.reply(ctx, a.optString("to"), a.getString("text"));
                case "send_message": return Calls.sendMessage(ctx, a.getString("to"), a.getString("text"), a.optString("app", "auto"));
                case "install_app": return PlayInstall.run(ctx, a.getString("name"));
                case "answer_call": return CallWatcher.answer(ctx);
                case "decline_call": return CallWatcher.decline(ctx);
                case "tap": return LunaAccessibilityService.tapText(a.getString("text"));
                case "read_screen": return LunaAccessibilityService.readScreen();
                default: return "error: I can't do that on the phone";
            }
        } catch (Exception e) {
            return "error: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
    }

    /** Starts a screen. From the background this works once phone control or "display over other apps" is allowed. */
    static String open(Context ctx, Intent intent, String done) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Context c = LunaAccessibilityService.instance != null ? LunaAccessibilityService.instance : ctx;
        c.startActivity(intent);
        return "ok: " + done;
    }

    // The list of installed apps is read once and kept (reading every app's name on each request is what made opening slow).
    private static volatile List<String[]> appIndex; // {lowercase label, label, package}
    private static volatile long appIndexAt;
    private static final long APP_INDEX_TTL = 10 * 60 * 1000L;

    static void warmUp(final Context ctx) {
        final Context app = ctx.getApplicationContext();
        new Thread(() -> apps(app, true)).start();
    }

    private static List<String[]> apps(Context ctx, boolean force) {
        List<String[]> cur = appIndex;
        if (!force && cur != null && System.currentTimeMillis() - appIndexAt < APP_INDEX_TTL) return cur;
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<String[]> out = new java.util.ArrayList<>();
        for (ResolveInfo r : pm.queryIntentActivities(main, 0)) {
            String label = String.valueOf(r.loadLabel(pm));
            out.add(new String[]{label.toLowerCase(Locale.ROOT), label, r.activityInfo.packageName});
        }
        appIndex = out;
        appIndexAt = System.currentTimeMillis();
        return out;
    }

    /** What people really say, mapped to the name the app has on the phone. */
    private static final String[][] ALIASES = {
            {"insta", "instagram"}, {"ig", "instagram"}, {"yt", "youtube"}, {"you tube", "youtube"}, {"whats app", "whatsapp"},
            {"watsapp", "whatsapp"}, {"whatsap", "whatsapp"}, {"gpay", "google pay"}, {"g pay", "google pay"}, {"maps", "google maps"},
            {"map", "google maps"}, {"google map", "google maps"}, {"play store", "google play store"}, {"playstore", "google play store"},
            {"mail", "gmail"}, {"email", "gmail"}, {"photos", "google photos"}, {"gallery", "gallery"}, {"insta gram", "instagram"},
            {"fb", "facebook"}, {"face book", "facebook"}, {"tele gram", "telegram"}, {"snap", "snapchat"}, {"x", "x"}, {"twitter", "x"},
            {"chrome browser", "chrome"}, {"browser", "chrome"}, {"clock", "clock"}, {"phone", "phone"}, {"dialer", "phone"}, {"contacts", "contacts"},
            {"camera", "camera"}, {"settings", "settings"}, {"spotify music", "spotify"}, {"prime", "prime video"}, {"hotstar", "hotstar"}
    };

    private static String alias(String w) {
        for (String[] a : ALIASES) if (a[0].equals(w)) return a[1];
        return w;
    }

    private static String[] bestApp(Context ctx, String wanted, boolean refreshed) {
        String said = wanted.trim().toLowerCase(Locale.ROOT);
        String[] best = match(ctx, alias(said), refreshed);
        if (best == null && !alias(said).equals(said)) best = match(ctx, said, refreshed); // the alias isn't installed: try the words as said
        // an app installed a moment ago isn't in the list yet: look once more, freshly
        return best != null || refreshed ? best : bestApp(ctx, wanted, true);
    }

    private static String[] match(Context ctx, String w, boolean refreshed) {
        if (w.isEmpty()) return null;
        String[] best = null;
        int bestScore = 0;
        for (String[] app : apps(ctx, refreshed)) {
            String label = app[0];
            int score = label.equals(w) ? 3 : label.startsWith(w) ? 2 : (label.contains(w) || w.contains(label)) && label.length() > 2 ? 1 : 0;
            if (score > bestScore) {
                bestScore = score;
                best = app;
            }
        }
        if (best != null || w.length() < 5) return best;
        // a spelling slip ("instagrm", "snapchta"): the closest app name, if it is really close
        int bestDist = w.length() >= 8 ? 3 : 2;
        for (String[] app : apps(ctx, refreshed)) {
            int d = lev(app[0], w);
            for (String word : app[0].split("\\s+")) if (word.length() >= 5) d = Math.min(d, lev(word, w));
            if (d < bestDist) {
                bestDist = d;
                best = app;
            }
        }
        return best;
    }

    /** How many single-letter changes turn one word into the other. */
    static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }

    /** The package of the installed app that best matches the name, or null. */
    static String packageFor(Context ctx, String wanted) {
        String[] app = bestApp(ctx, wanted, false);
        return app == null ? null : app[2];
    }

    /** The installed app's real name that best matches what was said, or "" (used by Python before it decides what to do). */
    public static String findApp(Context ctx, String wanted) {
        String[] app = bestApp(ctx, wanted, false);
        return app == null ? "" : app[1];
    }

    static String launchPackage(Context ctx, String pkg, String name) {
        Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) return "error: " + name + " can't be opened";
        return open(ctx, launch, "opened " + name);
    }

    private static String openApp(Context ctx, String wanted) {
        String[] app = bestApp(ctx, wanted, false);
        if (app == null) return "error: I can't find an app called " + wanted;
        return launchPackage(ctx, app[2], app[1]);
    }

    private static String settingsAction(String page) {
        switch (page) {
            case "wifi": return Settings.ACTION_WIFI_SETTINGS;
            case "bluetooth": return Settings.ACTION_BLUETOOTH_SETTINGS;
            case "display": return Settings.ACTION_DISPLAY_SETTINGS;
            case "sound": return Settings.ACTION_SOUND_SETTINGS;
            case "battery": return Intent.ACTION_POWER_USAGE_SUMMARY;
            case "apps": return Settings.ACTION_APPLICATION_SETTINGS;
            case "location": return Settings.ACTION_LOCATION_SOURCE_SETTINGS;
            case "accessibility": return Settings.ACTION_ACCESSIBILITY_SETTINGS;
            case "notification_access": return Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS;
            default: return Settings.ACTION_SETTINGS;
        }
    }

    private static String torch(Context ctx, boolean on) throws Exception {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics cc = cm.getCameraCharacteristics(id);
            Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
            if (flash != null && flash && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                cm.setTorchMode(id, on);
                return "ok: flashlight " + (on ? "on" : "off");
            }
        }
        return "error: this phone has no flashlight";
    }

    private static String volume(Context ctx, String direction) {
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        int dir = "up".equals(direction) ? AudioManager.ADJUST_RAISE : "down".equals(direction) ? AudioManager.ADJUST_LOWER : AudioManager.ADJUST_TOGGLE_MUTE;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
        return "ok: volume " + direction;
    }

    private static String media(Context ctx, String control) {
        int code;
        switch (control) {
            case "next": code = KeyEvent.KEYCODE_MEDIA_NEXT; break;
            case "previous": code = KeyEvent.KEYCODE_MEDIA_PREVIOUS; break;
            case "stop": code = KeyEvent.KEYCODE_MEDIA_STOP; break;
            default: code = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
        }
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
        return "ok: " + control.replace('_', ' ');
    }
}
