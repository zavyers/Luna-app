package com.luna.app;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Picks Luna's voice. Three choices:
 *  "female"  - Voice 1: the best female voice for the language
 *  "male"    - Voice 2: a male voice (lower pitched when the phone has no male voice)
 *  "female2" - Voice 3: a different female voice (the second best one; a little softer and lower when the phone has only one)
 */
final class Voices {
    private Voices() { }

    static String kind(Context ctx) {
        String k = ctx.getSharedPreferences("luna", Context.MODE_PRIVATE).getString("voice_kind", "female");
        return "male".equals(k) || "female2".equals(k) ? k : "female";
    }

    static boolean male(Context ctx) {
        return "male".equals(kind(ctx));
    }

    /** Deeper for Voice 2 and slightly softer for Voice 3, so each always sounds different even on phones that only ship one voice. */
    static float pitch(Context ctx, float pitch) {
        String k = kind(ctx);
        if ("male".equals(k)) return pitch * 0.8f;
        if ("female2".equals(k)) return pitch * 0.92f;
        return pitch;
    }

    private static final class Scored {
        final Voice voice;
        final int score;
        final boolean femaleName;

        Scored(Voice voice, int score, boolean femaleName) {
            this.voice = voice;
            this.score = score;
            this.femaleName = femaleName;
        }
    }

    static void choose(TextToSpeech tts, Locale want, String kind) {
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            boolean male = "male".equals(kind);
            List<Scored> ranked = new ArrayList<>();
            for (Voice v : all) {
                if (!v.getLocale().getLanguage().equals(want.getLanguage())) continue;
                String name = v.getName().toLowerCase(Locale.ROOT);
                boolean female = name.contains("female");
                boolean man = !female && name.contains("male");
                int score = male ? (man ? 5 : female ? -4 : 0) : (female ? 4 : man ? -5 : 0);
                if (!v.isNetworkConnectionRequired()) score += 1;
                if (v.getLocale().equals(want)) score += 1;
                ranked.add(new Scored(v, score, female));
            }
            if (ranked.isEmpty()) return;
            Collections.sort(ranked, (a, b) -> Integer.compare(b.score, a.score));
            Scored pick = ranked.get(0);
            if ("female2".equals(kind)) {
                // the next best voice that is clearly a different female voice; otherwise keep Voice 1's engine voice (the pitch still differs)
                for (int i = 1; i < ranked.size(); i++) {
                    Scored s = ranked.get(i);
                    if (s.femaleName && !s.voice.getName().equals(pick.voice.getName())) {
                        pick = s;
                        break;
                    }
                }
            }
            tts.setVoice(pick.voice);
        } catch (Exception ignored) {
            // keep the phone's default voice
        }
    }
}
