import json, sys, tempfile, time, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "app" / "src" / "main" / "python"))

from app.agent.fast import FastIntents  # noqa: E402
from app.agent.actions import check, ActionError, label  # noqa: E402
from app.chat.store import ChatStore  # noqa: E402
from app.config import load_settings  # noqa: E402
from app.ui.server import build_app  # noqa: E402


class FakePhone:
    def __init__(self, access=True, rows=None, apps=("Chrome", "WhatsApp", "Instagram")):
        self.access, self.rows, self.apps = access, rows or [], apps
        self.opened, self.screen = [], "ok: Hello. Meeting at 5 pm. Send."

    def find_app(self, name):
        n = name.lower()
        return next((a for a in self.apps if a.lower() == n or a.lower().startswith(n)), "")

    def messages_enabled(self): return self.access
    def recent_messages(self, limit=5, who=""):
        rows = [r for r in self.rows if not who or who.lower() in (r["sender"] + r.get("conv", "")).lower()]
        return rows[:limit]
    def open_message(self, who=""):
        self.opened.append(who)
        return "ok: opened" if self.rows else "error: I don't see a message to open"
    def read_screen(self): return self.screen


def msgs(now):
    return [
        {"app": "WhatsApp", "sender": "Rahul", "conv": "", "text": "are you coming?", "when": now - 120},
        {"app": "WhatsApp", "sender": "Rahul", "conv": "", "text": "hello", "when": now - 300},
        {"app": "Messages", "sender": "Mom", "conv": "", "text": "call me", "when": now - 4000},
    ]


class FastTests(unittest.TestCase):
    def setUp(self):
        self.now = time.time()
        self.phone = FakePhone(rows=msgs(self.now))
        self.fast = FastIntents("android", self.phone, now=lambda: self.now,
                                summarise=lambda q, c: "You have a meeting at 5 pm.")

    def test_open_app_variants(self):
        for text in ["open chrome", "Open Chrome please", "can you launch the chrome app", "chrome kholo", "open my instagram"]:
            r = self.fast.match(text)
            self.assertIsNotNone(r, text)
            self.assertEqual(r.actions[0]["status"], "client")
            self.assertEqual(r.actions[0]["args"]["action"], "a_open_app")

    def test_open_is_not_hijacked(self):
        for text in ["open the door", "open calendar", "what is chrome", "open a new chat", "open chrome and search cats", "tell me a joke"]:
            self.assertIsNone(self.fast.match(text), text)

    def test_who_messaged(self):
        r = self.fast.match("who messaged me now")
        self.assertIn("Rahul", r.text)
        self.assertIn("2 minutes ago", r.text)
        self.assertIn("are you coming?", r.text)
        self.assertIn("Mom", r.text)
        self.assertTrue(r.ok)

    def test_latest_and_named(self):
        r = self.fast.match("read my latest message")
        self.assertIn("latest", r.text.lower())
        self.assertNotIn("Mom", r.text)
        r = self.fast.match("what did mom say")
        self.assertIn("call me", r.text)
        r = self.fast.match("any messages from zed")
        self.assertIn("don't see", r.text)

    def test_open_message(self):
        r = self.fast.match("open my latest message")
        self.assertIn("Opening", r.text)
        self.assertEqual(self.phone.opened, [""])
        self.fast.match("open message from rahul")
        self.assertEqual(self.phone.opened[-1], "rahul")

    def test_needs_access_is_honest(self):
        self.phone.access = False
        r = self.fast.match("who messaged me")
        self.assertFalse(r.ok)
        self.assertIn("notification access", r.text)
        self.assertEqual(self.phone.opened, [])

    def test_open_message_failure_reported(self):
        self.phone.rows = []
        r = self.fast.match("open my latest message")
        self.assertFalse(r.ok)
        self.assertNotIn("Opening", r.text)

    def test_screen(self):
        r = self.fast.match("read my screen")
        self.assertIn("meeting at 5 pm", r.text)
        self.phone.screen = "error: turn on Luna phone control first"
        r = self.fast.match("what's on my screen")
        self.assertFalse(r.ok)
        self.assertIn("phone control", r.text)

    def test_unknown_app_falls_through(self):
        self.assertIsNone(self.fast.match("open nonexistentapp"))


class Boom:
    """A provider that fails the test if the AI is asked anything."""
    last_used = ""
    def generate(self, *a, **k): raise AssertionError("AI was called")
    def stream(self, *a, **k): raise AssertionError("AI was called")


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        self.settings = load_settings(d / "none.env", d / "keys.json")
        self.phone = FakePhone(rows=msgs(time.time()))
        self.app = build_app(self.settings, store=ChatStore(d / "chats.json"), provider=Boom(), phone=self.phone)
        self.app.platform = "android"
        self.app.assistant.fast.platform = "android"
        self.app.runner.platform = "android"

    def tearDown(self):
        self.tmp.cleanup()

    def test_fast_path_never_calls_ai_and_is_saved(self):
        chat = self.app.store.new_chat().id
        out = list(self.app.assistant.handle_stream(chat, "open chrome"))
        reply = out[-1][1]
        self.assertTrue(reply.ok)
        self.assertEqual(reply.actions[0]["status"], "client")
        saved = self.app.store.messages(chat)
        self.assertEqual([m["role"] for m in saved], ["user", "assistant"])

    def test_works_without_any_api_key(self):
        self.assertFalse(self.settings.has_api_key)
        reply = self.app.assistant.handle(None, "who messaged me")
        self.assertTrue(reply.ok)
        self.assertIn("Rahul", reply.text)

    def test_voice_lands_in_the_open_chat(self):
        shown = self.app.start({})
        chat_id = shown["id"]
        out = self.app.background_heard("hey luna open chrome")
        self.assertEqual(out["state"], "reply")
        self.assertEqual(out["actions"][0]["name"], "Chrome")
        texts = [m["text"] for m in self.app.store.messages(chat_id)]
        self.assertEqual(len(texts), 2)
        self.assertIn("open chrome", texts[0].lower())

    def test_reply_message_needs_confirmation(self):
        name, args, where, risky = check({"action": "reply_message", "to": "Rahul", "text": "coming"}, "android")
        self.assertTrue(risky)
        self.assertEqual(where, "android")
        self.assertIn("Rahul", label(name, args))
        with self.assertRaises(ActionError):
            check({"action": "reply_message", "to": "Rahul"}, "android")
        res = self.app.runner.execute({"action": "reply_message", "to": "Rahul", "text": "coming"})
        self.assertEqual(res["status"], "confirm")


if __name__ == "__main__":
    unittest.main()


class WindowsFastTests(unittest.TestCase):
    def test_windows_open_uses_runner_and_known_apps_only(self):
        calls = []

        class Runner:
            def execute(self, a):
                calls.append(a)
                return {"status": "done", "text": "Opened"}

        fast = FastIntents("windows", None, Runner(), {"chrome": "chrome", "notepad": "notepad"})
        r = fast.match("open notepad")
        self.assertTrue(r.ok)
        self.assertEqual(calls[0], {"action": "open_app", "name": "notepad"})
        self.assertIsNone(fast.match("open somethingweird"))
        self.assertIsNone(fast.match("who messaged me"))  # phone-only
