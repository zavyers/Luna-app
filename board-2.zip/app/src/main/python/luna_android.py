"""Starts Luna's local server inside the Android app and returns its address."""
from pathlib import Path


def start(api_key, data_dir):
    from app.chat.store import ChatStore
    from app.config.settings import Settings
    from app.ui.server import LunaServer, build_app

    folder = Path(data_dir)
    folder.mkdir(parents=True, exist_ok=True)
    settings = Settings(gemini_api_key=(api_key or "").strip() or None)
    server = LunaServer(build_app(settings, store=ChatStore(folder / "chats.json")))
    server.start()
    return server.url
