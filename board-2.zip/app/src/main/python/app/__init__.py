"""Luna: a Gemini-powered personal assistant for Windows."""

__version__ = "0.1.0"
