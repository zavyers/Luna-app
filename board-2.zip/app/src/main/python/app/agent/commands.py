"""Local commands Luna handles herself, without asking Gemini.

Works on text, so it behaves the same whether the words were typed or (later) spoken.
It is deliberately strict: the WHOLE utterance has to be the command, so a request like
"make a project plan for my app" still goes to Gemini instead of creating a project.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

_WAKE = r"(?:(?:hey|hi|ok|okay)\s+)?(?:luna[\s,]+)?"
_POLITE = r"(?:please\s+)?(?:(?:can|could|will|would)\s+you\s+(?:please\s+)?)?"
_VERBS = r"(?:start|open|create|make|begin|set\s+up)"
_ARTICLE = r"(?:a\s+|an\s+|another\s+|the\s+)?"
_VERB_PHRASE = rf"(?:{_VERBS}\s+{_ARTICLE})?"
_END = r"[\s.!?]*(?:please)?[\s.!?]*$"
_PREFIX = rf"^{_WAKE}{_POLITE}"

_NEW_CHAT = re.compile(
    rf"{_PREFIX}{_VERB_PHRASE}(?:new|fresh|another|blank)\s+(?:chat|conversation)(?:\s+window)?{_END}",
    re.IGNORECASE,
)
# "new project", "start a project", "create another project"
_PROJECT_BARE = re.compile(
    rf"{_PREFIX}(?:{_VERBS}\s+{_ARTICLE}(?:new\s+)?|(?:new|another)\s+)project{_END}",
    re.IGNORECASE,
)
# "new project called Luna", "start a project named Website"
_PROJECT_NAMED = re.compile(
    rf"{_PREFIX}{_VERB_PHRASE}(?:(?:new|another)\s+)?project\s+(?:called|named|titled)\s+(?P<name>.+?){_END}",
    re.IGNORECASE,
)
# "new project Website" / "new project: Website" (only when the phrase starts with "new project")
_PROJECT_SHORT = re.compile(
    rf"{_PREFIX}new\s+project\s*[:\-]?\s*(?P<name>[^.!?:]+?){_END}",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class Command:
    name: str  # "new_chat" | "new_project"
    argument: Optional[str] = None


def _clean_name(name: str) -> Optional[str]:
    cleaned = name.strip(" \"'.,!?")
    return cleaned or None


def parse_command(text: str) -> Optional[Command]:
    cleaned = " ".join(text.strip().split())
    if not cleaned or len(cleaned) > 120:
        return None

    if _NEW_CHAT.match(cleaned):
        return Command("new_chat")
    if _PROJECT_BARE.match(cleaned):
        return Command("new_project")
    named = _PROJECT_NAMED.match(cleaned)
    if named:
        return Command("new_project", _clean_name(named.group("name")))
    short = _PROJECT_SHORT.match(cleaned)
    if short:
        return Command("new_project", _clean_name(short.group("name")))
    return None
