"""Luna configuration.

The Gemini API key is read ONLY from the environment, which is populated from the
`.env` file next to main.py. It is never hard-coded, printed or logged.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import dotenv_values

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ENV_FILE = PROJECT_ROOT / ".env"

API_KEY_VAR = "GEMINI_API_KEY"
MODEL_VAR = "GEMINI_MODEL"
DEFAULT_MODEL = "gemini-3.8-flash"
DEFAULT_TIMEOUT_SECONDS = 30.0

# Values that mean "the user has not put a real key in yet".
_PLACEHOLDER_VALUES = {"", "changeme", "none", "null"}


def _clean_key(value: Optional[str]) -> Optional[str]:
    """Return a usable key, or None if the value is empty or a placeholder."""
    if value is None:
        return None
    cleaned = value.strip().strip("\"'").strip()
    lowered = cleaned.lower()
    if lowered in _PLACEHOLDER_VALUES or "your_gemini_api_key" in lowered:
        return None
    return cleaned


@dataclass(frozen=True)
class Settings:
    # repr=False so the key can never leak through print(settings) or logging.
    gemini_api_key: Optional[str] = field(default=None, repr=False)
    gemini_model: str = DEFAULT_MODEL
    request_timeout: float = DEFAULT_TIMEOUT_SECONDS
    env_file: Path = ENV_FILE

    @property
    def has_api_key(self) -> bool:
        return bool(self.gemini_api_key)


def load_settings(env_file: Optional[Path] = None) -> Settings:
    """Load settings from the OS environment and the .env file.

    Real OS environment variables win over the .env file. The .env file is read with
    `utf-8-sig` because Windows Notepad often saves a BOM that would otherwise corrupt
    the first variable name. Nothing is written into os.environ.
    """
    path = Path(env_file) if env_file is not None else ENV_FILE
    file_values: dict = {}
    if path.is_file():
        try:
            file_values = dotenv_values(path, encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError):
            file_values = {}

    def lookup(name: str) -> Optional[str]:
        return os.environ.get(name) or file_values.get(name)

    model = (lookup(MODEL_VAR) or "").strip() or DEFAULT_MODEL
    return Settings(
        gemini_api_key=_clean_key(lookup(API_KEY_VAR)),
        gemini_model=model,
        env_file=path,
    )


def missing_key_message(env_file: Optional[Path] = None) -> str:
    """Clear, key-free setup instructions shown when no Gemini key is configured."""
    path = Path(env_file) if env_file is not None else ENV_FILE
    lines = [
        "Luna needs a Google Gemini API key before she can think.",
        "",
        "1. Get a key from Google AI Studio (aistudio.google.com).",
        f"2. Open this file in a text editor: {path}",
        f"3. Set the line  {API_KEY_VAR}=  to your key (no quotes, no spaces).",
        "4. Save the file and restart Luna.",
        "",
        "Never paste your key into the source code or into a chat.",
    ]
    hidden = path.with_name(path.name + ".txt")
    if not path.exists() and hidden.exists():
        lines.append("")
        lines.append(
            f"Found '{hidden.name}' instead of '{path.name}'. Windows Notepad adds .txt "
            "automatically; rename the file so it has no .txt extension."
        )
    return "\n".join(lines)
