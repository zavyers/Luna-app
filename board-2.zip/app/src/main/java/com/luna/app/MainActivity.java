package com.luna.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private WebView web;
    private boolean started = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050b14"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);

        SharedPreferences prefs = getSharedPreferences("luna", MODE_PRIVATE);
        String key = prefs.getString("gemini_key", "");
        if (key.isEmpty() && !prefs.getBoolean("asked", false)) {
            askForKey(prefs);
        } else {
            startLuna(key);
        }
    }

    private void askForKey(final SharedPreferences prefs) {
        final EditText input = new EditText(this);
        input.setHint("Gemini API key");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(this)
                .setTitle("Paste your Gemini API key")
                .setMessage("It is stored only on this phone.")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Save", (d, w) -> {
                    String k = input.getText().toString().trim();
                    prefs.edit().putString("gemini_key", k).putBoolean("asked", true).apply();
                    startLuna(k);
                })
                .setNegativeButton("Skip", (d, w) -> {
                    prefs.edit().putBoolean("asked", true).apply();
                    startLuna("");
                })
                .show();
    }

    private void startLuna(final String key) {
        if (started) return;
        started = true;
        new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                PyObject mod = Python.getInstance().getModule("luna_android");
                final String url = mod.callAttr("start", key, getFilesDir().getAbsolutePath() + "/luna").toString();
                runOnUiThread(() -> web.loadUrl(url));
            } catch (final Throwable t) {
                runOnUiThread(() -> Toast.makeText(this, "Luna failed to start: " + t.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
