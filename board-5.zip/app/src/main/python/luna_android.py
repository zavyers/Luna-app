"""Starts Luna's engine inside the Android app, and answers the background listening service."""
import json
import os
from pathlib import Path

_STATE = {}


def start(data_dir):
    """Starts the engine once; asking again just returns the same address."""
    if "url" in _STATE:
        return _STATE["url"]
    os.environ.setdefault("LUNA_REQUEST_TIMEOUT", "120")  # phones on mobile data can be slow
    os.environ["LUNA_PLATFORM"] = "android"
    from app.chat.store import ChatStore
    from app.config import load_settings
    from app.ui.server import LunaServer, build_app

    folder = Path(data_dir)
    folder.mkdir(parents=True, exist_ok=True)
    # Keys, the assistant's name and everything else are set in Luna's own Settings screen.
    settings = load_settings(folder / "none.env", folder / "keys.json")
    app = build_app(settings, store=ChatStore(folder / "chats.json"))
    server = LunaServer(app)
    server.start()
    _STATE.update(url=server.url, app=app, server=server)
    return server.url


def heard(text):
    """The background service heard something. Returns JSON: ignore, awake, or a spoken reply with phone actions."""
    return json.dumps(_STATE["app"].background_heard(str(text)))


def pending():
    """Orders from the paired laptop that the phone still has to carry out (JSON list)."""
    return json.dumps(_STATE["app"].actions_pending({})["actions"])
