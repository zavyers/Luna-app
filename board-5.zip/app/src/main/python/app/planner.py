"""Luna's own calendar, to-do list and scheduled reminders. One small JSON file on the device.

Times are the device's local time: "2026-10-12T15:30" (date and time) or "2026-10-12" (all day).
Tasks and events can repeat. Deleting leaves a tombstone so the deletion also reaches a paired device.
"""
from __future__ import annotations

import calendar as _calendar
import json
import re
import secrets
import threading
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

REPEATS = ("none", "daily", "weekly", "monthly", "yearly")
KINDS = ("task", "event")
MAX_ITEMS = 2000
ALL_DAY_REMINDER_HOUR = 9
_FORMS = ("%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d")


class PlannerError(Exception):
    """Safe-to-show message."""


def parse_when(value: str) -> Tuple[datetime, bool]:
    """Returns (datetime, has_time)."""
    text = (value or "").strip()
    for form in _FORMS:
        try:
            return datetime.strptime(text, form), form != "%Y-%m-%d"
        except ValueError:
            continue
    raise PlannerError("I could not understand that date. Use a form like 2026-10-12 or 2026-10-12 15:30.")


def norm_when(value: Optional[str]) -> Optional[str]:
    if value in (None, ""):
        return None
    dt, has_time = parse_when(str(value))
    return dt.strftime("%Y-%m-%dT%H:%M") if has_time else dt.strftime("%Y-%m-%d")


def _add_months(dt: datetime, months: int) -> datetime:
    total = dt.year * 12 + (dt.month - 1) + months
    year, month = divmod(total, 12)
    day = min(dt.day, _calendar.monthrange(year, month + 1)[1])
    return dt.replace(year=year, month=month + 1, day=day)


def _step(dt: datetime, repeat: str) -> datetime:
    if repeat == "daily":
        return dt + timedelta(days=1)
    if repeat == "weekly":
        return dt + timedelta(days=7)
    if repeat == "monthly":
        return _add_months(dt, 1)
    return _add_months(dt, 12)  # yearly


class Planner:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._lock = threading.RLock()
        self._items: Dict[str, Dict[str, Any]] = {}
        self._fired: Dict[str, float] = {}
        self.revision = 0
        self._load()

    # ------------------------------------------------------------ persistence

    def _load(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            self._items = {str(k): dict(v) for k, v in (raw.get("items") or {}).items() if isinstance(v, dict)}
            self._fired = {str(k): float(v) for k, v in (raw.get("fired") or {}).items()}
        except (OSError, ValueError, AttributeError, TypeError):
            self._items, self._fired = {}, {}

    def _save(self) -> None:
        cutoff = time.time() - 14 * 86400
        self._fired = {k: v for k, v in self._fired.items() if v > cutoff}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps({"items": self._items, "fired": self._fired}), encoding="utf-8")
        tmp.replace(self.path)
        self.revision += 1

    # ------------------------------------------------------------------ edits

    def add(self, kind: str, title: str, when: Optional[str] = None, repeat: str = "none",
            remind: Optional[int] = None, notes: str = "") -> Dict[str, Any]:
        title = " ".join(str(title or "").split())[:200]
        if kind not in KINDS:
            raise PlannerError("An item is either a task or an event.")
        if not title:
            raise PlannerError("What should I call it?")
        if repeat not in REPEATS:
            raise PlannerError("Repeat must be none, daily, weekly, monthly or yearly.")
        when = norm_when(when)
        if kind == "event" and not when:
            raise PlannerError("An event needs a date.")
        if repeat != "none" and not when:
            raise PlannerError("A repeating item needs a start date.")
        try:
            minutes = int(remind) if remind not in (None, "") else (10 if kind == "event" else 0)
        except (TypeError, ValueError):
            raise PlannerError("Reminder minutes must be a number.") from None
        minutes = max(0, min(minutes, 7 * 24 * 60))
        now = time.time()
        with self._lock:
            if sum(1 for i in self._items.values() if not i.get("deleted")) >= MAX_ITEMS:
                raise PlannerError("The planner is full. Delete some old items first.")
            item = {"id": secrets.token_hex(6), "kind": kind, "title": title, "when": when, "repeat": repeat,
                    "remind": minutes, "done": False, "notes": str(notes or "")[:500], "created": now,
                    "updated": now, "deleted": False}
            self._items[item["id"]] = item
            self._save()
            return dict(item)

    def _live(self, item_id: str) -> Dict[str, Any]:
        item = self._items.get(item_id)
        if not item or item.get("deleted"):
            raise PlannerError("I can't find that item.")
        return item

    def update(self, item_id: str, **fields: Any) -> Dict[str, Any]:
        with self._lock:
            item = self._live(item_id)
            if "title" in fields:
                title = " ".join(str(fields["title"]).split())[:200]
                if not title:
                    raise PlannerError("The title can't be empty.")
                item["title"] = title
            if "when" in fields:
                item["when"] = norm_when(fields["when"])
            if "repeat" in fields:
                if fields["repeat"] not in REPEATS:
                    raise PlannerError("Unknown repeat.")
                item["repeat"] = fields["repeat"]
            if "remind" in fields:
                item["remind"] = max(0, min(int(fields["remind"]), 7 * 24 * 60))
            if "notes" in fields:
                item["notes"] = str(fields["notes"])[:500]
            item["updated"] = time.time()
            self._save()
            return dict(item)

    def complete(self, item_id: str, done: bool = True) -> Dict[str, Any]:
        with self._lock:
            item = self._live(item_id)
            if done and item["repeat"] != "none" and item.get("when"):
                dt, has_time = parse_when(item["when"])
                nxt = _step(dt, item["repeat"])
                while nxt <= datetime.now():
                    nxt = _step(nxt, item["repeat"])
                item["when"] = nxt.strftime("%Y-%m-%dT%H:%M") if has_time else nxt.strftime("%Y-%m-%d")
                item["done"] = False
            else:
                item["done"] = bool(done)
            item["updated"] = time.time()
            self._save()
            return dict(item)

    def delete(self, item_id: str) -> None:
        with self._lock:
            item = self._live(item_id)
            item["deleted"], item["updated"] = True, time.time()
            self._save()

    def find(self, query: str, kind: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Best match by title among live items (exact id, then words in common)."""
        q = " ".join(str(query or "").lower().split())
        if not q:
            return None
        with self._lock:
            live = [i for i in self._items.values() if not i.get("deleted") and (not kind or i["kind"] == kind)]
            for i in live:
                if i["id"] == q:
                    return dict(i)
            words = set(re.findall(r"\w+", q))
            best, score = None, 0.0
            for i in live:
                t = i["title"].lower()
                s = 3.0 if q in t or t in q else len(words & set(re.findall(r"\w+", t))) / max(1, len(words))
                if i.get("done"):
                    s -= 0.5
                if s > score:
                    best, score = i, s
            return dict(best) if best is not None and score >= 0.5 else None

    # ---------------------------------------------------------------- queries

    def tasks(self, include_done: bool = False) -> List[Dict[str, Any]]:
        with self._lock:
            out = [dict(i) for i in self._items.values() if not i.get("deleted") and i["kind"] == "task"
                   and (include_done or not i.get("done"))]
        return sorted(out, key=lambda i: (i.get("done", False), i.get("when") or "9999", i["created"]))

    def occurrences(self, start: datetime, end: datetime) -> List[Dict[str, Any]]:
        """Every dated item (repeats expanded) that falls between start and end."""
        out: List[Dict[str, Any]] = []
        with self._lock:
            items = [dict(i) for i in self._items.values() if not i.get("deleted") and i.get("when")]
        for item in items:
            base, has_time = parse_when(item["when"])
            cur, n = base, 0
            if item["repeat"] in ("daily", "weekly") and base < start:
                days = 1 if item["repeat"] == "daily" else 7
                cur = base + timedelta(days=max(0, ((start - base).days // days)) * days)
            while cur <= end and n < 900:
                n += 1
                day_start = cur.replace(hour=0, minute=0)
                if (cur >= start) or (not has_time and day_start >= start.replace(hour=0, minute=0)):
                    out.append({"id": item["id"], "kind": item["kind"], "title": item["title"], "done": item.get("done", False),
                                "date": cur.strftime("%Y-%m-%d"), "time": cur.strftime("%H:%M") if has_time else "",
                                "repeat": item["repeat"]})
                if item["repeat"] == "none":
                    break
                cur = _step(cur, item["repeat"])
        return sorted(out, key=lambda o: (o["date"], o["time"] or "00:00", o["title"]))

    def month(self, year: int, month: int, today: Optional[date] = None) -> Dict[str, Any]:
        if not (1900 <= year <= 2200 and 1 <= month <= 12):
            raise PlannerError("That month is out of range.")
        today = today or date.today()
        weeks = _calendar.Calendar(firstweekday=6).monthdatescalendar(year, month)
        start = datetime.combine(weeks[0][0], datetime.min.time())
        end = datetime.combine(weeks[-1][-1], datetime.max.time())
        by_day: Dict[str, List[Dict[str, Any]]] = {}
        for occ in self.occurrences(start, end):
            by_day.setdefault(occ["date"], []).append(occ)
        return {"year": year, "month": month, "title": f"{_calendar.month_name[month]} {year}",
                "weeks": [[{"date": d.isoformat(), "day": d.day, "other": d.month != month, "today": d == today,
                            "items": by_day.get(d.isoformat(), [])} for d in week] for week in weeks]}

    def digest(self, now: Optional[datetime] = None, limit: int = 14) -> str:
        """A short text of what is coming up, for the AI to answer 'what is on my schedule?'."""
        now = now or datetime.now()
        lines = []
        for t in self.tasks()[:limit]:
            lines.append(f"- task: {t['title']}" + (f" (due {t['when'].replace('T', ' ')})" if t.get("when") else "") + (f", repeats {t['repeat']}" if t["repeat"] != "none" else ""))
        for o in self.occurrences(now.replace(hour=0, minute=0), now + timedelta(days=7)):
            if o["kind"] == "event":
                lines.append(f"- event: {o['title']} on {o['date']}" + (f" at {o['time']}" if o["time"] else ""))
            if len(lines) >= limit * 2:
                break
        return "\n".join(lines)

    # -------------------------------------------------------------- reminders

    @staticmethod
    def _reminder_at(item: Dict[str, Any], occ: datetime, has_time: bool) -> datetime:
        base = occ if has_time else occ.replace(hour=ALL_DAY_REMINDER_HOUR, minute=0)
        return base - timedelta(minutes=int(item.get("remind", 0)))

    def _reminders(self, start: datetime, end: datetime) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        with self._lock:
            items = [dict(i) for i in self._items.values() if not i.get("deleted") and i.get("when") and not i.get("done")]
        for item in items:
            base, has_time = parse_when(item["when"])
            cur, n = base, 0
            if item["repeat"] in ("daily", "weekly") and base < start - timedelta(days=2):
                days = 1 if item["repeat"] == "daily" else 7
                cur = base + timedelta(days=max(0, ((start - timedelta(days=2) - base).days // days)) * days)
            while n < 900:
                n += 1
                at = self._reminder_at(item, cur, has_time)
                if at > end:
                    break
                if at >= start:
                    out.append({"key": f"{item['id']}@{at.strftime('%Y-%m-%dT%H:%M')}", "id": item["id"], "title": item["title"],
                                "kind": item["kind"], "at": at.strftime("%Y-%m-%dT%H:%M")})
                if item["repeat"] == "none":
                    break
                cur = _step(cur, item["repeat"])
        return sorted(out, key=lambda r: r["at"])

    def upcoming_reminders(self, now: Optional[datetime] = None, hours: int = 72) -> List[Dict[str, Any]]:
        """Reminders still to come (for Android to schedule alarms)."""
        now = now or datetime.now()
        with self._lock:
            fired = set(self._fired)
        return [r for r in self._reminders(now, now + timedelta(hours=hours)) if r["key"] not in fired]

    def due(self, now: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """Reminders whose time has come and which have not been shown yet (marks them shown)."""
        now = now or datetime.now()
        hits = []
        with self._lock:
            for r in self._reminders(now - timedelta(hours=24), now):
                if r["key"] not in self._fired:
                    self._fired[r["key"]] = time.time()
                    hits.append(r)
            if hits:
                self._save()
        return hits

    # ---------------------------------------------------------------- pairing

    def export(self) -> Dict[str, Any]:
        with self._lock:
            return {"items": [dict(i) for i in self._items.values()]}

    def merge(self, data: Dict[str, Any]) -> int:
        changed = 0
        try:
            with self._lock:
                for raw in list(data.get("items", []))[:MAX_ITEMS]:
                    iid = str(raw["id"])
                    local = self._items.get(iid)
                    if local is None or float(raw.get("updated", 0)) > float(local.get("updated", 0)):
                        item = {"id": iid, "kind": raw["kind"] if raw["kind"] in KINDS else "task", "title": str(raw["title"])[:200],
                                "when": norm_when(raw.get("when")), "repeat": raw.get("repeat") if raw.get("repeat") in REPEATS else "none",
                                "remind": max(0, int(raw.get("remind", 0))), "done": bool(raw.get("done")), "notes": str(raw.get("notes", ""))[:500],
                                "created": float(raw.get("created", 0)), "updated": float(raw.get("updated", 0)), "deleted": bool(raw.get("deleted"))}
                        self._items[iid] = item
                        changed += 1
                if changed:
                    self._save()
        except (KeyError, TypeError, ValueError, AttributeError, PlannerError):
            pass
        return changed
