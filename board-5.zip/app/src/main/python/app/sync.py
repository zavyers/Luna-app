"""Pair two devices (phone <-> laptop) on the same Wi-Fi with a 6-digit code.

One device shows a code, the other types it in. The typing device finds the other one on
the local network, they swap a secret token, and from then on the chats are kept in step
(both ways, new messages only, nothing is ever deleted by syncing). Nothing goes through
the internet or any server of ours.
"""
from __future__ import annotations

import base64
import hmac
import http.client
import ipaddress
import json
import re
import secrets
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional

PORT = 47822
CODE_SECONDS = 300
MAX_ATTEMPTS = 5
MAX_BODY = 12 * 1024 * 1024
SYNC_EVERY = 15.0
_IMAGE_RE = re.compile(r"\[\[image:([0-9a-f]{24}\.(?:png|jpg|webp))\|")


class PairError(Exception):
    """Safe-to-show message."""


def local_ips() -> List[str]:
    ips: List[str] = []
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("10.255.255.255", 1))
        ips.append(probe.getsockname()[0])
        probe.close()
    except OSError:
        pass
    try:
        ips += socket.gethostbyname_ex(socket.gethostname())[2]
    except OSError:
        pass
    out: List[str] = []
    for ip in ips:
        try:
            if ipaddress.ip_address(ip).is_private and not ip.startswith("127.") and ip not in out:
                out.append(ip)
        except ValueError:
            continue
    return out


def _images_in(chats: List[Dict[str, Any]]) -> List[str]:
    names: List[str] = []
    for c in chats:
        for m in c.get("messages", []):
            for name in _IMAGE_RE.findall(str(m.get("text", ""))):
                if name not in names:
                    names.append(name)
    return names


class SyncManager:
    def __init__(self, store: Any, data_dir: Path, image_dir: Optional[Path] = None, port: int = PORT,
                 planner: Any = None, on_action: Any = None) -> None:
        self.store = store
        self.planner = planner
        self.on_action = on_action
        self._outbox: List[Dict[str, Any]] = []
        self.file = Path(data_dir) / "pairing.json"
        self.image_dir = Path(image_dir) if image_dir else Path(data_dir) / "images"
        self.port = port
        self.device = (socket.gethostname() or "device")[:40]
        self.revision = 0            # bumps when a sync brought something new
        self.last_sync = 0.0
        self.last_error = ""
        self._code: Optional[str] = None
        self._code_until = 0.0
        self._attempts = 0
        self._server: Optional[ThreadingHTTPServer] = None
        self._lock = threading.RLock()
        self._peers: Dict[str, Dict[str, Any]] = {}   # devices allowed to sync with me
        self._link: Optional[Dict[str, Any]] = None   # the device I joined
        self._loop_started = False
        self._load()
        if self._peers:
            self._start_server(quiet=True)
        if self._link:
            self._start_loop()

    # ------------------------------------------------------------ persistence

    def _load(self) -> None:
        try:
            raw = json.loads(self.file.read_text(encoding="utf-8"))
            self._peers = {str(k): dict(v) for k, v in (raw.get("peers") or {}).items()}
            link = raw.get("link")
            self._link = dict(link) if isinstance(link, dict) and link.get("host") and link.get("token") else None
        except (OSError, ValueError, AttributeError, TypeError):
            self._peers, self._link = {}, None

    def _save(self) -> None:
        self.file.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.file.with_name(self.file.name + ".tmp")
        tmp.write_text(json.dumps({"peers": self._peers, "link": self._link}), encoding="utf-8")
        try:
            tmp.chmod(0o600)
        except OSError:
            pass
        tmp.replace(self.file)

    # ------------------------------------------------- showing a code (host)

    def start_pairing(self) -> Dict[str, Any]:
        with self._lock:
            self._start_server()
            self._code = f"{secrets.randbelow(10**6):06d}"
            self._code_until = time.time() + CODE_SECONDS
            self._attempts = 0
            timer = threading.Timer(CODE_SECONDS + 2, self._expire_check)
            timer.daemon = True  # never keep the app alive just for this
            timer.start()
        return self.status()

    def stop_pairing(self) -> Dict[str, Any]:
        with self._lock:
            self._code = None
            self._expire_check()
        return self.status()

    def _expire_check(self) -> None:
        with self._lock:
            if self._code and time.time() > self._code_until:
                self._code = None
            if not self._code and not self._peers and self._server is not None:
                self._server.shutdown()
                self._server.server_close()
                self._server = None

    def _start_server(self, quiet: bool = False) -> None:
        if self._server is not None:
            return
        try:
            server = ThreadingHTTPServer(("0.0.0.0", self.port), self._handler())
        except OSError:
            if quiet:
                return
            raise PairError("Luna could not open the pairing port. Close other Luna windows and try again.") from None
        server.daemon_threads = True
        threading.Thread(target=server.serve_forever, daemon=True).start()
        self._server = server

    def _handler(self) -> type:
        mgr = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *_: Any) -> None:
                pass

            def _json(self, status: int, body: Dict[str, Any]) -> None:
                raw = json.dumps(body).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def _authed(self) -> bool:
                supplied = (self.headers.get("Authorization") or "").replace("Bearer ", "", 1)
                with mgr._lock:
                    return any(hmac.compare_digest(supplied, t) for t in mgr._peers)

            def _body(self) -> Optional[Dict[str, Any]]:
                try:
                    length = int(self.headers.get("Content-Length") or 0)
                    if length < 0 or length > MAX_BODY:
                        return None
                    data = json.loads(self.rfile.read(length).decode("utf-8")) if length else {}
                    return data if isinstance(data, dict) else None
                except (ValueError, UnicodeDecodeError):
                    return None

            def do_GET(self) -> None:
                path = self.path.split("?", 1)[0]
                if path == "/sync/ping":
                    return self._json(200, {"luna": True})
                if not self._authed():
                    return self._json(403, {"error": "Not paired."})
                if path == "/sync/data":
                    m = re.search(r"since=([0-9.]+)", self.path)
                    since = float(m.group(1)) if m else 0.0
                    data = mgr.store.export_data(since)
                    return self._json(200, {"data": data, "images": _images_in(data["chats"]),
                                            "planner": mgr.planner.export() if mgr.planner else None})
                if path == "/sync/poll":
                    with mgr._lock:
                        cmds, mgr._outbox = mgr._outbox, []
                    return self._json(200, {"commands": cmds})
                if path.startswith("/sync/img/"):
                    name = path[len("/sync/img/"):]
                    if not re.fullmatch(r"[0-9a-f]{24}\.(png|jpg|webp)", name) or not (mgr.image_dir / name).is_file():
                        return self._json(404, {"error": "No such picture."})
                    raw = (mgr.image_dir / name).read_bytes()
                    return self._json(200, {"b64": base64.b64encode(raw).decode("ascii")})
                self._json(404, {"error": "Not found."})

            def do_POST(self) -> None:
                path = self.path.split("?", 1)[0]
                body = self._body()
                if body is None:
                    return self._json(400, {"error": "Bad request."})
                if path == "/sync/pair":
                    return self._json(*mgr._accept_pair(body))
                if not self._authed():
                    return self._json(403, {"error": "Not paired."})
                if path == "/sync/data":
                    changed = mgr.store.merge_data(body.get("data") or {})
                    if mgr.planner and body.get("planner"):
                        changed += mgr.planner.merge(body["planner"])
                    mgr._save_images(body.get("images") or {})
                    if changed:
                        mgr.revision += 1
                    return self._json(200, {"changed": changed})
                if path == "/sync/action" and mgr.on_action:
                    action = body.get("action")
                    if not isinstance(action, dict):
                        return self._json(400, {"error": "Bad request."})
                    return self._json(200, {"text": str(mgr.on_action(action, bool(body.get("confirmed"))))[:300]})
                self._json(404, {"error": "Not found."})

        return Handler

    def _accept_pair(self, body: Dict[str, Any]) -> tuple:
        with self._lock:
            if not self._code or time.time() > self._code_until:
                return 403, {"error": "No pairing code is showing on that device."}
            self._attempts += 1
            if self._attempts > MAX_ATTEMPTS:
                self._code = None
                return 403, {"error": "Too many wrong tries. Show a new code."}
            if not hmac.compare_digest(str(body.get("code", "")), self._code):
                return 403, {"error": "Wrong code."}
            token = secrets.token_urlsafe(24)
            self._peers[token] = {"name": str(body.get("name", "device"))[:40], "added": time.time()}
            self._code = None  # one use only
            self._save()
        self.revision += 1
        return 200, {"token": token, "name": self.device}

    def _save_images(self, images: Dict[str, str]) -> None:
        self.image_dir.mkdir(parents=True, exist_ok=True)
        for name, b64 in list(images.items())[:8]:
            if re.fullmatch(r"[0-9a-f]{24}\.(png|jpg|webp)", str(name)) and not (self.image_dir / name).exists():
                try:
                    raw = base64.b64decode(b64)
                except (ValueError, TypeError):
                    continue
                if len(raw) <= 12 * 1024 * 1024:
                    (self.image_dir / name).write_bytes(raw)

    # ----------------------------------------------- typing a code (client)

    def _scan(self) -> List[str]:
        hosts: List[str] = []
        for ip in local_ips():
            prefix = ip.rsplit(".", 1)[0]
            hosts += [f"{prefix}.{i}" for i in range(1, 255) if f"{prefix}.{i}" != ip]

        def probe(host: str) -> Optional[str]:
            try:
                conn = http.client.HTTPConnection(host, self.port, timeout=0.7)
                conn.request("GET", "/sync/ping")
                ok = json.loads(conn.getresponse().read().decode("utf-8")).get("luna") is True
                conn.close()
                return host if ok else None
            except (OSError, ValueError, http.client.HTTPException):
                return None

        with ThreadPoolExecutor(max_workers=64) as pool:
            return [h for h in pool.map(probe, hosts) if h]

    def join(self, code: str, address: str = "") -> Dict[str, Any]:
        code = re.sub(r"\D", "", code or "")
        if len(code) != 6:
            raise PairError("Type the 6 numbers shown on the other device.")
        candidates = []
        if address.strip():
            host, _, port = address.strip().partition(":")
            candidates.append((host, int(port) if port.isdigit() else self.port))
        else:
            candidates = [(h, self.port) for h in self._scan()]
        if not candidates:
            raise PairError("Luna could not find the other device. Put both on the same Wi-Fi, show the code there first, and try again.")
        wrong = False
        for host, port in candidates:
            try:
                conn = http.client.HTTPConnection(host, port, timeout=4)
                conn.request("POST", "/sync/pair", json.dumps({"code": code, "name": self.device}), {"Content-Type": "application/json"})
                resp = conn.getresponse()
                body = json.loads(resp.read().decode("utf-8"))
                conn.close()
            except (OSError, ValueError, http.client.HTTPException):
                continue
            if resp.status == 200 and body.get("token"):
                with self._lock:
                    self._link = {"host": host, "port": port, "token": body["token"], "name": str(body.get("name", host))[:40],
                                  "pull_since": 0.0, "push_since": 0.0}
                    self._save()
                self._start_loop()
                try:
                    self.sync_once()
                except PairError:
                    pass
                return self.status()
            wrong = True
        raise PairError("That code was not accepted. Check the numbers, or show a new code on the other device." if wrong
                        else "Luna found the other device but could not talk to it.")

    def unpair(self) -> Dict[str, Any]:
        with self._lock:
            self._link = None
            self._peers = {}
            self._save()
            self._code = None
            self._expire_check()
        return self.status()

    # ------------------------------------------------------------- syncing

    def _call(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        link = self._link
        if not link:
            raise PairError("Not paired.")
        try:
            conn = http.client.HTTPConnection(link["host"], int(link["port"]), timeout=10)
            raw = json.dumps(body).encode("utf-8") if body is not None else None
            conn.request(method, path, raw, {"Authorization": "Bearer " + link["token"], "Content-Type": "application/json"})
            resp = conn.getresponse()
            data = json.loads(resp.read().decode("utf-8"))
            conn.close()
        except (OSError, ValueError, http.client.HTTPException):
            raise PairError("The paired device is not reachable right now.") from None
        if resp.status == 403:
            raise PairError("The other device no longer recognises this one. Pair again.")
        if resp.status != 200:
            raise PairError("The paired device refused the sync.")
        return data

    def sync_once(self) -> Dict[str, Any]:
        with self._lock:
            link = self._link
        if not link:
            raise PairError("Not paired with another device yet.")
        try:
            got = self._call("GET", f"/sync/data?since={max(0.0, float(link.get('pull_since', 0)) - 1):.3f}")
            data = got.get("data") or {}
            changed = self.store.merge_data(data)
            if self.planner and got.get("planner"):
                changed += self.planner.merge(got["planner"])
            for name in got.get("images", [])[:40]:
                if not (self.image_dir / name).exists():
                    pic = self._call("GET", "/sync/img/" + name)
                    self._save_images({name: pic.get("b64", "")})
            newest = max([float(c.get("updated", 0)) for c in data.get("chats", [])] or [float(link.get("pull_since", 0))])

            mine = self.store.export_data(float(link.get("push_since", 0)))
            pushed_to = max([float(c.get("updated", 0)) for c in mine["chats"]] or [float(link.get("push_since", 0))])
            if mine["chats"]:
                images = {}
                for name in _images_in(mine["chats"])[:8]:
                    p = self.image_dir / name
                    if p.is_file() and p.stat().st_size < 3 * 1024 * 1024:
                        images[name] = base64.b64encode(p.read_bytes()).decode("ascii")
                self._call("POST", "/sync/data", {"data": mine, "images": images,
                                                  "planner": self.planner.export() if self.planner else None})
            elif self.planner:
                self._call("POST", "/sync/data", {"data": {"chats": [], "projects": []}, "images": {}, "planner": self.planner.export()})
            with self._lock:
                if self._link:
                    self._link["pull_since"], self._link["push_since"] = newest, pushed_to
                    self._save()
            self.last_sync, self.last_error = time.time(), ""
            if changed:
                self.revision += 1
            return {"changed": changed}
        except PairError as error:
            self.last_error = str(error)
            raise

    def _start_loop(self) -> None:
        with self._lock:
            if self._loop_started:
                return
            self._loop_started = True

        def loop() -> None:
            tick = 0
            while True:
                time.sleep(3.0)
                tick += 1
                if not self._link:
                    continue
                try:
                    for cmd in (self._call("GET", "/sync/poll").get("commands") or [])[:10]:  # orders from the other device
                        if self.on_action and isinstance(cmd.get("action"), dict):
                            self.on_action(cmd["action"], bool(cmd.get("confirmed")))
                    if tick % 5 == 0:
                        self.sync_once()
                except PairError:
                    pass
                except Exception:  # a sync bug must never kill the app
                    self.last_error = "Sync hit a problem and will retry."

        threading.Thread(target=loop, daemon=True).start()

    # --------------------------------------------------- orders to the other device

    def send_action(self, action: Dict[str, Any], confirmed: bool = False) -> str:
        """Ask the paired device to do something. The laptop is told at once; the phone picks it up within seconds."""
        with self._lock:
            link = self._link
            has_peers = bool(self._peers)
        if link:
            return str(self._call("POST", "/sync/action", {"action": action, "confirmed": confirmed}).get("text", "Done"))
        if has_peers:
            with self._lock:
                self._outbox.append({"action": action, "confirmed": confirmed})
            return "Sent. The other device will do it in a few seconds"
        raise PairError("No other device is paired. Open Settings, then Phone ↔ Laptop.")

    # ---------------------------------------------------------------- status

    def status(self) -> Dict[str, Any]:
        with self._lock:
            showing = bool(self._code and time.time() < self._code_until)
            link = self._link
            return {
                "paired": bool(link or self._peers),
                "peer": (link or {}).get("name") or (next(iter(self._peers.values()))["name"] if self._peers else ""),
                "role": "joined" if link else ("host" if self._peers else ""),
                "code": self._code if showing else "",
                "code_expires_in": max(0, int(self._code_until - time.time())) if showing else 0,
                "addresses": [f"{ip}:{self.port}" for ip in local_ips()] if showing else [],
                "last_sync": self.last_sync,
                "error": self.last_error,
                "revision": self.revision,
            }
