"""Luna's hands: turns the AI's  [[do: {...}]]  lines into real actions on this device,
on the paired device, or in the planner. Everything is checked against a fixed list first,
and anything that could do damage waits for the person's OK.
"""
from __future__ import annotations

import ctypes
import json
import os
import re
import subprocess
import sys
import urllib.parse
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.planner import Planner, PlannerError

_BLOCK = re.compile(r"\[\[do:\s*(\{.*?\})\s*\]\]", re.DOTALL)
_PARTIAL = re.compile(r"\[\[do:.*$", re.DOTALL)
MAX_ACTIONS = 6


class ActionError(Exception):
    """Safe-to-show message."""


# name -> (where it runs, needs OK first, {argument: (type, required, limit-or-choices)}, hint for the AI)
_REPEAT = ("none", "daily", "weekly", "monthly", "yearly")
SPECS: Dict[str, Tuple[str, bool, Dict[str, Tuple[Any, bool, Any]], str]] = {
    # planner: works on every device
    "add_task": ("planner", False, {"title": (str, True, 200), "when": (str, False, 20), "repeat": (str, False, _REPEAT), "remind": (int, False, 10080)},
                 'add_task {"title","when":"YYYY-MM-DD or YYYY-MM-DDTHH:MM (optional)","repeat":"none|daily|weekly|monthly|yearly","remind":minutes before}'),
    "add_event": ("planner", False, {"title": (str, True, 200), "when": (str, True, 20), "repeat": (str, False, _REPEAT), "remind": (int, False, 10080)},
                  'add_event {"title","when":"YYYY-MM-DDTHH:MM","repeat","remind"}'),
    "complete_task": ("planner", False, {"title": (str, True, 200)}, 'complete_task {"title"}'),
    "delete_item": ("planner", False, {"title": (str, True, 200)}, 'delete_item {"title"}'),
    "show_calendar": ("planner", False, {"month": (str, False, 7)}, 'show_calendar {"month":"YYYY-MM"} draws the calendar in the chat'),
    "show_tasks": ("planner", False, {}, 'show_tasks {} draws the to-do list in the chat'),
    # Windows laptop
    "open_app": ("windows", False, {"name": (str, True, 40)}, 'open_app {"name"}'),
    "open_url": ("windows", False, {"url": (str, True, 500)}, 'open_url {"url":"https://..."}'),
    "search_web": ("windows", False, {"query": (str, True, 300)}, 'search_web {"query"} opens a web search'),
    "open_folder": ("windows", False, {"name": (str, True, 20)}, 'open_folder {"name":"downloads|documents|desktop|pictures|music|videos"}'),
    "volume": ("windows", False, {"direction": (str, True, ("up", "down", "mute"))}, 'volume {"direction":"up|down|mute"}'),
    "media": ("windows", False, {"control": (str, True, ("play_pause", "next", "previous", "stop"))}, 'media {"control":"play_pause|next|previous|stop"} controls music and video'),
    "lock_screen": ("windows", False, {}, "lock_screen {}"),
    "shutdown": ("windows", True, {}, "shutdown {} (the person must confirm)"),
    "restart": ("windows", True, {}, "restart {} (the person must confirm)"),
    "sleep_pc": ("windows", True, {}, "sleep_pc {} (the person must confirm)"),
    "cancel_shutdown": ("windows", False, {}, "cancel_shutdown {}"),
    "close_app": ("windows", True, {"name": (str, True, 40)}, 'close_app {"name"} (the person must confirm)'),
    # Android phone (run by the app itself)
    "a_open_app": ("android", False, {"name": (str, True, 40)}, 'open_app {"name"}'),
    "a_open_url": ("android", False, {"url": (str, True, 500)}, 'open_url {"url":"https://..."}'),
    "a_search_web": ("android", False, {"query": (str, True, 300)}, 'search_web {"query"}'),
    "call": ("android", False, {"number": (str, True, 20)}, 'call {"number"} opens the dialer with the number; the person presses call'),
    "sms": ("android", False, {"number": (str, True, 20), "text": (str, False, 500)}, 'sms {"number","text"} prepares a message; the person presses send'),
    "alarm": ("android", False, {"hour": (int, True, 23), "minute": (int, True, 59), "label": (str, False, 60)}, 'alarm {"hour":0-23,"minute":0-59,"label"} sets a phone alarm'),
    "timer": ("android", False, {"seconds": (int, True, 86400), "label": (str, False, 60)}, 'timer {"seconds","label"}'),
    "open_settings": ("android", False, {"page": (str, True, ("main", "wifi", "bluetooth", "display", "sound", "battery", "apps", "location", "accessibility"))}, 'open_settings {"page":"wifi|bluetooth|display|sound|battery|apps|location|accessibility|main"}'),
    "flashlight": ("android", False, {"state": (str, True, ("on", "off"))}, 'flashlight {"state":"on|off"}'),
    "a_volume": ("android", False, {"direction": (str, True, ("up", "down", "mute"))}, 'volume {"direction":"up|down|mute"}'),
    "a_media": ("android", False, {"control": (str, True, ("play_pause", "next", "previous", "stop"))}, 'media {"control":"play_pause|next|previous|stop"} controls music and video in any app'),
    "navigate": ("android", False, {"place": (str, True, 200)}, 'navigate {"place"} starts maps directions'),
    "go_home": ("android", False, {}, "go_home {}"),
    "go_back": ("android", False, {}, "go_back {}"),
    "recents": ("android", False, {}, "recents {}"),
    "notifications": ("android", False, {}, "notifications {} pulls down the notification shade"),
    "quick_settings": ("android", False, {}, "quick_settings {}"),
    "a_lock_screen": ("android", False, {}, "lock_screen {}"),
    "screenshot": ("android", False, {}, "screenshot {}"),
    "tap": ("android", True, {"text": (str, True, 60)}, 'tap {"text":"words on the button"} taps something on screen (the person must confirm)'),
    "read_screen": ("android", False, {}, "read_screen {} reads out the text on the screen"),
}
# the AI says  open_app  on both platforms; Luna maps it to the right internal name
_ANDROID_ALIAS = {"open_app": "a_open_app", "open_url": "a_open_url", "search_web": "a_search_web", "volume": "a_volume", "media": "a_media", "lock_screen": "a_lock_screen"}


def normalize_platform(name: str) -> str:
    name = (name or "").lower()
    if name.startswith("win"):
        return "windows"
    return name if name in ("android", "mac", "linux") else ("mac" if name.startswith("darwin") else "linux")


def prompt_for(platform: str) -> str:
    """The part of the system prompt that teaches the AI what it may do here."""
    plat = normalize_platform(platform)
    plan = [h for n, (w, _r, _a, h) in SPECS.items() if w == "planner"]
    dev = [h for n, (w, _r, _a, h) in SPECS.items() if w == plat]
    dev = [re.sub(r"^a_", "", h) for h in dev]
    where = {"windows": "this Windows laptop", "android": "this Android phone"}.get(plat, "this computer")
    text = (
        "DEVICE CONTROL: you can act, not just talk. To do something, first say it in your normal reply "
        "(for example \"Yes sir, opening Chrome.\"), then add one line per action at the very END of the reply, "
        "exactly like this (JSON on one line): [[do: {\"action\":\"open_app\",\"name\":\"Chrome\"}]]. "
        "Never claim an action worked; the app runs it and reports. Use only the actions below, with these fields.\n"
        "Planner (calendar, to-do list, reminders) on this device:\n" + "\n".join("  " + h for h in plan) + "\n"
        f"On {where}:\n" + ("\n".join("  " + h for h in dev) if dev else "  (nothing yet)") + "\n"
        "To act on the user's OTHER paired device (the laptop when you run on the phone, and the other way round) add \"on\":\"other\" to the action. "
        "To add a reminder or scheduled task use add_task with a time. Use the date and time given below to turn words like "
        "\"tomorrow 5 pm\" into exact dates."
    )
    return text


def parse_actions(text: str) -> Tuple[str, List[Dict[str, Any]]]:
    """Returns (the reply without any [[do: ...]] lines, the actions found)."""
    actions: List[Dict[str, Any]] = []
    for m in _BLOCK.finditer(text):
        try:
            data = json.loads(m.group(1))
        except ValueError:
            continue
        if isinstance(data, dict) and isinstance(data.get("action"), str):
            actions.append(data)
    clean = _PARTIAL.sub("", _BLOCK.sub("", text)).rstrip()
    return clean, actions[:MAX_ACTIONS]


def check(action: Dict[str, Any], platform: str) -> Tuple[str, Dict[str, Any], str, bool]:
    """Validates one action. Returns (internal name, clean arguments, where it runs, needs an OK)."""
    plat = normalize_platform(platform)
    name = str(action.get("action", ""))
    internal = _ANDROID_ALIAS.get(name, name) if plat == "android" else name
    if internal not in SPECS or (internal.startswith("a_") and name == internal):
        raise ActionError("I can't do that.")
    where, risky, schema, _hint = SPECS[internal]
    if where not in ("planner", plat):
        raise ActionError("That isn't something I can do on this device.")
    clean: Dict[str, Any] = {}
    for arg, (kind, required, limit) in schema.items():
        value = action.get(arg)
        if value in (None, ""):
            if required:
                raise ActionError(f"I need “{arg}” to do that.")
            continue
        if kind is int:
            try:
                value = int(value)
            except (TypeError, ValueError):
                raise ActionError(f"“{arg}” must be a number.") from None
            if not 0 <= value <= int(limit):
                raise ActionError(f"“{arg}” is out of range.")
        else:
            value = " ".join(str(value).split())
            if isinstance(limit, tuple):
                if value not in limit:
                    raise ActionError(f"“{arg}” must be one of: {', '.join(limit)}.")
            elif len(value) > int(limit):
                raise ActionError(f"“{arg}” is too long.")
        clean[arg] = value
    if "url" in clean and not re.match(r"^https?://[^\s]+$", clean["url"]):
        raise ActionError("That web address is not valid.")
    if "number" in clean and not re.match(r"^[+\d][\d\s\-()]{2,19}$", clean["number"]):
        raise ActionError("That phone number is not valid.")
    return internal, clean, where, risky


def label(name: str, args: Dict[str, Any]) -> str:
    n = re.sub(r"^a_", "", name)
    detail = args.get("name") or args.get("title") or args.get("query") or args.get("place") or args.get("number") or args.get("text") or args.get("control") or args.get("direction") or args.get("state") or args.get("page") or ""
    if n == "alarm":
        detail = f"{args.get('hour', 0):02d}:{args.get('minute', 0):02d}"
    if n == "timer":
        detail = f"{args.get('seconds', 0)} seconds"
    return (n.replace("_", " ").capitalize() + (f": {detail}" if detail else "")).strip()


# ------------------------------------------------------------------- Windows hands

_APPS = {
    "chrome": "chrome", "google chrome": "chrome", "edge": "msedge", "microsoft edge": "msedge", "firefox": "firefox",
    "notepad": "notepad", "calculator": "calc", "calc": "calc", "paint": "mspaint", "explorer": "explorer",
    "file explorer": "explorer", "files": "explorer", "settings": "ms-settings:", "task manager": "taskmgr",
    "command prompt": "cmd", "cmd": "cmd", "powershell": "powershell", "word": "winword", "excel": "excel",
    "powerpoint": "powerpnt", "spotify": "spotify", "whatsapp": "whatsapp:", "vs code": "code", "vscode": "code",
    "visual studio code": "code", "camera": "microsoft.windows.camera:", "calendar": "outlookcal:", "mail": "outlookmail:",
    "store": "ms-windows-store:", "clock": "ms-clock:", "photos": "ms-photos:", "snipping tool": "snippingtool",
    "teams": "msteams:", "discord": "discord", "zoom": "zoom", "vlc": "vlc", "steam": "steam",
}
_SITES = {"youtube": "https://www.youtube.com", "gmail": "https://mail.google.com", "google": "https://www.google.com",
          "maps": "https://maps.google.com", "netflix": "https://www.netflix.com", "instagram": "https://www.instagram.com",
          "facebook": "https://www.facebook.com", "twitter": "https://x.com", "x": "https://x.com", "chatgpt": "https://chatgpt.com"}
_FOLDERS = {"downloads": "Downloads", "documents": "Documents", "desktop": "Desktop", "pictures": "Pictures", "music": "Music", "videos": "Videos"}
_SAFE_NAME = re.compile(r"^[\w .\-]{1,40}$")
_VK = {"volume:up": 0xAF, "volume:down": 0xAE, "volume:mute": 0xAD, "media:play_pause": 0xB3, "media:next": 0xB0,
       "media:previous": 0xB1, "media:stop": 0xB2}


class WindowsShell:
    """Does the real work on a Windows PC. Replaced by a fake in tests."""

    def start(self, argv: List[str]) -> None:
        subprocess.Popen(argv, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))

    def startfile(self, target: str) -> None:
        os.startfile(target)  # type: ignore[attr-defined]

    def key(self, vk: int, times: int = 1) -> None:
        user32 = ctypes.windll.user32  # type: ignore[attr-defined]
        for _ in range(times):
            user32.keybd_event(vk, 0, 0, 0)
            user32.keybd_event(vk, 0, 2, 0)

    def lock(self) -> None:
        ctypes.windll.user32.LockWorkStation()  # type: ignore[attr-defined]

    def browse(self, url: str) -> None:
        webbrowser.open(url)


def run_windows(name: str, a: Dict[str, Any], sh: Any) -> str:
    if name == "open_app":
        wanted = a["name"].lower().strip()
        if wanted in _SITES:
            sh.browse(_SITES[wanted])
            return f"Opened {a['name']}"
        target = _APPS.get(wanted)
        if target is None:
            if not _SAFE_NAME.match(a["name"]):
                raise ActionError("I can't open an app with that name.")
            target = a["name"]
        if target.endswith(":"):
            sh.startfile(target)
        else:
            sh.start(["cmd", "/c", "start", "", target])
        return f"Opened {a['name']}"
    if name == "open_url":
        sh.browse(a["url"])
        return "Opened the page"
    if name == "search_web":
        sh.browse("https://www.google.com/search?q=" + urllib.parse.quote(a["query"]))
        return f"Searched the web for {a['query']}"
    if name == "open_folder":
        folder = _FOLDERS.get(a["name"].lower())
        if not folder:
            raise ActionError("I only know downloads, documents, desktop, pictures, music and videos.")
        sh.startfile(str(Path.home() / folder))
        return f"Opened {folder}"
    if name == "volume":
        sh.key(_VK["volume:" + a["direction"]], 1 if a["direction"] == "mute" else 5)
        return "Volume " + {"up": "raised", "down": "lowered", "mute": "toggled"}[a["direction"]]
    if name == "media":
        sh.key(_VK["media:" + a["control"]])
        return "Done: " + a["control"].replace("_", " ")
    if name == "lock_screen":
        sh.lock()
        return "Locked the screen"
    if name in ("shutdown", "restart"):
        sh.start(["shutdown", "/s" if name == "shutdown" else "/r", "/t", "20"])
        return ("Shutting down" if name == "shutdown" else "Restarting") + " in 20 seconds. Say “cancel shutdown” to stop it"
    if name == "cancel_shutdown":
        sh.start(["shutdown", "/a"])
        return "Cancelled the shutdown"
    if name == "sleep_pc":
        sh.start(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
        return "Going to sleep"
    if name == "close_app":
        if not _SAFE_NAME.match(a["name"]):
            raise ActionError("I can't close an app with that name.")
        exe = _APPS.get(a["name"].lower(), a["name"])
        exe = exe if exe.lower().endswith(".exe") else exe + ".exe"
        sh.start(["taskkill", "/IM", exe])
        return f"Asked {a['name']} to close"
    raise ActionError("I can't do that.")


# ------------------------------------------------------------------------ runner

class ActionRunner:
    """Runs checked actions. Planner actions run here on every device; Windows actions run here too;
    Android actions are handed to the app (the page or the background service)."""

    def __init__(self, planner: Planner, platform: str, forward: Optional[Callable[[Dict[str, Any], bool], str]] = None,
                 shell: Optional[Any] = None) -> None:
        self.planner = planner
        self.platform = normalize_platform(platform)
        self.forward = forward
        self.shell = shell or WindowsShell()
        self.client_queue: List[Dict[str, Any]] = []  # commands from the other device waiting for the Android app

    def _planner(self, name: str, a: Dict[str, Any]) -> Dict[str, str]:
        p = self.planner
        if name in ("add_task", "add_event"):
            item = p.add("task" if name == "add_task" else "event", a["title"], a.get("when"), a.get("repeat", "none"), a.get("remind"))
            when = f" for {item['when'].replace('T', ' ')}" if item.get("when") else ""
            return {"text": f"Added “{item['title']}”{when}", "marker": f"[[done:Added “{item['title']}”{when}]]"}
        if name == "complete_task":
            found = p.find(a["title"], "task")
            if not found:
                raise ActionError(f"I can't find a task called “{a['title']}”.")
            p.complete(found["id"])
            return {"text": f"Ticked off “{found['title']}”", "marker": f"[[done:Ticked off “{found['title']}”]]"}
        if name == "delete_item":
            found = p.find(a["title"])
            if not found:
                raise ActionError(f"I can't find “{a['title']}”.")
            p.delete(found["id"])
            return {"text": f"Deleted “{found['title']}”", "marker": f"[[done:Deleted “{found['title']}”]]"}
        if name == "show_calendar":
            month = a.get("month") or datetime.now().strftime("%Y-%m")
            if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", month):
                raise ActionError("Say the month like 2026-10.")
            return {"text": "Here is the calendar", "marker": f"[[calendar:{month}]]"}
        return {"text": "Here is your to-do list", "marker": "[[tasks]]"}

    def execute(self, action: Dict[str, Any], confirmed: bool = False, remote: bool = False) -> Dict[str, Any]:
        """Runs ONE action. Returns {action, label, status: done|failed|confirm|client|sent, text, marker?, args?}."""
        raw_name = str(action.get("action", ""))
        try:
            if action.get("on") == "other" and not remote:
                internal, args, _where, risky = self._check_any(action)
                if risky and not confirmed:
                    return {"action": raw_name, "label": label(internal, args) + " (other device)", "status": "confirm",
                            "text": "Needs your OK", "args": action}
                if not self.forward:
                    raise ActionError("No other device is paired. Open Settings, then Phone ↔ Laptop.")
                sent = {k: v for k, v in action.items() if k != "on"}
                return {"action": raw_name, "label": label(internal, args) + " (other device)", "status": "sent", "text": self.forward(sent, confirmed)}
            internal, args, where, risky = check(action, self.platform)
            lab = label(internal, args)
            if risky and not confirmed:
                return {"action": raw_name, "label": lab, "status": "confirm", "text": "Needs your OK", "args": action}
            if where == "planner":
                out = self._planner(internal, args)
                return {"action": raw_name, "label": lab, "status": "done", **out}
            if where == "android":
                if remote:
                    self.client_queue.append({"action": internal, **args})
                    return {"action": raw_name, "label": lab, "status": "done", "text": "Passed to the phone"}
                return {"action": raw_name, "label": lab, "status": "client", "text": "", "args": {"action": internal, **args}}
            if self.platform == "windows":
                return {"action": raw_name, "label": lab, "status": "done", "text": run_windows(internal, args, self.shell)}
            if internal in ("open_url", "search_web"):  # Mac / Linux dev machines
                webbrowser.open(args.get("url") or "https://www.google.com/search?q=" + urllib.parse.quote(args["query"]))
                return {"action": raw_name, "label": lab, "status": "done", "text": "Opened in the browser"}
            raise ActionError("That isn't supported on this computer yet.")
        except (ActionError, PlannerError) as error:
            return {"action": raw_name, "label": raw_name.replace("_", " ").capitalize(), "status": "failed", "text": str(error)}
        except OSError:
            return {"action": raw_name, "label": raw_name.replace("_", " ").capitalize(), "status": "failed", "text": "Windows would not let me do that."}

    def _check_any(self, action: Dict[str, Any]) -> Tuple[str, Dict[str, Any], str, bool]:
        """For the other device we don't know its platform, so check against both and accept either."""
        for plat in ("windows", "android"):
            try:
                return check({k: v for k, v in action.items() if k != "on"}, plat)
            except ActionError:
                continue
        raise ActionError("I can't do that.")

    def process(self, actions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return [self.execute(a) for a in actions[:MAX_ACTIONS]]
