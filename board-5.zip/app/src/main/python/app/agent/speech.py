"""How a reply should be spoken: which words, in which language, with what mood."""
from __future__ import annotations

import re
from typing import Tuple

EMOTIONS = {"happy": (1.08, 1.05), "excited": (1.18, 1.15), "calm": (0.98, 0.95), "sad": (0.88, 0.88),
            "caring": (1.0, 0.95), "curious": (1.06, 1.0), "playful": (1.12, 1.08), "serious": (0.94, 1.0)}
_TAG = re.compile(r"^\s*\[([a-z]+)\]\s*", re.IGNORECASE)
_EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200D]")
_SCRIPTS = [("\u0900-\u097F", "hi-IN"), ("\u0B80-\u0BFF", "ta-IN"), ("\u0C00-\u0C7F", "te-IN"), ("\u0C80-\u0CFF", "kn-IN"),
            ("\u0D00-\u0D7F", "ml-IN"), ("\u0980-\u09FF", "bn-IN"), ("\u0A80-\u0AFF", "gu-IN"), ("\u0A00-\u0A7F", "pa-IN"),
            ("\u0600-\u06FF", "ar-SA"), ("\u0E00-\u0E7F", "th-TH"), ("\u3040-\u30FF", "ja-JP"), ("\uAC00-\uD7AF", "ko-KR"),
            ("\u4E00-\u9FFF", "zh-CN"), ("\u0400-\u04FF", "ru-RU")]


def script_lang(text: str, fallback: str = "en-US") -> str:
    for span, lang in _SCRIPTS:
        if re.search(f"[{span}]", text):
            return lang
    return fallback


def split_emotion(text: str) -> Tuple[str, str]:
    m = _TAG.match(text)
    if m and m.group(1).lower() in EMOTIONS:
        return m.group(1).lower(), text[m.end():]
    return "", text


def shape(emotion: str) -> Tuple[float, float]:
    """(pitch, rate) for a female-sounding voice in this mood."""
    p, r = EMOTIONS.get(emotion, (1.0, 1.0))
    return min(2.0, 1.1 * p), min(2.0, 1.05 * r)


def speakable(text: str) -> Tuple[str, str]:
    """Returns (emotion, plain words to say aloud): no code, pictures, markers, emoji or markdown."""
    emotion, body = split_emotion(text)
    body = re.sub(r"```.*?(```|$)", " ", body, flags=re.DOTALL)
    body = re.sub(r"\[\[[^\]]*\]\]", " ", body)
    body = re.sub(r"(?im)^\W*file(name)?\s*[:\-].*$", " ", body)
    body = _EMOJI.sub("", body)
    body = re.sub(r"[*_`#>~|]+", "", body)
    return emotion, " ".join(body.split())
