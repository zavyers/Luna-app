"""The wake word ("Hey Luna") for the Android background listener. Same rules as the screen's own."""
from __future__ import annotations

import re
import time
from typing import Any, Callable, Optional, Tuple

GREET = {"hey", "hay", "hi", "hello", "he", "ae", "aye", "arey", "are", "ok", "okay", "hei", "hai", "oye"}
_LUNA_SCRIPTS = re.compile(r"^(लूना|लुना|லூனா|لونا|луна|ルナ|루나)")
WINDOW_SECONDS = 12.0


def phon(s: str) -> str:
    s = re.sub(r"[^a-z0-9]", "", s.lower())
    s = re.sub(r"oo|ou", "u", s)
    s = s.replace("ee", "i").replace("aa", "a").replace("ph", "f").replace("w", "v")
    return re.sub(r"(.)\1+", r"\1", s)


def lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def fuzzy(a: str, b: str) -> bool:
    a, b = phon(a), phon(b)
    if not a or not b:
        return False
    return a == b or (len(b) >= 4 and lev(a, b) <= 1)


class WakeGate:
    """Decides whether what the microphone heard is meant for Luna."""

    def __init__(self, settings: Callable[[], Any]) -> None:
        self._settings = settings
        self.awake_until = 0.0

    def _words(self) -> list:
        s = self._settings()
        phrase = (getattr(s, "wake_word", "") or ("hey " + s.assistant_name)).lower()
        return [w for w in phrase.split() if w]

    def split(self, text: str) -> Tuple[bool, str]:
        s = self._settings()
        tokens = text.strip().split()
        roman = [re.sub(r"[^a-z0-9]", "", t.lower()) for t in tokens]
        words = self._words()
        name = words[-1] if words else "luna"
        for i, tok in enumerate(tokens):
            hit = fuzzy(roman[i], name) or (s.assistant_name.lower() == "luna" and not getattr(s, "wake_word", "") and bool(_LUNA_SCRIPTS.match(tok)))
            if not hit:
                continue
            if len(words) > 1 and not (len(words) == 2 and words[0] in GREET):
                if not all(i - (len(words) - 1) + k >= 0 and fuzzy(roman[i - (len(words) - 1) + k], w) for k, w in enumerate(words)):
                    continue
            rest = " ".join(tokens[i + 1:]).lstrip(",.:;!? ")
            return True, rest
        return False, ""

    def process(self, text: str, now: Optional[float] = None) -> Tuple[str, str]:
        """Returns ("ignore"|"awake"|"command", the words to answer)."""
        now = time.time() if now is None else now
        text = (text or "").strip()
        if not text:
            return "ignore", ""
        s = self._settings()
        if not getattr(s, "wake_required", True) or now < self.awake_until:
            self.awake_until = now + WINDOW_SECONDS
            return "command", text
        hit, rest = self.split(text)
        if not hit:
            return "ignore", ""
        self.awake_until = now + WINDOW_SECONDS
        return ("command", rest) if rest else ("awake", "")

    def extend(self, now: Optional[float] = None) -> None:
        self.awake_until = (time.time() if now is None else now) + WINDOW_SECONDS
