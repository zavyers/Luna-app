package com.luna.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.os.Bundle;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

/**
 * Keeps Luna listening while another app is on screen. Only runs when the person switches
 * "keep listening in the background" on, and always shows a notification while it does.
 */
public class ListenService extends Service {
    static volatile ListenService instance;
    static volatile boolean activityVisible = true;

    private static final int NOTIF_ID = 42;
    private static final String CHANNEL = "luna_listening";

    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer rec;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean busy = false;
    private boolean running = false;
    private boolean stopped = false;
    private Locale ttsLocale = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { main.post(ListenService.this::finishTurn); }
                    @Override public void onError(String utteranceId) { main.post(ListenService.this::finishTurn); }
                });
            }
        });
        main.postDelayed(this::maybeListen, 800);
        main.postDelayed(this::pollPending, 4000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            getSharedPreferences("luna", MODE_PRIVATE).edit().putBoolean("background", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopped = true;
        instance = null;
        main.removeCallbacksAndMessages(null);
        if (rec != null) {
            rec.destroy();
            rec = null;
        }
        if (tts != null) {
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW));
        }
        String name = getSharedPreferences("luna", MODE_PRIVATE).getString("name", "Luna");
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, ListenService.class).setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 3, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(name + " is listening")
                .setContentText("Say “Hey " + name + "” while using any app")
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(R.mipmap.ic_launcher, "Stop", stopPi);
        return b.build();
    }

    // ------------------------------------------------------------------ listening

    /** Called when Luna's screen appears or disappears. */
    static void refresh() {
        final ListenService s = instance;
        if (s != null) s.main.post(s::syncState);
    }

    private void syncState() {
        if (activityVisible) {
            if (running && rec != null) {
                rec.cancel();
                running = false;
            }
        } else {
            maybeListen();
        }
    }

    private void maybeListen() {
        if (stopped || activityVisible || busy || running) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this);
            rec.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onResults(Bundle results) {
                    running = false;
                    ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list == null || list.isEmpty() || list.get(0).trim().isEmpty()) {
                        main.postDelayed(ListenService.this::maybeListen, 300);
                    } else {
                        handle(list.get(0));
                    }
                }

                @Override
                public void onError(int error) {
                    running = false;
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return;
                    long wait = (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) ? 300 : 3000;
                    main.postDelayed(ListenService.this::maybeListen, wait);
                }
            });
        }
        String lang = getSharedPreferences("luna", MODE_PRIVATE).getString("lang", "en-US");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        running = true;
        rec.startListening(intent);
    }

    private PyObject engine() {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        PyObject module = Python.getInstance().getModule("luna_android");
        module.callAttr("start", getFilesDir().getAbsolutePath() + "/luna"); // does nothing if already started
        return module;
    }

    private void handle(final String text) {
        busy = true;
        new Thread(() -> {
            String out = "";
            try {
                out = engine().callAttr("heard", text).toString();
            } catch (Throwable ignored) {
                // the engine is not ready; just listen again
            }
            final String json = out;
            main.post(() -> onReply(json));
        }).start();
    }

    private void onReply(String json) {
        try {
            JSONObject r = new JSONObject(json);
            String state = r.optString("state");
            if ("awake".equals(state)) {
                new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_ACK, 200);
                finishTurn();
                return;
            }
            if (!"reply".equals(state)) {
                finishTurn();
                return;
            }
            JSONArray actions = r.optJSONArray("actions");
            if (actions != null) {
                for (int i = 0; i < actions.length(); i++) PhoneActions.run(this, actions.getJSONObject(i));
            }
            String say = r.optString("speak");
            JSONArray confirm = r.optJSONArray("confirm");
            if (confirm != null && confirm.length() > 0) say += " That needs your OK, so please open the app.";
            if (say.trim().isEmpty()) {
                finishTurn();
            } else {
                speak(say, r.optString("lang", "en-US"), (float) r.optDouble("pitch", 1.1), (float) r.optDouble("rate", 1.05));
            }
        } catch (Exception e) {
            finishTurn();
        }
    }

    private void finishTurn() {
        busy = false;
        main.postDelayed(this::maybeListen, 400);
    }

    // --------------------------------------------------------------------- speaking

    private void speak(String text, String lang, float pitch, float rate) {
        if (!ttsReady || tts == null) {
            finishTurn();
            return;
        }
        busy = true;
        if (running && rec != null) {
            rec.cancel();
            running = false;
        }
        Locale want = Locale.forLanguageTag(lang);
        if (!want.equals(ttsLocale)) {
            int r = tts.setLanguage(want);
            if (r >= TextToSpeech.LANG_AVAILABLE) {
                ttsLocale = want;
                chooseFemale(want);
            }
        }
        tts.setPitch(pitch);
        tts.setSpeechRate(rate);
        String say = text.length() > 3500 ? text.substring(0, 3500) : text;
        tts.speak(say, TextToSpeech.QUEUE_FLUSH, null, "bg" + System.nanoTime());
    }

    private void chooseFemale(Locale want) {
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            Voice best = null;
            int bestScore = -99;
            for (Voice v : all) {
                if (!v.getLocale().getLanguage().equals(want.getLanguage())) continue;
                String name = v.getName().toLowerCase(Locale.ROOT);
                int score = 0;
                if (name.contains("female")) score += 4;
                else if (name.contains("male")) score -= 5;
                if (!v.isNetworkConnectionRequired()) score += 1;
                if (v.getLocale().equals(want)) score += 1;
                if (score > bestScore) {
                    best = v;
                    bestScore = score;
                }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) {
            // keep the default voice
        }
    }

    static void speakReminder(final String title) {
        final ListenService s = instance;
        if (s != null) s.main.post(() -> s.speak("Reminder, sir: " + title, "en-US", 1.1f, 1.05f));
    }

    // ------------------------------------------------- orders from the paired laptop

    private void pollPending() {
        if (stopped) return;
        if (!activityVisible) {
            new Thread(() -> {
                try {
                    final JSONArray list = new JSONArray(engine().callAttr("pending").toString());
                    if (list.length() == 0) return;
                    main.post(() -> {
                        try {
                            for (int i = 0; i < list.length(); i++) PhoneActions.run(ListenService.this, list.getJSONObject(i));
                        } catch (Exception ignored) {
                            // skip a bad order
                        }
                    });
                } catch (Throwable ignored) {
                    // not ready yet
                }
            }).start();
        }
        main.postDelayed(this::pollPending, 3000);
    }
}
