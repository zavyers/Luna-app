package com.luna.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        String key = intent.getStringExtra("key");
        if (title == null || key == null) return;
        // When Luna is open on screen she shows and speaks the reminder herself.
        if (MainActivity.visible) return;
        Reminders.notifyNow(context, title, intent.getStringExtra("kind"), key);
        ListenService.speakReminder(title);
    }
}
