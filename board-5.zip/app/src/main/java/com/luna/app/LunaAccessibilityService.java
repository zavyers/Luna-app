package com.luna.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

/** Lets Luna press Home/Back, read the screen and tap buttons in other apps. Off until the person switches it on in Settings. */
public class LunaAccessibilityService extends AccessibilityService {
    static volatile LunaAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    static String global(String what) {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control in Settings, then Accessibility first";
        int action;
        switch (what) {
            case "go_home": action = GLOBAL_ACTION_HOME; break;
            case "go_back": action = GLOBAL_ACTION_BACK; break;
            case "recents": action = GLOBAL_ACTION_RECENTS; break;
            case "notifications": action = GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quick_settings": action = GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "a_lock_screen": action = GLOBAL_ACTION_LOCK_SCREEN; break;
            case "screenshot": action = GLOBAL_ACTION_TAKE_SCREENSHOT; break;
            default: return "error: unknown action";
        }
        return s.performGlobalAction(action) ? "ok" : "error: the phone refused";
    }

    static String readScreen() {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control first";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "error: I can't see the screen right now";
        StringBuilder out = new StringBuilder();
        collect(root, out, 0);
        String text = out.toString().trim();
        return text.isEmpty() ? "ok: nothing readable is on the screen" : "ok: " + text;
    }

    private static void collect(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || out.length() > 1500 || depth > 40) return;
        CharSequence t = node.getText();
        if (t == null || t.length() == 0) t = node.getContentDescription();
        if (t != null && t.length() > 0) out.append(t).append(". ");
        for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out, depth + 1);
    }

    static String tapText(String text) {
        LunaAccessibilityService s = instance;
        if (s == null) return "error: turn on Luna phone control first";
        AccessibilityNodeInfo root = s.getRootInActiveWindow();
        if (root == null) return "error: I can't see the screen right now";
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(text);
        if (found == null || found.isEmpty()) return "error: I can't see “" + text + "” on the screen";
        for (AccessibilityNodeInfo n : found) {
            AccessibilityNodeInfo cur = n;
            while (cur != null) {
                if (cur.isClickable()) {
                    return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK) ? "ok: tapped " + text : "error: the tap did not work";
                }
                cur = cur.getParent();
            }
        }
        return "error: “" + text + "” is on the screen but can't be tapped";
    }
}
