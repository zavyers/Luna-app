package com.luna.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Phone alarms for the planner, so reminders ring even when Luna is closed. */
final class Reminders {
    static final String CHANNEL = "luna_reminders";
    private static final String PREFS = "luna";
    private static final int MAX = 50;

    private Reminders() { }

    /** json: [{"key","title","at":"YYYY-MM-DDTHH:MM","kind"}, ...] from the planner. */
    static void schedule(Context ctx, String json) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().putString("reminders", json).apply();
        apply(ctx, json);
    }

    static void rescheduleFromPrefs(Context ctx) {
        String json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("reminders", "[]");
        apply(ctx, json);
    }

    private static PendingIntent pending(Context ctx, String key, String title, String kind, int flags) {
        Intent i = new Intent(ctx, ReminderReceiver.class);
        i.setAction("com.luna.app.REMINDER");
        i.putExtra("key", key);
        i.putExtra("title", title);
        i.putExtra("kind", kind);
        return PendingIntent.getBroadcast(ctx, key.hashCode(), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    private static void apply(Context ctx, String json) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            String old = prefs.getString("scheduled", "");
            if (!old.isEmpty()) {
                for (String key : old.split("\n")) {
                    if (!key.isEmpty()) am.cancel(pending(ctx, key, "", "", PendingIntent.FLAG_UPDATE_CURRENT));
                }
            }
            JSONArray list = new JSONArray(json);
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            long now = System.currentTimeMillis();
            List<String> keys = new ArrayList<>();
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            for (int n = 0; n < list.length() && keys.size() < MAX; n++) {
                JSONObject r = list.getJSONObject(n);
                Date when = fmt.parse(r.getString("at"));
                if (when == null || when.getTime() <= now) continue;
                String key = r.getString("key");
                PendingIntent pi = pending(ctx, key, r.optString("title"), r.optString("kind", "task"), PendingIntent.FLAG_UPDATE_CURRENT);
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTime(), pi);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTime(), pi);
                keys.add(key);
            }
            prefs.edit().putString("scheduled", String.join("\n", keys)).apply();
        } catch (Exception ignored) {
            // a bad list just means no alarms this time
        }
    }

    static void channel(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    static void notifyNow(Context ctx, String title, String kind, String key) {
        channel(ctx);
        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent tap = PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CHANNEL) : new Notification.Builder(ctx);
        b.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("event".equals(kind) ? "Event" : "Reminder")
                .setContentText(title)
                .setAutoCancel(true)
                .setContentIntent(tap);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(key.hashCode(), b.build());
    }
}
