"""Instant answers for the requests that never need the AI: opening an app, "who messaged me",
"open my latest message" and "read my screen". Going straight to the phone/PC makes them feel
immediate, because the usual path waits for a full AI round trip first.

`match()` returns None when the text isn't one of these, and Luna carries on as usual.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

_STRIP = re.compile(r"[^\w\s'+-]", re.UNICODE)
_FILLER = r"(?:\s+(?:app|application|please|pls|for me|now|ok|okay|sir|ma'?am))*"

_OPEN = re.compile(r"^(?:(?:hey\s+)?please\s+)?(?:(?:can|could|would) you\s+)?(?:open|launch|start)\s+(?:up\s+)?(?:the\s+|my\s+)?(.{1,40}?)" + _FILLER + r"$")
_OPEN_HI = re.compile(r"^(?:please\s+)?(.{1,40}?)\s+(?:kholo|khol do|khol de|kholna|open karo|open kar do|chalu karo|chalao|chala do|start karo)" + _FILLER + r"$")
_NOT_APPS = {"calendar", "my calendar", "the calendar", "calendar view", "todo", "to do", "to do list", "todo list", "tasks", "task list",
             "my tasks", "list", "new chat", "a new chat", "new project", "a new project", "chat", "message", "messages", "my messages",
             "latest message", "last message", "my latest message", "my last message", "new message", "recent message", "notifications"}

_MSG_WORDS = r"(?:messages?|msgs?|texts?|whatsapp|chats?|notifications?|dms?|conversations?)"
_OPEN_WORDS = r"(?:(?:whatsapp|instagram|insta)\s+)?(?:messages?|msgs?|texts?|chats?|dms?|conversations?|notifications?)"
_OPEN_MSG = re.compile(r"^(?:please\s+)?(?:open|show|go to|take me to)\s+(?:me\s+)?(?:the\s+|my\s+)?(?:(?:latest|last|new|recent|newest|unread)\s+)?" + _OPEN_WORDS
                       + r"(?:\s+(?:from|of|by|with|on|in|at)\s+(.{1,30}))?" + _FILLER + r"$")
_OPEN_MSG_HI = re.compile(r"^(?:mera\s+|meri\s+)?(?:(?:latest|last|new|naya|aakhri)\s+)?(?:(?:whatsapp|instagram|insta)\s+)?(?:message|msg)\s+(?:kholo|khol do|dikhao|open karo)$")
_WHO = re.compile(r"\b(?:who|whom|kisne|kaun)\b.{0,30}\b(?:messag\w*|texted|text|msg\w*|called|whatsapp\w*|sent|sent me|dm|dmed|pinged|ne message|ne msg)\b|"
                  r"\bwho(?:'s| is| has| was)?\s+(?:just\s+)?(?:messag\w+|text\w*|call\w*)\b|\bkisne\s+(?:message|msg)\b")
_READ = re.compile(r"^(?:please\s+)?(?:read|tell me|show|what(?:'s| is| are)?|any|check)\b.{0,25}\b" + _MSG_WORDS + r"\b|"
                   r"^(?:do i have|have i got|any)\s+(?:any\s+)?(?:new\s+)?" + _MSG_WORDS + r"\b|"
                   r"^(?:mere|mera|meri)\s+(?:naye\s+|new\s+|latest\s+)?(?:message|msg)\w*\s+(?:padho|sunao|batao|dikhao)")
_WHAT_DID = re.compile(r"^(?:and\s+)?what\s+(?:did|has|was|is)\s+.{1,30}?\s+(?:say|said|saying|send|sent|write|wrote|text|texted|message|messaged)\b")
_FROM = [re.compile(r"\b(?:from|of|with|by)\s+([a-z][\w .'-]{0,28}?)(?:\s+(?:on|in|please|now|today)\b.*)?$"),
         re.compile(r"\bwhat\s+(?:did|has|was)\s+([a-z][\w .'-]{0,28}?)\s+(?:say|said|send|sent|write|wrote|text|texted|message|messaged)\b")]
_SCREEN = re.compile(r"\b(?:read|summari[sz]e|describe|explain|tell me what(?:'s| is)? (?:on|in)|what(?:'s| is)? (?:on|in)|what do you see on)\s+(?:out\s+)?(?:my\s+|the\s+|this\s+)?(?:phone\s+)?(?:screen|page|display)\b|"
                     r"\bscreen\s+(?:par|pe|mein|me)\s+kya\b|\bwhat(?:'s| is)? on screen\b")
# ---- calls and chats with a person
_WA = re.compile(r"\b(?:whatsapp|whats app|watsapp|whatsap)\b")
_IG = re.compile(r"\b(?:instagram|insta)\b")
_CALL_VERB = re.compile(r"\b(?:call|calling|ring|dial|phone|lagao|laga)\b")
_CHAT_VERB = re.compile(r"\b(?:message|msg|chat|text|dm|open)\b")
_NAME_STOP = {"please", "pls", "make", "a", "an", "give", "start", "place", "whatsapp", "whats", "app", "watsapp", "whatsap", "call", "calling",
              "video", "voice", "to", "my", "on", "using", "via", "through", "over", "in", "ko", "ka", "ki", "pe", "par", "karo", "kar", "do",
              "lagao", "laga", "ring", "phone", "dial", "can", "you", "could", "would", "me", "hey", "message", "msg", "chat", "text", "dm",
              "open", "with", "the", "latest", "last", "new", "recent", "newest", "unread", "send", "normal", "normally", "regular", "mobile",
              "sim", "from", "using", "cellular", "audio", "of", "for", "and", "i", "want", "wanna", "need", "let", "s", "lets", "now", "chat's"}
_PLAIN_CALL = re.compile(r"^(?:please\s+)?(?:(?:can|could|would) you\s+)?(?:make\s+a\s+)?(?:(?:normal|regular|phone|mobile|cellular|sim)\s+)?"
                         r"(?:call|ring|dial|phone)\s+(?:to\s+)?(?:my\s+)?(.+?)"
                         r"(?:\s+(?:normally|normal|on (?:my )?(?:phone|sim|mobile)|using (?:the |my )?(?:sim|phone)|from (?:my )?(?:sim|phone)|please))?$")
_PLAIN_CALL_HI = re.compile(r"^(.+?)\s+ko\s+(?:(?:normal|simple|phone)\s+)?call\s+(?:karo|kar do|lagao|laga do|kardo)$")
_NOT_PEOPLE = {"me", "it", "a", "an", "the", "this", "that", "back", "off", "out", "up", "when", "if", "someone", "somebody", "anyone", "us", "them"}
_LATEST = re.compile(r"\b(?:now|latest|last|just|recent|newest)\b")


@dataclass
class FastResult:
    text: str
    actions: List[Dict[str, Any]] = field(default_factory=list)  # shown like any other action: {label,status,text,args}
    ok: bool = True
    note: str = ""


def _clean(text: str) -> str:
    return " ".join(_STRIP.sub(" ", (text or "").lower()).split())


def _ago(seconds: float) -> str:
    s = max(0, int(seconds))
    if s < 60:
        return "just now"
    if s < 3600:
        m = s // 60
        return f"{m} minute{'s' if m != 1 else ''} ago"
    if s < 86400:
        h = s // 3600
        return f"{h} hour{'s' if h != 1 else ''} ago"
    d = s // 86400
    return f"{d} day{'s' if d != 1 else ''} ago"


class FastIntents:
    NEED_ACCESS = ("I can't see your messages yet. Open Luna's Settings and tap “Allow notification access”, switch Luna on, "
                   "and then ask me again. I only read message notifications, and only when you ask.")

    def __init__(self, platform: str, phone: Any = None, runner: Any = None, windows_apps: Optional[Dict[str, Any]] = None,
                 summarise: Optional[Callable[[str, str], str]] = None, now: Optional[Callable[[], float]] = None) -> None:
        self.platform = platform
        self.phone = phone
        self.runner = runner
        self.windows_apps = windows_apps or {}
        self.summarise = summarise
        import time
        self.now = now or time.time

    # ------------------------------------------------------------------ routing

    def match(self, text: str) -> Optional[FastResult]:
        t = _clean(text)
        if not t or len(t) > 120:
            return None
        if self.platform == "android" and self.phone is not None:
            for fn in (self._call_person, self._chat_person, self._open_message, self._who_messaged, self._read_screen):
                out = fn(t)
                if out is not None:
                    return out
        return self._open_app(t)

    # ------------------------------------------------------------------ opening apps

    def _app_name(self, t: str) -> Optional[str]:
        for rx in (_OPEN, _OPEN_HI):
            m = rx.match(t)
            if m:
                name = m.group(1).strip()
                if not name or name in _NOT_APPS or len(name.split()) > 4 or re.search(r"\b(and|then|http|www|\.com)\b", name):
                    return None
                return name
        return None

    def _open_app(self, t: str) -> Optional[FastResult]:
        name = self._app_name(t)
        if not name:
            return None
        if self.platform == "android" and self.phone is not None:
            label = self.phone.find_app(name)
            if not label:
                return None  # maybe not an app at all ("open the door"): let the AI decide
            return FastResult(f"[calm] Opening {label}.", [{"label": f"Open app: {label}", "status": "client", "text": "",
                                                           "args": {"action": "a_open_app", "name": label}}], note=f"Opened {label}")
        if self.platform == "windows" and self.runner is not None and name in self.windows_apps:
            res = self.runner.execute({"action": "open_app", "name": name})
            if res.get("status") == "done":
                return FastResult(f"[calm] Opening {name.title() if name.islower() else name}.", note=f"Opened {name}")
            return FastResult("[caring] " + str(res.get("text") or "I couldn't open that."), ok=False)
        return None

    # ------------------------------------------------------------------ calls and chats with a person

    @staticmethod
    def _who_words(t: str) -> str:
        words = [w for w in t.split() if w not in _NAME_STOP]
        return " ".join(words) if 1 <= len(words) <= 3 else ""

    def _resolve(self, name: str):
        """Returns (contact name, None) or (None, FastResult explaining why not). None, None means "not about a contact"."""
        if not self.phone.contacts_enabled():
            return None, FastResult("[caring] I need permission to read your contacts first. Open Luna's Settings, tap “Allow contacts and calling”, "
                                    "allow it, and ask me again.", ok=False)
        rows = self.phone.find_contact(name)
        if not rows:
            if set(name.split()) & _NOT_PEOPLE:
                return None, None
            return None, FastResult(f"[caring] I can't find {name} in your contacts.", ok=False)
        exact = [r for r in rows if str(r.get("name", "")).lower() == name.lower()]
        if len(exact) == 1:
            return str(exact[0]["name"]), None
        if len(rows) > 1:
            names = ", ".join(str(r["name"]) for r in rows[:4])
            return None, FastResult(f"[curious] I found more than one: {names}. Say the full name of the one you mean.", ok=False)
        return str(rows[0]["name"]), None

    def _contact_action(self, name: str, action: str, text: str, label: str, **extra: Any) -> FastResult:
        return FastResult(f"[calm] {text}", [{"label": label, "status": "client", "text": "",
                                              "args": {"action": action, "contact": name, **extra}}], note=label)

    def _call_person(self, t: str) -> Optional[FastResult]:
        if not _CALL_VERB.search(t) and "video call" not in t:
            return None
        wa, ig = bool(_WA.search(t)), bool(_IG.search(t))
        video = bool(re.search(r"\bvideo\b", t))
        # Instagram has no way to start a call for another app, so say so instead of pretending
        if ig and not wa:
            return FastResult("[caring] I can't start Instagram calls, because Instagram doesn't allow other apps to. "
                              "I can open your Instagram messages (say “open my latest message on Instagram”), or call them on WhatsApp "
                              "or by phone if you say which.", ok=False)
        if wa:
            name = self._who_words(t)
            if not name:
                return None
            who, problem = self._resolve(name)
            if problem is not None:
                return problem
            if who is None:
                return None
            kind = "video call" if video else "call"
            return self._contact_action(who, "whatsapp_call", f"Starting a WhatsApp {kind} with {who}.", f"WhatsApp {kind}: {who}", video="yes" if video else "no")
        if video:
            return FastResult("[curious] Which app should I use for the video call? Say “video call … on WhatsApp”.", ok=False)
        m = _PLAIN_CALL.match(t) or _PLAIN_CALL_HI.match(t)
        if not m:
            return None
        name = m.group(1).strip()
        if not name or len(name.split()) > 3 or re.search(r"\b(and|then|http|www)\b", name):
            return None
        digits = re.sub(r"[\s-]", "", name)
        if re.fullmatch(r"\+?\d{3,15}", digits):  # a spoken number: open the dialer and let the person press call
            return FastResult(f"[calm] Opening the dialer with {digits}.", [{"label": f"Call: {digits}", "status": "client", "text": "",
                                                                          "args": {"action": "call", "number": digits}}])
        who, problem = self._resolve(name)
        if problem is not None:
            return problem
        if who is None:
            return None
        return self._contact_action(who, "call_contact", f"Calling {who}.", f"Call: {who}")

    def _chat_person(self, t: str) -> Optional[FastResult]:
        if not _WA.search(t) or _CALL_VERB.search(t) or not _CHAT_VERB.search(t):
            return None
        name = self._who_words(t)
        if not name:
            return None  # "open my latest message on whatsapp" is handled as an open-message request
        who, problem = self._resolve(name)
        if problem is not None:
            return problem
        if who is None:
            return None
        return self._contact_action(who, "whatsapp_chat", f"Opening your WhatsApp chat with {who}.", f"WhatsApp chat: {who}")

    # ------------------------------------------------------------------ messages

    @staticmethod
    def _person(t: str) -> str:
        for rx in _FROM:
            m = rx.search(t)
            if m:
                who = m.group(1).strip()
                if who and who not in ("me", "my", "the", "a", "luna", "whatsapp", "messages", "my messages"):
                    return who
        return ""

    def _open_message(self, t: str) -> Optional[FastResult]:
        m = _OPEN_MSG.match(t)
        if not (m or _OPEN_MSG_HI.match(t)):
            return None
        who = (m.group(1) if m and m.group(1) else "") or self._person(t)
        app_word = re.search(r"\b(whatsapp|instagram|insta)\b", t)
        if app_word and (not who or who.strip() in ("whatsapp", "instagram", "insta")):
            who = "instagram" if app_word.group(1) == "insta" else app_word.group(1)
        if not self.phone.messages_enabled():
            return FastResult("[caring] " + self.NEED_ACCESS, ok=False)
        res = self.phone.open_message(who.strip())
        if not res.startswith("ok") and who.strip():
            app = self.phone.find_app(who.strip())
            if app:  # "open my message on WhatsApp" with no message notification: open the app itself
                return FastResult(f"[calm] I don't see a new message there, so I'm opening {app}.",
                                  [{"label": f"Open app: {app}", "status": "client", "text": "",
                                    "args": {"action": "a_open_app", "name": app}}], note=f"Opened {app}")
        if res.startswith("ok"):
            return FastResult("[calm] Opening " + (f"{who}'s" if who else "your latest") + " message.", note="Opened a message")
        return FastResult("[caring] " + (res.split(":", 1)[1].strip() if ":" in res else res).capitalize(), ok=False)

    def _who_messaged(self, t: str) -> Optional[FastResult]:
        if not (_WHO.search(t) or _READ.search(t) or _WHAT_DID.search(t)):
            return None
        if "open" in t.split()[:2]:
            return None
        if not self.phone.messages_enabled():
            return FastResult("[caring] " + self.NEED_ACCESS, ok=False)
        who = self._person(t)
        asking_who = bool(_WHO.search(t))
        latest_only = bool(_LATEST.search(t)) and not who and not asking_who
        rows = self.phone.recent_messages(12, who)
        if not rows:
            return FastResult("[calm] " + (f"I don't see any recent messages from {who}." if who else "I don't see any new messages."), note="No messages")
        now = self.now()
        # one entry per conversation (newest first), so a chatty friend doesn't hide everyone else
        convs: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            convs.setdefault(f"{r.get('app','')}|{r.get('conv') or r.get('sender','')}", []).append(r)
        out: List[str] = []
        if who:
            first = next(iter(convs.values()))
            sender = first[0].get("sender") or who
            lines = [f"{str(r.get('text',''))[:240]}" for r in reversed(first[:5])]
            out.append(f"[calm] Recent messages from {sender} on {first[0].get('app') or 'your phone'}:")
            out += [f"“{line}”" for line in lines]
        else:
            keys = list(convs)[: (1 if latest_only else 3)]
            total = len(convs)
            if latest_only or total == 1:
                out.append("[calm] Your latest message:" if latest_only else "[calm] You have a new message:")
            else:
                out.append(f"[calm] {total} people messaged you. The latest {len(keys)}:")
            for k in keys:
                grp = convs[k]
                r = grp[0]
                text = str(r.get("text", ""))[:240]
                more = f" (and {len(grp) - 1} more)" if len(grp) > 1 else ""
                when = _ago(now - float(r.get("when", now) or now))
                title = r.get("conv") or r.get("sender") or "Someone"
                sender = r.get("sender") or title
                head = f"{title}: {sender}" if r.get("conv") and sender != title else sender
                out.append(f"{head} on {r.get('app') or 'your phone'}, {when}{more}: “{text}”")
        return FastResult("\n".join(out), note=f"Read {len(convs)} conversation(s)")

    # ------------------------------------------------------------------ the screen

    def _read_screen(self, t: str) -> Optional[FastResult]:
        if not _SCREEN.search(t):
            return None
        raw = self.phone.read_screen()
        if not raw.startswith("ok"):
            msg = raw.split(":", 1)[1].strip() if ":" in raw else "I can't see the screen."
            if "turn on" in msg.lower():
                msg = "I can't read the screen yet. Open Luna's Settings, tap “Turn on phone control”, switch Luna on, then ask again."
            return FastResult("[caring] " + msg[:300], ok=False)
        content = raw.split(":", 1)[1].strip()
        if "nothing readable" in content:
            return FastResult("[calm] I can't find any readable text on the screen.")
        answer = ""
        if self.summarise is not None:
            try:
                answer = self.summarise(t, content).strip()
            except Exception:
                answer = ""
        if not answer:
            answer = "Here is what's on the screen: " + content[:500]
        return FastResult(answer if answer.startswith("[") else "[calm] " + answer, note="Read the screen")
