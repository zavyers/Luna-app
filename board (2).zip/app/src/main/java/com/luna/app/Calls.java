package com.luna.app;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Phone calls, WhatsApp calls and WhatsApp chats for a person from the contacts list. */
final class Calls {
    private Calls() { }

    private static final String[] EMERGENCY = {"112", "911", "999", "100", "101", "102", "108"};

    static boolean canRead(Context c) {
        return c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean canCall(Context c) {
        return c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
    }

    /** People in the contacts matching the name: JSON [{id, name, number}], best match first, one entry per person. */
    static String searchJson(Context ctx, String name) {
        JSONArray out = new JSONArray();
        String w = name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
        if (w.isEmpty() || !canRead(ctx)) return out.toString();
        Cursor cur = null;
        try {
            cur = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + w + "%"}, null);
            Map<Long, String[]> people = new LinkedHashMap<>();
            while (cur != null && cur.moveToNext()) {
                long id = cur.getLong(0);
                if (!people.containsKey(id)) people.put(id, new String[]{cur.getString(1), cur.getString(2)});
            }
            ArrayList<Map.Entry<Long, String[]>> list = new ArrayList<>(people.entrySet());
            final String key = w;
            list.sort((a, b) -> rank(a.getValue()[0], key) - rank(b.getValue()[0], key));
            for (Map.Entry<Long, String[]> e : list) {
                if (out.length() >= 6) break;
                JSONObject o = new JSONObject();
                o.put("id", e.getKey());
                o.put("name", e.getValue()[0]);
                o.put("number", e.getValue()[1]);
                out.put(o);
            }
        } catch (Exception ignored) {
            // no contacts available: report an empty list
        } finally {
            if (cur != null) cur.close();
        }
        return out.toString();
    }

    private static int rank(String name, String w) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        return n.equals(w) ? 0 : n.startsWith(w) ? 1 : 2;
    }

    private static JSONObject pick(Context ctx, String name) throws Exception {
        JSONArray arr = new JSONArray(searchJson(ctx, name));
        if (arr.length() == 0) return null;
        String w = name.trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < arr.length(); i++) {
            if (arr.getJSONObject(i).getString("name").toLowerCase(Locale.ROOT).equals(w)) return arr.getJSONObject(i);
        }
        return arr.getJSONObject(0);
    }

    private static String notFound(Context ctx, String name) {
        return canRead(ctx) ? "error: I can't find “" + name + "” in your contacts"
                : "error: allow Contacts for Luna first (Luna Settings, then Allow contacts and calling)";
    }

    /** A normal phone call. Calls straight away when Luna may call; otherwise opens the dialer with the number filled in. */
    static String callContact(Context ctx, String name) throws Exception {
        JSONObject c = pick(ctx, name);
        if (c == null) return notFound(ctx, name);
        String number = c.getString("number");
        String shown = c.getString("name");
        String digits = number.replaceAll("\\D", "");
        boolean emergency = false;
        for (String e : EMERGENCY) if (digits.equals(e)) emergency = true; // never dial an emergency number on my own
        if (canCall(ctx) && !emergency) {
            return PhoneActions.open(ctx, new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))), "calling " + shown);
        }
        return PhoneActions.open(ctx, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))),
                "the dialer is open with " + shown + ", press call" + (emergency || canCall(ctx) ? "" : ". Allow Calling in Luna's settings and I'll call straight away"));
    }

    private static long dataRow(Context ctx, long contactId, String mime) {
        Cursor cur = null;
        try {
            cur = ctx.getContentResolver().query(ContactsContract.Data.CONTENT_URI, new String[]{ContactsContract.Data._ID},
                    ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                    new String[]{String.valueOf(contactId), mime}, null);
            if (cur != null && cur.moveToFirst()) return cur.getLong(0);
        } catch (Exception ignored) {
            // treat as not found
        } finally {
            if (cur != null) cur.close();
        }
        return -1;
    }

    /** A WhatsApp voice call, video call or chat with a contact, using the entries WhatsApp adds to the contacts. */
    static String whatsapp(Context ctx, String name, boolean video, boolean chat) throws Exception {
        JSONObject c = pick(ctx, name);
        if (c == null) return notFound(ctx, name);
        String shown = c.getString("name");
        long id = c.getLong("id");
        PackageManager pm = ctx.getPackageManager();
        String[][] apps = {{"com.whatsapp", "vnd.com.whatsapp", "WhatsApp"}, {"com.whatsapp.w4b", "vnd.com.whatsapp.w4b", "WhatsApp Business"}};
        boolean installed = false;
        for (String[] a : apps) {
            if (pm.getLaunchIntentForPackage(a[0]) == null) continue;
            installed = true;
            String mime = "vnd.android.cursor.item/" + a[1] + (chat ? ".profile" : video ? ".video.call" : ".voip.call");
            long row = dataRow(ctx, id, mime);
            if (row < 0) continue;
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, row), mime);
            i.setPackage(a[0]);
            String what = chat ? "opened your " + a[2] + " chat with " + shown : "asked " + a[2] + " to start a " + (video ? "video" : "voice") + " call with " + shown;
            return PhoneActions.open(ctx, i, what);
        }
        if (!installed) return "error: WhatsApp isn't installed on this phone";
        String number = c.getString("number").replaceAll("[^+\\d]", "");
        if (chat && number.startsWith("+")) {
            return PhoneActions.open(ctx, new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + number.substring(1))), "opened a WhatsApp chat with " + shown);
        }
        return "error: " + shown + " has no WhatsApp entry in your contacts, so I can't start that";
    }
}
